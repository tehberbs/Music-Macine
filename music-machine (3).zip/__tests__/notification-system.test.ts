import { describe, it, expect, beforeEach, vi } from 'vitest';
import { NotificationService } from '../lib/notification-service';
import { playbackNotifications, downloadNotifications, errorNotifications, featureNotifications } from '../lib/notification-integration-example';

describe('Notification System', () => {
  let service: NotificationService;
  let mockHook: any;

  beforeEach(() => {
    // Reset singleton
    NotificationService.instance = null;
    service = NotificationService.getInstance();

    // Create mock notification hook
    mockHook = {
      show: vi.fn((notification) => {
        return `notification-${Date.now()}`;
      }),
      hide: vi.fn(),
      clear: vi.fn(),
      notifications: [],
    };

    service.setNotificationHook(mockHook);
  });

  describe('NotificationService', () => {
    it('should be a singleton', () => {
      const service1 = NotificationService.getInstance();
      const service2 = NotificationService.getInstance();
      expect(service1).toBe(service2);
    });

    it('should show success notification', () => {
      service.showSuccess('Test', 'Success message');
      expect(mockHook.show).toHaveBeenCalledWith(
        expect.objectContaining({
          type: 'success',
          title: 'Test',
          message: 'Success message',
        })
      );
    });

    it('should show error notification', () => {
      service.showError('Error', 'Something went wrong');
      expect(mockHook.show).toHaveBeenCalledWith(
        expect.objectContaining({
          type: 'error',
          title: 'Error',
          message: 'Something went wrong',
        })
      );
    });

    it('should show info notification', () => {
      service.showInfo('Info', 'Information message');
      expect(mockHook.show).toHaveBeenCalledWith(
        expect.objectContaining({
          type: 'info',
          title: 'Info',
          message: 'Information message',
        })
      );
    });

    it('should show warning notification', () => {
      service.showWarning('Warning', 'Warning message');
      expect(mockHook.show).toHaveBeenCalledWith(
        expect.objectContaining({
          type: 'warning',
          title: 'Warning',
          message: 'Warning message',
        })
      );
    });

    it('should show download notification', () => {
      service.showDownload('Download', 'Downloading file...');
      expect(mockHook.show).toHaveBeenCalledWith(
        expect.objectContaining({
          type: 'download',
          title: 'Download',
          message: 'Downloading file...',
          duration: 0, // Indefinite
        })
      );
    });

    it('should show playback notification', () => {
      service.showPlayback('Playing', 'Now playing track');
      expect(mockHook.show).toHaveBeenCalledWith(
        expect.objectContaining({
          type: 'playback',
          title: 'Playing',
          message: 'Now playing track',
          duration: 3000,
        })
      );
    });

    it('should dismiss notification', () => {
      service.dismiss('test-id');
      expect(mockHook.hide).toHaveBeenCalledWith('test-id');
    });

    it('should clear all notifications', () => {
      service.clear();
      expect(mockHook.clear).toHaveBeenCalled();
    });
  });

  describe('Playback Notifications', () => {
    it('should show track started notification', () => {
      playbackNotifications.trackStarted('Song Title', 'Artist Name');
      expect(mockHook.show).toHaveBeenCalledWith(
        expect.objectContaining({
          type: 'playback',
          title: '🎵 Now Playing',
          message: 'Song Title by Artist Name',
        })
      );
    });

    it('should show track paused notification', () => {
      playbackNotifications.trackPaused('Song Title');
      expect(mockHook.show).toHaveBeenCalledWith(
        expect.objectContaining({
          type: 'info',
          title: '⏸️ Paused',
          message: 'Song Title',
        })
      );
    });

    it('should show track resumed notification', () => {
      playbackNotifications.trackResumed('Song Title');
      expect(mockHook.show).toHaveBeenCalledWith(
        expect.objectContaining({
          type: 'playback',
          title: '▶️ Resumed',
          message: 'Song Title',
        })
      );
    });

    it('should show track ended notification', () => {
      playbackNotifications.trackEnded('Song Title');
      expect(mockHook.show).toHaveBeenCalledWith(
        expect.objectContaining({
          type: 'info',
          title: '✓ Track Finished',
          message: 'Song Title',
          duration: 2000,
        })
      );
    });
  });

  describe('Download Notifications', () => {
    it('should show download started notification', () => {
      downloadNotifications.downloadStarted('Video Title');
      expect(mockHook.show).toHaveBeenCalledWith(
        expect.objectContaining({
          type: 'download',
          title: '⬇️ Downloading',
          message: expect.stringContaining('Video Title'),
        })
      );
    });

    it('should show download completed notification', () => {
      downloadNotifications.downloadCompleted('Video Title');
      expect(mockHook.show).toHaveBeenCalledWith(
        expect.objectContaining({
          type: 'success',
          title: '✓ Download Complete',
          message: expect.stringContaining('Video Title'),
        })
      );
    });

    it('should show download failed notification', () => {
      downloadNotifications.downloadFailed('Video Title', 'Network error');
      expect(mockHook.show).toHaveBeenCalledWith(
        expect.objectContaining({
          type: 'error',
          title: '✗ Download Failed',
          message: expect.stringContaining('Video Title'),
        })
      );
    });

    it('should show download progress notification', () => {
      downloadNotifications.downloadProgress('Video Title', 0.5);
      expect(mockHook.show).toHaveBeenCalledWith(
        expect.objectContaining({
          type: 'info',
          title: '⬇️ Downloading',
          message: expect.stringContaining('50%'),
        })
      );
    });
  });

  describe('Error Notifications', () => {
    it('should show audio load failed notification', () => {
      errorNotifications.audioLoadFailed('Track Title');
      expect(mockHook.show).toHaveBeenCalledWith(
        expect.objectContaining({
          type: 'error',
          title: '✗ Load Failed',
          message: expect.stringContaining('Track Title'),
        })
      );
    });

    it('should show network error notification', () => {
      errorNotifications.networkError();
      expect(mockHook.show).toHaveBeenCalledWith(
        expect.objectContaining({
          type: 'error',
          title: '✗ Network Error',
        })
      );
    });

    it('should show search failed notification', () => {
      errorNotifications.searchFailed('API error');
      expect(mockHook.show).toHaveBeenCalledWith(
        expect.objectContaining({
          type: 'error',
          title: '✗ Search Failed',
        })
      );
    });

    it('should show API key missing notification', () => {
      errorNotifications.apiKeyMissing();
      expect(mockHook.show).toHaveBeenCalledWith(
        expect.objectContaining({
          type: 'error',
          title: '✗ Configuration Error',
        })
      );
    });
  });

  describe('Feature Notifications', () => {
    it('should show EQ applied notification', () => {
      featureNotifications.eqApplied('Bass Boost');
      expect(mockHook.show).toHaveBeenCalledWith(
        expect.objectContaining({
          type: 'info',
          title: '🎚️ EQ Applied',
          message: 'Preset: Bass Boost',
        })
      );
    });

    it('should show stem silencer activated notification', () => {
      featureNotifications.stemSilencerActivated('Vocals');
      expect(mockHook.show).toHaveBeenCalledWith(
        expect.objectContaining({
          type: 'info',
          title: '🎸 Stem Silencer',
          message: 'Vocals silenced',
        })
      );
    });

    it('should show visualizer changed notification', () => {
      featureNotifications.visualizerChanged('Spectrum Bars');
      expect(mockHook.show).toHaveBeenCalledWith(
        expect.objectContaining({
          type: 'info',
          title: '✨ Visualizer',
          message: 'Spectrum Bars',
        })
      );
    });

    it('should show playlist created notification', () => {
      featureNotifications.playlistCreated('My Playlist');
      expect(mockHook.show).toHaveBeenCalledWith(
        expect.objectContaining({
          type: 'success',
          title: '✓ Playlist Created',
          message: expect.stringContaining('My Playlist'),
        })
      );
    });

    it('should show added to favorites notification', () => {
      featureNotifications.addedToFavorites('Song Title');
      expect(mockHook.show).toHaveBeenCalledWith(
        expect.objectContaining({
          type: 'success',
          title: '❤️ Added to Favorites',
          message: 'Song Title',
        })
      );
    });

    it('should show sleep timer set notification', () => {
      featureNotifications.sleepTimerSet(30);
      expect(mockHook.show).toHaveBeenCalledWith(
        expect.objectContaining({
          type: 'info',
          title: '⏱️ Sleep Timer',
          message: expect.stringContaining('30 minutes'),
        })
      );
    });
  });

  describe('Notification Durations', () => {
    it('should use default durations', () => {
      service.showSuccess('Test', 'Message');
      expect(mockHook.show).toHaveBeenCalledWith(
        expect.objectContaining({
          duration: 3000,
        })
      );
    });

    it('should allow custom durations', () => {
      service.showSuccess('Test', 'Message', 5000);
      expect(mockHook.show).toHaveBeenCalledWith(
        expect.objectContaining({
          duration: 5000,
        })
      );
    });

    it('should support indefinite notifications', () => {
      service.showDownload('Test', 'Message');
      expect(mockHook.show).toHaveBeenCalledWith(
        expect.objectContaining({
          duration: 0,
        })
      );
    });
  });

  describe('Notification Actions', () => {
    it('should support action buttons', () => {
      const action = { label: 'Retry', onPress: vi.fn() };
      service.showDownload('Test', 'Message', action);
      expect(mockHook.show).toHaveBeenCalledWith(
        expect.objectContaining({
          action,
        })
      );
    });

    it('should support notifications without actions', () => {
      service.showSuccess('Test', 'Message');
      expect(mockHook.show).toHaveBeenCalledWith(
        expect.objectContaining({
          type: 'success',
          title: 'Test',
          message: 'Message',
        })
      );
      const lastCall = mockHook.show.mock.calls[mockHook.show.mock.calls.length - 1][0];
      expect(lastCall.action).toBeUndefined();
    });
  });
});
