import { ScrollView, Text, View, TouchableOpacity } from 'react-native';
import { ScreenContainer } from '@/components/screen-container';
import { useColors } from '@/hooks/use-colors';
import MaterialIcons from '@expo/vector-icons/MaterialIcons';
import { ComponentProps } from 'react';
import { useState, useCallback } from 'react';
import { useMusicPlayer } from '@/lib/music-player-context-v2';
import { StemPresetsService } from '@/lib/stem-presets-service';

interface StemControl {
  key: 'drums' | 'guitar' | 'synth' | 'vocals';
  label: string;
  description: string;
  icon: ComponentProps<typeof MaterialIcons>['name'];
}

const STEM_CONTROLS: StemControl[] = [
  {
    key: 'drums',
    label: 'Drums',
    description: 'Remove or reduce drum sounds',
    icon: 'music-note',
  },
  {
    key: 'guitar',
    label: 'Guitar',
    description: 'Remove or reduce guitar sounds',
    icon: 'music-note',
  },
  {
    key: 'synth',
    label: 'Synth',
    description: 'Remove or reduce synthesizer sounds',
    icon: 'music-note',
  },
  {
    key: 'vocals',
    label: 'Vocals',
    description: 'Mute or reduce vocal sounds',
    icon: 'mic',
  },
];

export default function StemsScreen() {
  const colors = useColors();
  const musicPlayer = useMusicPlayer();
  const [drumVolume, setDrumVolume] = useState(musicPlayer.drumVolume);
  const [guitarVolume, setGuitarVolume] = useState(musicPlayer.guitarVolume);
  const [synthVolume, setSynthVolume] = useState(musicPlayer.synthVolume);
  const [vocalVolume, setVocalVolume] = useState(musicPlayer.vocalVolume);

  const handleDrumChange = useCallback(
    (value: number) => {
      setDrumVolume(value);
      musicPlayer.setDrumVolume(value);
    },
    [musicPlayer]
  );

  const handleGuitarChange = useCallback(
    (value: number) => {
      setGuitarVolume(value);
      musicPlayer.setGuitarVolume(value);
    },
    [musicPlayer]
  );

  const handleSynthChange = useCallback(
    (value: number) => {
      setSynthVolume(value);
      musicPlayer.setSynthVolume(value);
    },
    [musicPlayer]
  );

  const handleVocalChange = useCallback(
    (value: number) => {
      setVocalVolume(value);
      musicPlayer.setVocalVolume(value);
    },
    [musicPlayer]
  );

  const handleReset = useCallback(() => {
    setDrumVolume(100);
    setGuitarVolume(100);
    setSynthVolume(100);
    setVocalVolume(100);
    musicPlayer.setDrumVolume(100);
    musicPlayer.setGuitarVolume(100);
    musicPlayer.setSynthVolume(100);
    musicPlayer.setVocalVolume(100);
  }, [musicPlayer]);

  const applyPreset = useCallback(
    (presetId: string) => {
      const preset = StemPresetsService.getPreset(presetId);
      if (preset) {
        setDrumVolume(preset.drumVolume);
        setGuitarVolume(preset.guitarVolume);
        setSynthVolume(preset.synthVolume);
        setVocalVolume(preset.vocalVolume);
        musicPlayer.setDrumVolume(preset.drumVolume);
        musicPlayer.setGuitarVolume(preset.guitarVolume);
        musicPlayer.setSynthVolume(preset.synthVolume);
        musicPlayer.setVocalVolume(preset.vocalVolume);
      }
    },
    [musicPlayer]
  );

  const getStemValue = (key: 'drums' | 'guitar' | 'synth' | 'vocals'): number => {
    switch (key) {
      case 'drums':
        return drumVolume;
      case 'guitar':
        return guitarVolume;
      case 'synth':
        return synthVolume;
      case 'vocals':
        return vocalVolume;
      default:
        return 100;
    }
  };

  const handleStemChange = (key: 'drums' | 'guitar' | 'synth' | 'vocals', value: number) => {
    switch (key) {
      case 'drums':
        handleDrumChange(value);
        break;
      case 'guitar':
        handleGuitarChange(value);
        break;
      case 'synth':
        handleSynthChange(value);
        break;
      case 'vocals':
        handleVocalChange(value);
        break;
    }
  };

  const renderStemSlider = (control: StemControl) => {
    const value = getStemValue(control.key);
    const percentage = (value / 100) * 100;

    return (
      <View key={control.key} className="gap-3">
        <View className="flex-row items-center justify-between">
          <View className="flex-row items-center gap-3 flex-1">
            <MaterialIcons name={control.icon} size={24} color={colors.primary} />
            <View>
              <Text className="text-foreground font-semibold">{control.label}</Text>
              <Text className="text-muted text-xs">{control.description}</Text>
            </View>
          </View>
          <Text className="text-primary font-semibold text-sm">{Math.round(value)}%</Text>
        </View>

        {/* Visual Slider Bar */}
        <View
          style={{
            height: 40,
            justifyContent: 'center',
            backgroundColor: colors.surface,
            borderRadius: 8,
            borderWidth: 1,
            borderColor: colors.border,
          }}
        >
          <View
            style={{
              height: 6,
              backgroundColor: colors.border,
              borderRadius: 3,
              marginHorizontal: 12,
            }}
          >
            {/* Fill bar */}
            <View
              style={{
                height: 6,
                backgroundColor: colors.primary,
                borderRadius: 3,
                width: `${percentage}%`,
              }}
            />
          </View>
        </View>

        {/* Control Buttons */}
        <View className="flex-row gap-2">
          <TouchableOpacity
            onPress={() => handleStemChange(control.key, Math.max(0, value - 10))}
            className="flex-1 py-2 px-3 rounded-lg items-center border"
            style={{ backgroundColor: colors.surface, borderColor: colors.border }}
          >
            <Text className="text-foreground font-semibold text-sm">−10%</Text>
          </TouchableOpacity>

          <TouchableOpacity
            onPress={() => handleStemChange(control.key, 100)}
            className="flex-1 py-2 px-3 rounded-lg items-center border"
            style={{ backgroundColor: colors.surface, borderColor: colors.border }}
          >
            <Text className="text-foreground font-semibold text-sm">Reset</Text>
          </TouchableOpacity>

          <TouchableOpacity
            onPress={() => handleStemChange(control.key, Math.min(100, value + 10))}
            className="flex-1 py-2 px-3 rounded-lg items-center border"
            style={{ backgroundColor: colors.surface, borderColor: colors.border }}
          >
            <Text className="text-foreground font-semibold text-sm">+10%</Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  };

  return (
    <ScreenContainer className="flex-1 bg-background" containerClassName="bg-background">
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ flexGrow: 1 }}>
        {/* Header */}
        <View className="px-6 pt-6 pb-4">
          <Text className="text-2xl font-bold text-foreground">Stem Controls</Text>
          <Text className="text-muted text-sm mt-1">AI-Powered Instrument Silencer</Text>
        </View>

        {/* Presets */}
        <View className="px-6 py-4">
          <Text className="text-lg font-bold text-foreground mb-3">Quick Presets</Text>
          <View className="gap-2">
            {StemPresetsService.getAllPresets().slice(0, 4).map((preset) => (
              <TouchableOpacity
                key={preset.id}
                onPress={() => applyPreset(preset.id)}
                className="py-3 px-4 rounded-lg border"
                style={{ backgroundColor: colors.surface, borderColor: colors.border }}
              >
                <Text className="text-foreground font-semibold text-sm">{preset.name}</Text>
                <Text className="text-muted text-xs mt-1">{preset.description}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Stem Controls */}
        <View className="px-6 py-4 gap-6">
          {STEM_CONTROLS.map((control) => renderStemSlider(control))}
        </View>

        {/* More Presets */}
        <View className="px-6 py-4">
          <Text className="text-lg font-bold text-foreground mb-3">More Presets</Text>
          <View className="gap-2">
            {StemPresetsService.getAllPresets().slice(4).map((preset) => (
              <TouchableOpacity
                key={preset.id}
                onPress={() => applyPreset(preset.id)}
                className="py-3 px-4 rounded-lg border"
                style={{ backgroundColor: colors.surface, borderColor: colors.border }}
              >
                <Text className="text-foreground font-semibold text-sm">{preset.name}</Text>
                <Text className="text-muted text-xs mt-1">{preset.description}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Reset All Button */}
        <View className="px-6 py-4">
          <TouchableOpacity
            onPress={handleReset}
            className="py-3 px-4 rounded-lg items-center border"
            style={{ borderColor: colors.border, backgroundColor: colors.surface }}
          >
            <Text className="text-foreground font-semibold">Reset All Stems</Text>
          </TouchableOpacity>
        </View>

        {/* Info */}
        <View className="px-6 py-4 mb-6">
          <View
            className="p-4 rounded-lg gap-2"
            style={{ backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border }}
          >
            <Text className="text-foreground font-semibold text-sm">How It Works</Text>
            <Text className="text-muted text-xs leading-relaxed">
              The AI stem separator analyzes your music and isolates individual instruments. Adjust each slider to remove or reduce specific sounds. Values from 0-100% control the volume of each instrument. Works best with local audio files.
            </Text>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
