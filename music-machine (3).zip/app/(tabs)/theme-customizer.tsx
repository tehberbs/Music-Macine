import React, { useState } from 'react';
import { ScrollView, View, Text, TouchableOpacity, TextInput, Modal, FlatList, Pressable, ImageBackground } from 'react-native';
import { ScreenContainer } from '@/components/screen-container';
import { useAdvancedTheme } from '@/lib/advanced-theme-context';

export default function ThemeCustomizerScreen() {
  const {
    currentTheme,
    availableThemes,
    selectTheme,
    updateThemeColors,
    updateThemeSpacing,
    createCustomTheme,
    deleteTheme,
    resetToDefault,
  } = useAdvancedTheme();

  const [activeTab, setActiveTab] = useState<'themes' | 'colors' | 'spacing' | 'elements'>('themes');
  const [showColorPicker, setShowColorPicker] = useState(false);
  const [selectedColorKey, setSelectedColorKey] = useState<keyof typeof currentTheme.colors>('primary');
  const [customThemeName, setCustomThemeName] = useState('');
  const [showCreateModal, setShowCreateModal] = useState(false);

  const handleCreateTheme = async () => {
    if (customThemeName.trim()) {
      await createCustomTheme(customThemeName);
      setCustomThemeName('');
      setShowCreateModal(false);
    }
  };

  const handleColorChange = async (color: string) => {
    const newColors = { ...currentTheme.colors, [selectedColorKey]: color };
    await updateThemeColors(newColors);
    setShowColorPicker(false);
  };

  const handleSpacingChange = async (key: keyof typeof currentTheme.spacing, value: number) => {
    const newSpacing = { ...currentTheme.spacing, [key]: value };
    await updateThemeSpacing(newSpacing);
  };

  return (
    <ScreenContainer className="bg-background">
      <ImageBackground
        source={{ uri: currentTheme.backgroundImage }}
        className="flex-1 absolute inset-0 opacity-30"
      />

      <View className="flex-1 relative z-10">
        {/* Header */}
        <View className="p-4 border-b border-border">
          <Text className="text-2xl font-bold text-foreground">Theme Customizer</Text>
          <Text className="text-sm text-muted mt-1">Current: {currentTheme.name}</Text>
        </View>

        {/* Tab Navigation */}
        <View className="flex-row border-b border-border bg-surface">
          {(['themes', 'colors', 'spacing', 'elements'] as const).map((tab) => (
            <TouchableOpacity
              key={tab}
              onPress={() => setActiveTab(tab)}
              className={`flex-1 py-3 border-b-2 ${
                activeTab === tab ? 'border-primary' : 'border-transparent'
              }`}
            >
              <Text
                className={`text-center font-semibold capitalize ${
                  activeTab === tab ? 'text-primary' : 'text-muted'
                }`}
              >
                {tab}
              </Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* Content */}
        <ScrollView className="flex-1 p-4">
          {activeTab === 'themes' && (
            <View className="gap-4">
              <TouchableOpacity
                onPress={() => setShowCreateModal(true)}
                className="bg-primary p-4 rounded-lg mb-4"
              >
                <Text className="text-background font-bold text-center">+ Create Custom Theme</Text>
              </TouchableOpacity>

              <FlatList
                scrollEnabled={false}
                data={availableThemes}
                keyExtractor={(item) => item.id}
                renderItem={({ item }) => (
                  <Pressable
                    onPress={() => selectTheme(item.id)}
                    className={`p-4 rounded-lg mb-3 border-2 ${
                      currentTheme.id === item.id
                        ? 'border-primary bg-primary/10'
                        : 'border-border bg-surface'
                    }`}
                  >
                    <View className="flex-row justify-between items-center">
                      <View className="flex-1">
                        <Text className="text-lg font-bold text-foreground">{item.name}</Text>
                        <Text className="text-xs text-muted capitalize mt-1">{item.type}</Text>
                      </View>
                      {currentTheme.id === item.id && (
                        <Text className="text-primary font-bold">✓</Text>
                      )}
                    </View>
                    {item.type !== 'default' && (
                      <TouchableOpacity
                        onPress={() => deleteTheme(item.id)}
                        className="mt-2 p-2 bg-error/20 rounded"
                      >
                        <Text className="text-error text-xs font-semibold">Delete</Text>
                      </TouchableOpacity>
                    )}
                  </Pressable>
                )}
              />

              <TouchableOpacity onPress={resetToDefault} className="bg-warning p-3 rounded-lg mt-4">
                <Text className="text-background font-bold text-center">Reset to Default</Text>
              </TouchableOpacity>
            </View>
          )}

          {activeTab === 'colors' && (
            <View className="gap-4">
              {(Object.keys(currentTheme.colors) as Array<keyof typeof currentTheme.colors>).map(
                (colorKey) => (
                  <Pressable
                    key={colorKey}
                    onPress={() => {
                      setSelectedColorKey(colorKey);
                      setShowColorPicker(true);
                    }}
                    className="p-4 rounded-lg bg-surface border border-border flex-row items-center gap-3"
                  >
                    <View
                      className="w-12 h-12 rounded-lg border-2 border-border"
                      style={{ backgroundColor: currentTheme.colors[colorKey] }}
                    />
                    <View className="flex-1">
                      <Text className="text-foreground font-semibold capitalize">{colorKey}</Text>
                      <Text className="text-xs text-muted">{currentTheme.colors[colorKey]}</Text>
                    </View>
                    <Text className="text-primary">›</Text>
                  </Pressable>
                )
              )}
            </View>
          )}

          {activeTab === 'spacing' && (
            <View className="gap-4">
              {(Object.keys(currentTheme.spacing) as Array<keyof typeof currentTheme.spacing>).map(
                (spacingKey) => (
                  <View key={spacingKey} className="p-4 rounded-lg bg-surface border border-border">
                    <View className="flex-row justify-between items-center mb-2">
                      <Text className="text-foreground font-semibold capitalize">{spacingKey}</Text>
                      <Text className="text-primary font-bold">{currentTheme.spacing[spacingKey]}px</Text>
                    </View>
                    <View className="flex-row gap-2">
                      {[4, 8, 12, 16, 20, 24, 32].map((value) => (
                        <TouchableOpacity
                          key={value}
                          onPress={() => handleSpacingChange(spacingKey, value)}
                          className={`px-3 py-2 rounded ${
                            currentTheme.spacing[spacingKey] === value
                              ? 'bg-primary'
                              : 'bg-border'
                          }`}
                        >
                          <Text
                            className={
                              currentTheme.spacing[spacingKey] === value
                                ? 'text-background text-xs font-bold'
                                : 'text-foreground text-xs'
                            }
                          >
                            {value}
                          </Text>
                        </TouchableOpacity>
                      ))}
                    </View>
                  </View>
                )
              )}
            </View>
          )}

          {activeTab === 'elements' && (
            <View className="gap-4">
              <View className="p-4 rounded-lg bg-surface border border-border">
                <Text className="text-foreground font-bold mb-3">Navigation Links</Text>
                {currentTheme.navigationLinks.map((link) => (
                  <View key={link.id} className="p-3 bg-background rounded mb-2 flex-row justify-between items-center">
                    <Text className="text-foreground">{link.label}</Text>
                    <Text className="text-xs text-muted">
                      {Math.round(link.position.x * 100)}%, {Math.round(link.position.y * 100)}%
                    </Text>
                  </View>
                ))}
              </View>

              <View className="p-4 rounded-lg bg-surface border border-border">
                <Text className="text-foreground font-bold mb-3">App Features</Text>
                {currentTheme.appFeatures.map((feature) => (
                  <View key={feature.id} className="p-3 bg-background rounded mb-2 flex-row justify-between items-center">
                    <Text className="text-foreground">{feature.name}</Text>
                    <Text className="text-xs text-muted">{feature.visible ? 'Visible' : 'Hidden'}</Text>
                  </View>
                ))}
              </View>
            </View>
          )}
        </ScrollView>
      </View>

      {/* Create Theme Modal */}
      <Modal visible={showCreateModal} transparent animationType="fade">
        <View className="flex-1 bg-black/50 justify-center items-center p-4">
          <View className="bg-surface rounded-lg p-6 w-full max-w-sm">
            <Text className="text-xl font-bold text-foreground mb-4">Create Custom Theme</Text>
            <TextInput
              placeholder="Theme name..."
              value={customThemeName}
              onChangeText={setCustomThemeName}
              placeholderTextColor="#9CA3AF"
              className="bg-background text-foreground p-3 rounded-lg mb-4 border border-border"
            />
            <View className="flex-row gap-2">
              <TouchableOpacity
                onPress={() => setShowCreateModal(false)}
                className="flex-1 bg-border p-3 rounded-lg"
              >
                <Text className="text-foreground font-semibold text-center">Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={handleCreateTheme}
                className="flex-1 bg-primary p-3 rounded-lg"
              >
                <Text className="text-background font-semibold text-center">Create</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      {/* Color Picker Modal */}
      <Modal visible={showColorPicker} transparent animationType="fade">
        <View className="flex-1 bg-black/50 justify-center items-center p-4">
          <View className="bg-surface rounded-lg p-6 w-full max-w-sm">
            <Text className="text-xl font-bold text-foreground mb-4 capitalize">
              Pick {selectedColorKey} Color
            </Text>
            <View className="grid grid-cols-4 gap-2 mb-4">
              {[
                '#FF6B6B', '#4ECDC4', '#45B7D1', '#FFA07A',
                '#98D8C8', '#F7DC6F', '#BB8FCE', '#85C1E2',
                '#F8B88B', '#52B788', '#A8DADC', '#FF6B9D',
              ].map((color) => (
                <TouchableOpacity
                  key={color}
                  onPress={() => handleColorChange(color)}
                  className="w-12 h-12 rounded-lg border-2 border-border"
                  style={{ backgroundColor: color }}
                />
              ))}
            </View>
            <TouchableOpacity
              onPress={() => setShowColorPicker(false)}
              className="bg-primary p-3 rounded-lg"
            >
              <Text className="text-background font-semibold text-center">Done</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </ScreenContainer>
  );
}
