import React, { useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet, TextInput } from 'react-native';
import { ScreenContainer } from '@/components/screen-container';
import MaterialIcons from '@expo/vector-icons/MaterialIcons';

interface Video {
  id: string;
  title: string;
  channel: string;
  duration: string;
  thumbnail: string;
}

const mockVideos: Video[] = [
  { id: '1', title: 'Amazing Space Journey', channel: 'Official Channel', duration: '08:00', thumbnail: '#FF6B35' },
  { id: '2', title: 'Reminiscence', channel: 'Official Channel', duration: '08:00', thumbnail: '#004E89' },
  { id: '3', title: 'Stunning Nature Landscape...', channel: 'Official Channel', duration: '08:00', thumbnail: '#1B998B' },
  { id: '4', title: 'Cosmic Glittering Fendisage', channel: 'Official Channel', duration: '08:00', thumbnail: '#00D9FF' },
  { id: '5', title: 'Futuristic Sci-Fi City', channel: 'Official Channel', duration: '08:00', thumbnail: '#FF9F1C' },
  { id: '6', title: 'Relaxing Ocean Waves...', channel: 'Official Channel', duration: '08:00', thumbnail: '#0099F7' },
];

export default function YouTubeScreen() {
  const [searchQuery, setSearchQuery] = useState('');

  const VideoCard = ({ video }: { video: Video }) => (
    <TouchableOpacity style={styles.videoCard}>
      <View style={[styles.thumbnail, { backgroundColor: video.thumbnail }]}>
        <Text style={styles.duration}>{video.duration}</Text>
      </View>
      <Text style={styles.videoTitle} numberOfLines={2}>{video.title}</Text>
      <Text style={styles.videoChannel} numberOfLines={1}>{video.channel}</Text>
    </TouchableOpacity>
  );

  return (
    <ScreenContainer className="bg-transparent">
      <View style={styles.container}>
        {/* Header */}
        <View style={styles.header}>
          <View style={styles.headerContent}>
            <MaterialIcons name="play-circle" size={28} color="#FF0000" />
            <Text style={styles.headerTitle}>YouTube</Text>
          </View>
          <TouchableOpacity style={styles.searchIcon}>
            <MaterialIcons name="search" size={24} color="#FFD700" />
          </TouchableOpacity>
        </View>

        {/* Search Bar */}
        <View style={styles.searchContainer}>
          <TextInput
            placeholder="Search videos..."
            placeholderTextColor="#A0826D"
            value={searchQuery}
            onChangeText={setSearchQuery}
            style={styles.searchInput}
          />
          {searchQuery && (
            <TouchableOpacity onPress={() => setSearchQuery('')}>
              <MaterialIcons name="close" size={20} color="#FFD700" />
            </TouchableOpacity>
          )}
        </View>

        {/* Video Grid */}
        <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.gridContainer}>
          <View style={styles.videoGrid}>
            {mockVideos.map((video) => (
              <VideoCard key={video.id} video={video} />
            ))}
          </View>
        </ScrollView>
      </View>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 2,
    borderBottomColor: '#D4AF37',
    backgroundColor: '#1a1a1a',
  },
  headerContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#FFD700',
  },
  searchIcon: {
    padding: 8,
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: '#1a1a1a',
    borderBottomWidth: 1,
    borderBottomColor: '#333',
    gap: 8,
  },
  searchInput: {
    flex: 1,
    backgroundColor: '#0d0d0d',
    borderWidth: 1,
    borderColor: '#333',
    borderRadius: 6,
    paddingHorizontal: 12,
    paddingVertical: 8,
    color: '#FFD700',
    fontSize: 14,
  },
  gridContainer: {
    paddingHorizontal: 16,
    paddingVertical: 16,
    paddingBottom: 100,
  },
  videoGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    gap: 12,
  },
  videoCard: {
    width: '48%',
    backgroundColor: '#1a1a1a',
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#333',
    overflow: 'hidden',
  },
  thumbnail: {
    width: '100%',
    aspectRatio: 16 / 9,
    justifyContent: 'flex-end',
    alignItems: 'flex-end',
    padding: 8,
  },
  duration: {
    backgroundColor: 'rgba(0, 0, 0, 0.7)',
    color: '#FFF',
    fontSize: 10,
    fontWeight: 'bold',
    paddingHorizontal: 4,
    paddingVertical: 2,
    borderRadius: 2,
  },
  videoTitle: {
    color: '#FFD700',
    fontSize: 12,
    fontWeight: '500',
    paddingHorizontal: 8,
    paddingTop: 8,
  },
  videoChannel: {
    color: '#A0826D',
    fontSize: 10,
    paddingHorizontal: 8,
    paddingBottom: 8,
  },
});
