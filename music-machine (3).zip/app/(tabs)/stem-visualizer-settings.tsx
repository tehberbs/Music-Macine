import { ScrollView, Text, View, TouchableOpacity, FlatList } from 'react-native';
import { ScreenContainer } from '@/components/screen-container';
import { useColors } from '@/hooks/use-colors';
import MaterialIcons from '@expo/vector-icons/MaterialIcons';
import { useState, useCallback } from 'react';
import { StemVisualizerEngine, StemVisualizerType } from '@/lib/stem-visualizer-engine';

interface StemVisualizerOption {
  type: StemVisualizerType;
  label: string;
  instrument: string;
}

export default function StemVisualizerSettingsScreen() {
  const colors = useColors();
  const [selectedViz, setSelectedViz] = useState<StemVisualizerType>('drum-reactor');
  const [intensity, setIntensity] = useState(70);
  const [speed, setSpeed] = useState(50);
  const [sensitivity, setSensitivity] = useState(80);
  const [opacity, setOpacity] = useState(100);
  const [primaryColor, setPrimaryColor] = useState('#7C3AED');

  const visualizers: StemVisualizerOption[] = [
    { type: 'drum-reactor', label: 'Drum Reactor', instrument: 'Drums & Percussion' },
    { type: 'bass-wave', label: 'Bass Wave', instrument: 'Bass' },
    { type: 'vocal-spectrum', label: 'Vocal Spectrum', instrument: 'Vocals' },
    { type: 'guitar-ripple', label: 'Guitar Ripple', instrument: 'Guitar' },
    { type: 'synth-aurora', label: 'Synth Aurora', instrument: 'Synthesizer' },
    { type: 'piano-cascade', label: 'Piano Cascade', instrument: 'Piano' },
    { type: 'string-harmony', label: 'String Harmony', instrument: 'Strings' },
    { type: 'percussion-burst', label: 'Percussion Burst', instrument: 'Percussion' },
  ];

  const colorOptions = [
    '#7C3AED', // Purple
    '#EC4899', // Pink
    '#06B6D4', // Cyan
    '#10B981', // Green
    '#F59E0B', // Amber
    '#EF4444', // Red
    '#3B82F6', // Blue
    '#8B5CF6', // Violet
  ];

  const handleSelectViz = useCallback((type: StemVisualizerType) => {
    setSelectedViz(type);
  }, []);

  const handleColorSelect = useCallback((color: string) => {
    setPrimaryColor(color);
  }, []);

  const renderVisualizerOption = ({ item }: { item: StemVisualizerOption }) => {
    const isSelected = selectedViz === item.type;
    return (
      <TouchableOpacity
        onPress={() => handleSelectViz(item.type)}
        className="flex-1 py-3 px-3 rounded-lg m-1 items-center"
        style={{
          backgroundColor: isSelected ? colors.primary : colors.surface,
          borderWidth: isSelected ? 2 : 1,
          borderColor: isSelected ? colors.primary : colors.border,
        }}
      >
        <Text
          className="text-xs font-semibold text-center"
          style={{
            color: isSelected ? colors.background : colors.foreground,
          }}
          numberOfLines={2}
        >
          {item.label}
        </Text>
      </TouchableOpacity>
    );
  };

  const renderColorOption = (color: string) => (
    <TouchableOpacity
      key={color}
      onPress={() => handleColorSelect(color)}
      className="rounded-full m-2 border-2"
      style={{
        width: 50,
        height: 50,
        backgroundColor: color,
        borderColor: primaryColor === color ? colors.foreground : 'transparent',
      }}
    />
  );

  const renderSlider = (label: string, value: number, onChange: (v: number) => void, min = 0, max = 100) => {
    const percentage = ((value - min) / (max - min)) * 100;
    return (
      <View className="gap-2">
        <View className="flex-row items-center justify-between">
          <Text className="text-foreground font-semibold text-sm">{label}</Text>
          <Text className="text-primary font-semibold text-sm">{value}%</Text>
        </View>
        <TouchableOpacity
          activeOpacity={0.8}
          style={{
            height: 40,
            justifyContent: 'center',
            backgroundColor: colors.surface,
            borderRadius: 8,
            borderWidth: 1,
            borderColor: colors.border,
          }}
        >
          <View
            style={{
              height: 6,
              backgroundColor: colors.border,
              borderRadius: 3,
              marginHorizontal: 12,
            }}
          >
            <View
              style={{
                height: 6,
                backgroundColor: colors.primary,
                borderRadius: 3,
                width: `${percentage}%`,
              }}
            />
          </View>
        </TouchableOpacity>
      </View>
    );
  };

  const currentViz = visualizers.find((v) => v.type === selectedViz);

  return (
    <ScreenContainer className="flex-1 bg-background" containerClassName="bg-background">
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ flexGrow: 1 }}>
        {/* Header */}
        <View className="px-6 pt-6 pb-4">
          <Text className="text-2xl font-bold text-foreground">AI Stem Visualizer</Text>
          <Text className="text-muted text-sm mt-1">Customize stem-reactive visualizations</Text>
        </View>

        {/* Visualizer Selection */}
        <View className="px-6 py-4">
          <Text className="text-foreground font-semibold mb-3">Choose Stem Visualizer (8 Options)</Text>
          <FlatList
            data={visualizers}
            renderItem={renderVisualizerOption}
            keyExtractor={(item) => item.type}
            numColumns={2}
            scrollEnabled={false}
            contentContainerStyle={{ gap: 4 }}
          />
        </View>

        {/* Current Selection Info */}
        {currentViz && (
          <View className="px-6 py-4">
            <View
              className="p-4 rounded-lg gap-2"
              style={{ backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border }}
            >
              <Text className="text-foreground font-semibold text-sm">{currentViz.label}</Text>
              <Text className="text-muted text-xs">Reacts to: {currentViz.instrument}</Text>
            </View>
          </View>
        )}

        {/* Color Selection */}
        <View className="px-6 py-4">
          <Text className="text-foreground font-semibold mb-3">Primary Color</Text>
          <View className="flex-row flex-wrap justify-center">
            {colorOptions.map((color) => renderColorOption(color))}
          </View>
        </View>

        {/* Sliders */}
        <View className="px-6 py-4 gap-6">
          <Text className="text-foreground font-semibold">Settings</Text>
          {renderSlider('Intensity', intensity, setIntensity)}
          {renderSlider('Speed', speed, setSpeed)}
          {renderSlider('Sensitivity', sensitivity, setSensitivity)}
          {renderSlider('Opacity', opacity, setOpacity)}
        </View>

        {/* Stem Information */}
        <View className="px-6 py-4">
          <View
            className="p-4 rounded-lg gap-3"
            style={{ backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border }}
          >
            <Text className="text-foreground font-semibold text-sm">Stem Detection</Text>
            <View className="gap-2">
              {[
                { name: 'Drums', color: '#FF1744' },
                { name: 'Bass', color: '#1976D2' },
                { name: 'Vocals', color: '#E91E63' },
                { name: 'Guitar', color: '#FF9800' },
                { name: 'Synth', color: '#9C27B0' },
                { name: 'Piano', color: '#2196F3' },
                { name: 'Strings', color: '#4CAF50' },
                { name: 'Percussion', color: '#FF5722' },
              ].map((stem) => (
                <View key={stem.name} className="flex-row items-center gap-3">
                  <View
                    style={{
                      width: 12,
                      height: 12,
                      borderRadius: 6,
                      backgroundColor: stem.color,
                    }}
                  />
                  <Text className="text-muted text-xs flex-1">{stem.name}</Text>
                </View>
              ))}
            </View>
          </View>
        </View>

        {/* Info */}
        <View className="px-6 py-4 mb-6">
          <View
            className="p-4 rounded-lg gap-2"
            style={{ backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border }}
          >
            <Text className="text-foreground font-semibold text-sm">How It Works</Text>
            <Text className="text-muted text-xs leading-relaxed">
              AI stem visualizers analyze your music and react to specific instruments. Each visualizer is tuned to respond to different sounds: drums create rhythmic pulses, bass creates waves, vocals create spectrum changes, and more. Sensitivity controls how responsive the visualization is to detected instruments.
            </Text>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
