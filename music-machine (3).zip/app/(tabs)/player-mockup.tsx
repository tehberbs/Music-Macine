import React, { useState, useEffect } from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet, Dimensions } from 'react-native';
import { ScreenContainer } from '@/components/screen-container';
import MaterialIcons from '@expo/vector-icons/MaterialIcons';
import Animated, { useAnimatedStyle, withRepeat, withTiming, useSharedValue } from 'react-native-reanimated';

const { width } = Dimensions.get('window');

export default function PlayerScreen() {
  const [isPlaying, setIsPlaying] = useState(true);
  const [shuffle, setShuffle] = useState(false);
  const [repeat, setRepeat] = useState<'off' | 'all' | 'one'>('off');

  // Animated equalizer bars
  const bars = Array.from({ length: 10 }, (_, i) => {
    const height = useSharedValue(0.3);

    useEffect(() => {
      height.value = withRepeat(
        withTiming(Math.random() * 0.8 + 0.2, { duration: 300 }),
        -1,
        true
      );
    }, []);

    return height;
  });

  const EqualizerBar = ({ height }: { height: any }) => {
    const animatedStyle = useAnimatedStyle(() => ({
      height: `${height.value * 100}%`,
    }));

    return (
      <Animated.View
        style={[
          styles.equalizerBar,
          animatedStyle,
        ]}
      />
    );
  };

  return (
    <ScreenContainer className="bg-transparent">
      <View style={styles.container}>
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.headerTitle}>Now Playing</Text>
        </View>

        {/* Animated Equalizer */}
        <View style={styles.equalizerContainer}>
          <View style={styles.equalizerWrapper}>
            {bars.map((height, idx) => (
              <EqualizerBar key={idx} height={height} />
            ))}
          </View>
        </View>

        {/* Track Info */}
        <View style={styles.trackInfoBox}>
          <Text style={styles.artistName}>Artist Name</Text>
          <Text style={styles.songName}>Song Name</Text>
        </View>

        {/* Playback Controls */}
        <View style={styles.controlsContainer}>
          <TouchableOpacity
            onPress={() => setShuffle(!shuffle)}
            style={[styles.controlButton, shuffle && styles.controlButtonActive]}
          >
            <MaterialIcons
              name="shuffle"
              size={20}
              color={shuffle ? '#FFD700' : '#A0826D'}
            />
          </TouchableOpacity>

          <TouchableOpacity style={styles.skipButton}>
            <MaterialIcons name="skip-previous" size={24} color="#FFD700" />
          </TouchableOpacity>

          <TouchableOpacity
            onPress={() => setIsPlaying(!isPlaying)}
            style={styles.playButton}
          >
            <MaterialIcons
              name={isPlaying ? 'pause' : 'play-arrow'}
              size={32}
              color="#0d0d0d"
            />
          </TouchableOpacity>

          <TouchableOpacity style={styles.skipButton}>
            <MaterialIcons name="skip-next" size={24} color="#FFD700" />
          </TouchableOpacity>

          <TouchableOpacity
            onPress={() => {
              const nextRepeat = repeat === 'off' ? 'all' : repeat === 'all' ? 'one' : 'off';
              setRepeat(nextRepeat);
            }}
            style={[styles.controlButton, repeat !== 'off' && styles.controlButtonActive]}
          >
            <MaterialIcons
              name={repeat === 'one' ? 'repeat-one' : 'repeat'}
              size={20}
              color={repeat !== 'off' ? '#FFD700' : '#A0826D'}
            />
          </TouchableOpacity>
        </View>

        {/* Time Display */}
        <View style={styles.timeBox}>
          <Text style={styles.timeText}>01:25 / F86</Text>
          <Text style={styles.timeSubtext}>01:37 / 39.66</Text>
        </View>
      </View>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingHorizontal: 16,
    paddingVertical: 16,
  },
  header: {
    paddingVertical: 12,
    borderBottomWidth: 2,
    borderBottomColor: '#D4AF37',
    marginBottom: 24,
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#FFD700',
    textAlign: 'center',
  },
  equalizerContainer: {
    backgroundColor: '#1a1a1a',
    borderWidth: 2,
    borderColor: '#D4AF37',
    borderRadius: 8,
    paddingVertical: 16,
    paddingHorizontal: 12,
    marginBottom: 24,
    height: 120,
    justifyContent: 'center',
  },
  equalizerWrapper: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    justifyContent: 'space-around',
    height: '100%',
    gap: 4,
  },
  equalizerBar: {
    width: '8%',
    backgroundColor: '#00FF00',
    borderRadius: 2,
    minHeight: 4,
  },
  trackInfoBox: {
    backgroundColor: '#1a1a1a',
    borderWidth: 2,
    borderColor: '#D4AF37',
    borderRadius: 8,
    paddingVertical: 16,
    paddingHorizontal: 12,
    marginBottom: 24,
    alignItems: 'center',
  },
  artistName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#FFD700',
  },
  songName: {
    fontSize: 14,
    color: '#A0826D',
    marginTop: 4,
  },
  controlsContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 16,
    marginBottom: 24,
  },
  controlButton: {
    padding: 8,
  },
  controlButtonActive: {
    backgroundColor: '#D4AF37',
    borderRadius: 6,
  },
  skipButton: {
    padding: 8,
  },
  playButton: {
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: '#FFD700',
    justifyContent: 'center',
    alignItems: 'center',
  },
  timeBox: {
    backgroundColor: '#1a1a1a',
    borderWidth: 2,
    borderColor: '#D4AF37',
    borderRadius: 8,
    paddingVertical: 12,
    paddingHorizontal: 12,
    alignItems: 'center',
  },
  timeText: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#00FF00',
  },
  timeSubtext: {
    fontSize: 12,
    color: '#A0826D',
    marginTop: 4,
  },
});
