import { Tabs } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { HapticTab } from "@/components/haptic-tab";
import { Platform, View } from "react-native";
import { useColors } from "@/hooks/use-colors";
import MaterialIcons from "@expo/vector-icons/MaterialIcons";

export default function TabLayout() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const bottomPadding = Platform.OS === "web" ? 12 : Math.max(insets.bottom, 8);
  const tabBarHeight = 64 + bottomPadding;

  return (
    <Tabs
      screenOptions={{
        tabBarActiveTintColor: "#a855f7",
        tabBarInactiveTintColor: "#6b7280",
        headerShown: false,
        tabBarButton: HapticTab,
        tabBarStyle: {
          paddingTop: 8,
          paddingBottom: bottomPadding,
          height: tabBarHeight,
          backgroundColor: "#0f0f1a",
          borderTopColor: "#1e1e3a",
          borderTopWidth: 1,
          elevation: 20,
          shadowColor: "#a855f7",
          shadowOffset: { width: 0, height: -2 },
          shadowOpacity: 0.15,
          shadowRadius: 8,
        },
        tabBarLabelStyle: {
          fontSize: 11,
          fontWeight: "600",
          marginTop: 2,
        },
      }}
    >
      {/* Player */}
      <Tabs.Screen
        name="index"
        options={{
          title: "Player",
          tabBarIcon: ({ color, focused }) => (
            <View style={{ alignItems: "center", justifyContent: "center" }}>
              <MaterialIcons
                name={focused ? "play-circle-filled" : "play-circle-outline"}
                size={28}
                color={color}
              />
            </View>
          ),
        }}
      />

      {/* YouTube */}
      <Tabs.Screen
        name="youtube"
        options={{
          title: "YouTube",
          tabBarIcon: ({ color, focused }) => (
            <View style={{ alignItems: "center", justifyContent: "center" }}>
              <MaterialIcons
                name={focused ? "smart-display" : "smart-display"}
                size={28}
                color={color}
              />
            </View>
          ),
        }}
      />

      {/* Library */}
      <Tabs.Screen
        name="library"
        options={{
          title: "Local Library",
          tabBarIcon: ({ color, focused }) => (
            <View style={{ alignItems: "center", justifyContent: "center" }}>
              <MaterialIcons
                name={focused ? "library-music" : "library-music"}
                size={28}
                color={color}
              />
            </View>
          ),
        }}
      />

      {/* Downloads */}
      <Tabs.Screen
        name="downloads"
        options={{
          title: "Downloads",
          tabBarIcon: ({ color, focused }) => (
            <View style={{ alignItems: "center", justifyContent: "center" }}>
              <MaterialIcons
                name={focused ? "download" : "download"}
                size={28}
                color={color}
              />
            </View>
          ),
        }}
      />

      {/* Settings */}
      <Tabs.Screen
        name="settings"
        options={{
          title: "Settings",
          tabBarIcon: ({ color, focused }) => (
            <View style={{ alignItems: "center", justifyContent: "center" }}>
              <MaterialIcons
                name={focused ? "settings" : "settings"}
                size={28}
                color={color}
              />
            </View>
          ),
        }}
      />

      {/* Hidden Screens - Accessible via Settings navigation */}
      <Tabs.Screen name="equalizer" options={{ href: null, title: "Equalizer" }} />
      <Tabs.Screen name="stems" options={{ href: null, title: "Stems" }} />
      <Tabs.Screen name="visualizer-settings" options={{ href: null, title: "Visualizer Settings" }} />
      <Tabs.Screen name="stem-visualizer-settings" options={{ href: null, title: "Stem Visualizer Settings" }} />
      <Tabs.Screen name="now-playing" options={{ href: null, title: "Now Playing" }} />
      <Tabs.Screen name="favorites" options={{ href: null, title: "Favorites" }} />
      <Tabs.Screen name="offline" options={{ href: null, title: "Offline" }} />
      <Tabs.Screen name="visualizations" options={{ href: null, title: "Visualizations" }} />
      <Tabs.Screen name="playlists" options={{ href: null, title: "Playlists" }} />
      <Tabs.Screen name="playback" options={{ href: null, title: "Playback" }} />
      <Tabs.Screen name="search" options={{ href: null, title: "Search" }} />
      <Tabs.Screen name="player-mockup" options={{ href: null, title: "Player Mockup" }} />
    </Tabs>
  );
}
