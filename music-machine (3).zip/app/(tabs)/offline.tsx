import { ScrollView, Text, View, TouchableOpacity, FlatList } from 'react-native';
import { ScreenContainer } from '@/components/screen-container';
import { useColors } from '@/hooks/use-colors';
import MaterialIcons from '@expo/vector-icons/MaterialIcons';
import { useState, useEffect, useCallback } from 'react';
import { useMusicPlayer } from '@/lib/music-player-context-v2';
import { OfflineCacheService, type CachedTrack } from '@/lib/offline-cache-service';

export default function OfflineScreen() {
  const colors = useColors();
  const musicPlayer = useMusicPlayer();
  const [cachedTracks, setCachedTracks] = useState<CachedTrack[]>([]);
  const [cacheSize, setCacheSize] = useState<string>('0 MB');
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadCachedTracks();
  }, []);

  const loadCachedTracks = async () => {
    try {
      setIsLoading(true);
      await OfflineCacheService.initializeCache();

      const tracks = await OfflineCacheService.getOfflineAvailableTracks();
      const size = await OfflineCacheService.getCacheSizeFormatted();

      setCachedTracks(tracks);
      setCacheSize(size);
    } catch (error) {
      console.error('Failed to load cached tracks:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handlePlayTrack = useCallback(
    (track: CachedTrack) => {
      musicPlayer.playTrack({
        id: track.id,
        title: track.title,
        artist: track.artist,
        duration: 0,
        uri: track.localPath,
      });
    },
    [musicPlayer]
  );

  const handleRemoveTrack = useCallback(
    async (trackId: string) => {
      await OfflineCacheService.removeFromCache(trackId);
      setCachedTracks(cachedTracks.filter((t) => t.id !== trackId));

      const size = await OfflineCacheService.getCacheSizeFormatted();
      setCacheSize(size);
    },
    [cachedTracks]
  );

  const handleClearCache = useCallback(async () => {
    await OfflineCacheService.clearCache();
    setCachedTracks([]);
    setCacheSize('0 MB');
  }, []);

  const formatFileSize = (bytes: number): string => {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return Math.round((bytes / Math.pow(k, i)) * 100) / 100 + ' ' + sizes[i];
  };

  const renderCachedTrack = ({ item }: { item: CachedTrack }) => (
    <TouchableOpacity
      onPress={() => handlePlayTrack(item)}
      className="px-4 py-3 border-b flex-row items-center justify-between"
      style={{ borderColor: colors.border }}
    >
      <View className="flex-row items-center gap-3 flex-1">
        <View
          className="w-12 h-12 rounded-lg items-center justify-center"
          style={{ backgroundColor: colors.surface }}
        >
          <MaterialIcons name="download-done" size={24} color={colors.primary} />
        </View>
        <View className="flex-1">
          <Text className="text-foreground font-semibold" numberOfLines={1}>
            {item.title}
          </Text>
          <Text className="text-muted text-xs mt-1">{formatFileSize(item.fileSize)}</Text>
        </View>
      </View>
      <TouchableOpacity onPress={() => handleRemoveTrack(item.id)} className="p-2">
        <MaterialIcons name="delete" size={20} color={colors.error} />
      </TouchableOpacity>
    </TouchableOpacity>
  );

  return (
    <ScreenContainer className="flex-1 bg-background" containerClassName="bg-background">
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View className="px-6 pt-6 pb-4">
          <Text className="text-2xl font-bold text-foreground">Offline Downloads</Text>
          <Text className="text-muted text-sm mt-1">Play music without internet</Text>
        </View>

        {isLoading ? (
          <View className="flex-1 items-center justify-center py-8">
            <MaterialIcons name="cloud-download" size={48} color={colors.muted} />
            <Text className="text-muted mt-4">Loading...</Text>
          </View>
        ) : (
          <>
            {/* Cache Info */}
            <View className="px-6 pb-6 gap-3">
              <View
                className="p-4 rounded-lg gap-3"
                style={{ backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border }}
              >
                <View className="flex-row items-center justify-between">
                  <View className="flex-row items-center gap-2">
                    <MaterialIcons name="storage" size={20} color={colors.primary} />
                    <Text className="text-foreground font-semibold">Cache Size</Text>
                  </View>
                  <Text className="text-primary font-bold">{cacheSize}</Text>
                </View>

                <View className="flex-row items-center justify-between">
                  <View className="flex-row items-center gap-2">
                    <MaterialIcons name="music-note" size={20} color={colors.primary} />
                    <Text className="text-foreground font-semibold">Cached Tracks</Text>
                  </View>
                  <Text className="text-primary font-bold">{cachedTracks.length}</Text>
                </View>

                {cachedTracks.length > 0 && (
                  <TouchableOpacity
                    onPress={handleClearCache}
                    className="mt-2 py-2 px-3 rounded-lg items-center border"
                    style={{ borderColor: colors.error, backgroundColor: 'transparent' }}
                  >
                    <Text className="text-error font-semibold text-sm">Clear All Cache</Text>
                  </TouchableOpacity>
                )}
              </View>
            </View>

            {/* Cached Tracks */}
            <View className="pb-6">
              <View className="px-6 py-3">
                <Text className="text-lg font-bold text-foreground">Downloaded Tracks</Text>
              </View>

              {cachedTracks.length > 0 ? (
                <FlatList
                  data={cachedTracks}
                  renderItem={renderCachedTrack}
                  keyExtractor={(item) => item.id}
                  scrollEnabled={false}
                  nestedScrollEnabled={false}
                />
              ) : (
                <View className="px-6 py-8 items-center">
                  <MaterialIcons name="cloud-download" size={48} color={colors.muted} />
                  <Text className="text-muted mt-4 text-center">No offline downloads</Text>
                  <Text className="text-muted text-xs mt-2 text-center">
                    Download videos from YouTube to play offline
                  </Text>
                </View>
              )}
            </View>
          </>
        )}
      </ScrollView>
    </ScreenContainer>
  );
}
