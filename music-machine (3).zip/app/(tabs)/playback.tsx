import {
  Text,
  View,
  TouchableOpacity,
  FlatList,
  TextInput,
  StyleSheet,
  ActivityIndicator,
} from 'react-native';
import { ScreenContainer } from '@/components/screen-container';
import MaterialIcons from '@expo/vector-icons/MaterialIcons';
import { useState, useEffect, useCallback } from 'react';
import { useMusicPlayer } from '@/lib/music-player-context-v2';
import { getMediaLibraryService, type AudioFile } from '@/lib/media-library-service';

function formatTime(seconds: number): string {
  if (!seconds || isNaN(seconds)) return '0:00';
  const m = Math.floor(seconds / 60);
  const s = Math.floor(seconds % 60);
  return `${m}:${s.toString().padStart(2, '0')}`;
}

const PURPLE = '#a855f7';
const CYAN = '#22d3ee';
const BG = '#0f0f1a';
const SURFACE = '#1a1a2e';
const BORDER = '#1e1e3a';
const TEXT = '#f1f5f9';
const MUTED = '#64748b';

export default function PlaybackScreen() {
  const musicPlayer = useMusicPlayer();
  const [tracks, setTracks] = useState<AudioFile[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [permissionDenied, setPermissionDenied] = useState(false);

  useEffect(() => {
    loadAudioFiles();
  }, []);

  const loadAudioFiles = async () => {
    setIsLoading(true);
    setPermissionDenied(false);
    try {
      const svc = getMediaLibraryService();
      const files = await svc.getAudioFiles();
      if (files.length === 0) {
        setPermissionDenied(true);
      }
      setTracks(files);
    } catch (error) {
      console.error('[Library] Failed to load audio files:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const filtered = searchQuery.trim()
    ? tracks.filter(
        (t) =>
          (t.title || t.filename).toLowerCase().includes(searchQuery.toLowerCase()) ||
          (t.artist ?? '').toLowerCase().includes(searchQuery.toLowerCase())
      )
    : tracks;

  const toTrack = (t: AudioFile) => ({
    id: t.id,
    title: t.title || t.filename,
    artist: t.artist || 'Unknown Artist',
    album: t.album,
    duration: t.duration || 0,
    uri: t.uri,
  });

  const handlePlay = useCallback(
    (file: AudioFile) => {
      const queue = filtered.map(toTrack);
      musicPlayer.playTrack(toTrack(file), queue);
    },
    [musicPlayer, filtered]
  );

  const handlePlayAll = useCallback(() => {
    if (filtered.length === 0) return;
    const queue = filtered.map(toTrack);
    musicPlayer.playTrack(queue[0], queue);
  }, [musicPlayer, filtered]);

  const renderItem = ({ item, index }: { item: AudioFile; index: number }) => {
    const isActive = musicPlayer.currentTrack?.id === item.id;
    return (
      <TouchableOpacity
        style={[styles.trackRow, isActive && styles.trackRowActive]}
        onPress={() => handlePlay(item)}
        activeOpacity={0.7}
      >
        <View style={[styles.trackNum, { backgroundColor: isActive ? PURPLE : SURFACE }]}>
          {isActive && musicPlayer.isPlaying ? (
            <MaterialIcons name="graphic-eq" size={18} color="#fff" />
          ) : (
            <Text style={[styles.trackNumText, { color: isActive ? '#fff' : MUTED }]}>
              {index + 1}
            </Text>
          )}
        </View>
        <View style={styles.trackMeta}>
          <Text
            style={[styles.trackTitle, { color: isActive ? PURPLE : TEXT }]}
            numberOfLines={1}
          >
            {item.title || item.filename}
          </Text>
          <Text style={styles.trackArtist} numberOfLines={1}>
            {item.artist || 'Unknown Artist'}
          </Text>
        </View>
        <Text style={styles.trackDur}>{formatTime(item.duration)}</Text>
      </TouchableOpacity>
    );
  };

  return (
    <ScreenContainer containerClassName="flex-1" style={{ backgroundColor: BG }}>
      {/* Header */}
      <View style={styles.header}>
        <View>
          <Text style={styles.headerTitle}>Library</Text>
          <Text style={styles.headerSub}>
            {isLoading ? 'Loading...' : `${filtered.length} tracks`}
          </Text>
        </View>
        <View style={styles.headerActions}>
          {filtered.length > 0 && (
            <TouchableOpacity style={styles.playAllBtn} onPress={handlePlayAll}>
              <MaterialIcons name="play-arrow" size={18} color="#fff" />
              <Text style={styles.playAllText}>Play All</Text>
            </TouchableOpacity>
          )}
          <TouchableOpacity style={styles.refreshBtn} onPress={loadAudioFiles}>
            <MaterialIcons name="refresh" size={22} color={PURPLE} />
          </TouchableOpacity>
        </View>
      </View>

      {/* Search */}
      <View style={styles.searchWrap}>
        <MaterialIcons name="search" size={20} color={MUTED} />
        <TextInput
          placeholder="Search tracks..."
          placeholderTextColor={MUTED}
          value={searchQuery}
          onChangeText={setSearchQuery}
          style={styles.searchInput}
        />
        {searchQuery.length > 0 && (
          <TouchableOpacity onPress={() => setSearchQuery('')}>
            <MaterialIcons name="close" size={18} color={MUTED} />
          </TouchableOpacity>
        )}
      </View>

      {/* Content */}
      {isLoading ? (
        <View style={styles.centered}>
          <ActivityIndicator size="large" color={PURPLE} />
          <Text style={styles.centeredText}>Loading your library...</Text>
        </View>
      ) : permissionDenied ? (
        <View style={styles.centered}>
          <MaterialIcons name="lock" size={56} color={MUTED} />
          <Text style={styles.centeredTitle}>Permission Required</Text>
          <Text style={styles.centeredText}>
            Music Machine needs access to your media files to show your library.
          </Text>
          <TouchableOpacity style={styles.permBtn} onPress={loadAudioFiles}>
            <Text style={styles.permBtnText}>Grant Permission</Text>
          </TouchableOpacity>
        </View>
      ) : filtered.length === 0 ? (
        <View style={styles.centered}>
          <MaterialIcons name="library-music" size={56} color={MUTED} />
          <Text style={styles.centeredTitle}>
            {searchQuery ? 'No Results' : 'No Audio Files Found'}
          </Text>
          <Text style={styles.centeredText}>
            {searchQuery
              ? `No tracks match "${searchQuery}"`
              : 'Add MP3 or audio files to your device to see them here.'}
          </Text>
        </View>
      ) : (
        <FlatList
          data={filtered}
          renderItem={renderItem}
          keyExtractor={(item) => item.id}
          showsVerticalScrollIndicator={false}
          contentContainerStyle={{ paddingBottom: 100 }}
        />
      )}

      {/* Mini Now Playing */}
      {musicPlayer.currentTrack && (
        <View style={styles.nowPlaying}>
          <View style={styles.nowPlayingIcon}>
            <MaterialIcons name="music-note" size={20} color="#fff" />
          </View>
          <View style={styles.nowPlayingInfo}>
            <Text style={styles.nowPlayingTitle} numberOfLines={1}>
              {musicPlayer.currentTrack.title}
            </Text>
            <Text style={styles.nowPlayingArtist} numberOfLines={1}>
              {musicPlayer.currentTrack.artist} • {formatTime(musicPlayer.currentTime)}
            </Text>
          </View>
          <TouchableOpacity
            onPress={musicPlayer.isPlaying ? musicPlayer.pauseTrack : musicPlayer.resumeTrack}
            style={styles.nowPlayingBtn}
          >
            <MaterialIcons
              name={musicPlayer.isPlaying ? 'pause' : 'play-arrow'}
              size={28}
              color={PURPLE}
            />
          </TouchableOpacity>
        </View>
      )}
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 12,
  },
  headerTitle: { fontSize: 26, fontWeight: '800', color: TEXT },
  headerSub: { fontSize: 13, color: MUTED, marginTop: 2 },
  headerActions: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  playAllBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: PURPLE,
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 20,
  },
  playAllText: { color: '#fff', fontWeight: '700', fontSize: 13 },
  refreshBtn: { padding: 8 },
  searchWrap: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    marginHorizontal: 20,
    marginBottom: 12,
    paddingHorizontal: 14,
    paddingVertical: 10,
    backgroundColor: SURFACE,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: BORDER,
  },
  searchInput: { flex: 1, fontSize: 15, color: TEXT },
  trackRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 12,
    gap: 12,
    borderBottomWidth: 1,
    borderBottomColor: BORDER,
  },
  trackRowActive: { backgroundColor: 'rgba(168,85,247,0.08)' },
  trackNum: {
    width: 36,
    height: 36,
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
  },
  trackNumText: { fontSize: 14, fontWeight: '600' },
  trackMeta: { flex: 1 },
  trackTitle: { fontSize: 15, fontWeight: '600', lineHeight: 20 },
  trackArtist: { fontSize: 12, color: MUTED, marginTop: 2 },
  trackDur: { fontSize: 12, color: MUTED },
  centered: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 12, padding: 32 },
  centeredTitle: { fontSize: 18, fontWeight: '700', color: TEXT, textAlign: 'center' },
  centeredText: { fontSize: 14, color: MUTED, textAlign: 'center', lineHeight: 20 },
  permBtn: {
    backgroundColor: PURPLE,
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 24,
    marginTop: 8,
  },
  permBtnText: { color: '#fff', fontWeight: '700', fontSize: 15 },
  nowPlaying: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    paddingHorizontal: 20,
    paddingVertical: 12,
    backgroundColor: SURFACE,
    borderTopWidth: 1,
    borderTopColor: BORDER,
  },
  nowPlayingIcon: {
    width: 40,
    height: 40,
    borderRadius: 10,
    backgroundColor: PURPLE,
    alignItems: 'center',
    justifyContent: 'center',
  },
  nowPlayingInfo: { flex: 1 },
  nowPlayingTitle: { fontSize: 14, fontWeight: '600', color: TEXT },
  nowPlayingArtist: { fontSize: 12, color: MUTED, marginTop: 2 },
  nowPlayingBtn: { padding: 4 },
});
