import { ScrollView, Text, View, TouchableOpacity, FlatList } from 'react-native';
import { ScreenContainer } from '@/components/screen-container';
import { useColors } from '@/hooks/use-colors';
import MaterialIcons from '@expo/vector-icons/MaterialIcons';
import { useState, useEffect, useCallback } from 'react';
import { useMusicPlayer } from '@/lib/music-player-context-v2';
import { FavoritesService, type FavoriteTrack } from '@/lib/favorites-service';
import { RecentlyPlayedService } from '@/lib/recently-played-service';

export default function FavoritesScreen() {
  const colors = useColors();
  const musicPlayer = useMusicPlayer();
  const [favorites, setFavorites] = useState<FavoriteTrack[]>([]);
  const [topPlayed, setTopPlayed] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [stats, setStats] = useState<any>(null);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      setIsLoading(true);
      const favs = await FavoritesService.getFavorites();
      const top = await RecentlyPlayedService.getTopPlayed(5);
      const statistics = await RecentlyPlayedService.getStatistics();

      setFavorites(favs);
      setTopPlayed(top);
      setStats(statistics);
    } catch (error) {
      console.error('Failed to load data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handlePlayTrack = useCallback(
    (track: FavoriteTrack) => {
      musicPlayer.playTrack({
        id: track.id,
        title: track.title,
        artist: track.artist,
        duration: 0,
        uri: track.uri,
      });
    },
    [musicPlayer]
  );

  const handleRemoveFavorite = useCallback(
    async (trackId: string) => {
      await FavoritesService.removeFavorite(trackId);
      setFavorites(favorites.filter((t) => t.id !== trackId));
    },
    [favorites]
  );

  const renderFavoriteItem = ({ item }: { item: FavoriteTrack }) => (
    <TouchableOpacity
      onPress={() => handlePlayTrack(item)}
      className="px-4 py-3 border-b flex-row items-center justify-between"
      style={{ borderColor: colors.border }}
    >
      <View className="flex-row items-center gap-3 flex-1">
        <View
          className="w-12 h-12 rounded-lg items-center justify-center"
          style={{ backgroundColor: colors.surface }}
        >
          <MaterialIcons name="favorite" size={24} color={colors.primary} />
        </View>
        <View className="flex-1">
          <Text className="text-foreground font-semibold" numberOfLines={1}>
            {item.title}
          </Text>
          <Text className="text-muted text-xs mt-1">{item.artist}</Text>
        </View>
      </View>
      <TouchableOpacity onPress={() => handleRemoveFavorite(item.id)} className="p-2">
        <MaterialIcons name="close" size={20} color={colors.error} />
      </TouchableOpacity>
    </TouchableOpacity>
  );

  const renderTopPlayedItem = ({ item }: { item: any }) => (
    <TouchableOpacity
      onPress={() => handlePlayTrack(item)}
      className="px-4 py-3 border-b flex-row items-center gap-3"
      style={{ borderColor: colors.border }}
    >
      <View
        className="w-10 h-10 rounded-lg items-center justify-center"
        style={{ backgroundColor: colors.surface }}
      >
        <MaterialIcons name="play-arrow" size={20} color={colors.primary} />
      </View>
      <View className="flex-1">
        <Text className="text-foreground font-semibold text-sm" numberOfLines={1}>
          {item.title}
        </Text>
        <Text className="text-muted text-xs">{item.playCount} plays</Text>
      </View>
    </TouchableOpacity>
  );

  return (
    <ScreenContainer className="flex-1 bg-background" containerClassName="bg-background">
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View className="px-6 pt-6 pb-4">
          <Text className="text-2xl font-bold text-foreground">Your Music</Text>
          <Text className="text-muted text-sm mt-1">Favorites & Recently Played</Text>
        </View>

        {isLoading ? (
          <View className="flex-1 items-center justify-center py-8">
            <MaterialIcons name="music-note" size={48} color={colors.muted} />
            <Text className="text-muted mt-4">Loading...</Text>
          </View>
        ) : (
          <>
            {/* Statistics */}
            {stats && (
              <View className="px-6 pb-6 gap-3">
                <View
                  className="p-4 rounded-lg gap-2"
                  style={{ backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border }}
                >
                  <View className="flex-row justify-between items-center">
                    <Text className="text-foreground font-semibold">Total Plays</Text>
                    <Text className="text-primary font-bold text-lg">{stats.totalPlays}</Text>
                  </View>
                  <View className="flex-row justify-between items-center">
                    <Text className="text-foreground font-semibold">Unique Tracks</Text>
                    <Text className="text-primary font-bold text-lg">{stats.totalTracks}</Text>
                  </View>
                  <View className="flex-row justify-between items-center">
                    <Text className="text-foreground font-semibold">Avg Plays/Track</Text>
                    <Text className="text-primary font-bold text-lg">
                      {stats.averagePlaysPerTrack.toFixed(1)}
                    </Text>
                  </View>
                </View>
              </View>
            )}

            {/* Top Played */}
            {topPlayed.length > 0 && (
              <View className="pb-6">
                <View className="px-6 py-3">
                  <Text className="text-lg font-bold text-foreground">Top Played</Text>
                </View>
                <FlatList
                  data={topPlayed}
                  renderItem={renderTopPlayedItem}
                  keyExtractor={(item) => item.id}
                  scrollEnabled={false}
                  nestedScrollEnabled={false}
                />
              </View>
            )}

            {/* Favorites */}
            <View className="pb-6">
              <View className="px-6 py-3 flex-row items-center justify-between">
                <Text className="text-lg font-bold text-foreground">Favorites ({favorites.length})</Text>
                {favorites.length > 0 && (
                  <TouchableOpacity onPress={loadData}>
                    <MaterialIcons name="refresh" size={20} color={colors.primary} />
                  </TouchableOpacity>
                )}
              </View>

              {favorites.length > 0 ? (
                <FlatList
                  data={favorites}
                  renderItem={renderFavoriteItem}
                  keyExtractor={(item) => item.id}
                  scrollEnabled={false}
                  nestedScrollEnabled={false}
                />
              ) : (
                <View className="px-6 py-8 items-center">
                  <MaterialIcons name="favorite-border" size={48} color={colors.muted} />
                  <Text className="text-muted mt-4 text-center">No favorites yet</Text>
                  <Text className="text-muted text-xs mt-2 text-center">
                    Heart your favorite tracks to see them here
                  </Text>
                </View>
              )}
            </View>
          </>
        )}
      </ScrollView>
    </ScreenContainer>
  );
}
