import React, { useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet, FlatList } from 'react-native';
import { ScreenContainer } from '@/components/screen-container';
import MaterialIcons from '@expo/vector-icons/MaterialIcons';

interface Download {
  id: string;
  name: string;
  progress: number;
  size: string;
  status: 'downloading' | 'completed' | 'paused';
}

const mockDownloads: Download[] = [
  { id: '1', name: 'Latest Single.mp3', progress: 62, size: 'TGB 7 | 67 109.00', status: 'downloading' },
  { id: '2', name: 'Music Video.mp4', progress: 30, size: 'TGB 7 | 67 109.00', status: 'downloading' },
  { id: '3', name: 'Latest Album.zip', progress: 18, size: 'TGB 7 | 67 109.00', status: 'downloading' },
  { id: '4', name: 'Full Concert.mp', progress: 100, size: 'TGB 7 | 67 109.00', status: 'completed' },
  { id: '5', name: 'Promo Image.png', progress: 100, size: 'TGB 7 | 67 109.00', status: 'completed' },
  { id: '6', name: 'Essentials Playlist.flac', progress: 100, size: 'TGB 7 | 67 109.00', status: 'completed' },
  { id: '7', name: 'Software Update.exe', progress: 100, size: 'TGB 7 | 67 109.00', status: 'completed' },
];

export default function DownloadsScreen() {
  const [downloads, setDownloads] = useState(mockDownloads);

  const DownloadItem = ({ download }: { download: Download }) => (
    <View style={styles.downloadItem}>
      <View style={styles.downloadInfo}>
        <View style={styles.downloadIcon}>
          <MaterialIcons
            name={download.status === 'completed' ? 'check-circle' : 'download'}
            size={20}
            color={download.status === 'completed' ? '#4CAF50' : '#FFD700'}
          />
        </View>
        <View style={styles.downloadDetails}>
          <Text style={styles.downloadName}>{download.name}</Text>
          <View style={styles.progressContainer}>
            <View style={styles.progressBar}>
              <View
                style={[
                  styles.progressFill,
                  {
                    width: `${download.progress}%`,
                    backgroundColor:
                      download.status === 'completed'
                        ? '#4CAF50'
                        : download.progress > 50
                        ? '#FFD700'
                        : '#FF9F1C',
                  },
                ]}
              />
            </View>
          </View>
        </View>
      </View>
      <View style={styles.downloadMeta}>
        <Text style={styles.downloadProgress}>
          {download.status === 'completed' ? 'Downloaded' : `${download.progress}%`}
        </Text>
        <Text style={styles.downloadSize}>{download.size}</Text>
        <TouchableOpacity style={styles.downloadAction}>
          <MaterialIcons
            name={download.status === 'completed' ? 'more-vert' : 'pause'}
            size={20}
            color="#FFD700"
          />
        </TouchableOpacity>
      </View>
    </View>
  );

  return (
    <ScreenContainer className="bg-transparent">
      <View style={styles.container}>
        {/* Header */}
        <View style={styles.header}>
          <MaterialIcons name="download" size={24} color="#FFD700" />
          <Text style={styles.headerTitle}>Download Manager</Text>
          <View style={{ width: 24 }} />
        </View>

        {/* Downloads List */}
        <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.listContainer}>
          <View style={styles.downloadBox}>
            <FlatList
              scrollEnabled={false}
              data={downloads}
              keyExtractor={(item) => item.id}
              renderItem={({ item }) => <DownloadItem download={item} />}
            />
          </View>

          {/* Download Stats */}
          <View style={styles.statsContainer}>
            <View style={styles.statBox}>
              <Text style={styles.statLabel}>Downloaded</Text>
              <Text style={styles.statValue}>
                {downloads.filter((d) => d.status === 'completed').length}
              </Text>
            </View>
            <View style={styles.statBox}>
              <Text style={styles.statLabel}>Downloading</Text>
              <Text style={styles.statValue}>
                {downloads.filter((d) => d.status === 'downloading').length}
              </Text>
            </View>
          </View>
        </ScrollView>
      </View>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 2,
    borderBottomColor: '#D4AF37',
    backgroundColor: '#1a1a1a',
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#FFD700',
    flex: 1,
    textAlign: 'center',
  },
  listContainer: {
    paddingHorizontal: 16,
    paddingVertical: 16,
    paddingBottom: 100,
  },
  downloadBox: {
    backgroundColor: '#1a1a1a',
    borderWidth: 2,
    borderColor: '#D4AF37',
    borderRadius: 8,
    overflow: 'hidden',
    marginBottom: 16,
  },
  downloadItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 12,
    paddingHorizontal: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#333',
  },
  downloadInfo: {
    flexDirection: 'row',
    flex: 1,
    gap: 12,
  },
  downloadIcon: {
    width: 24,
    height: 24,
    justifyContent: 'center',
    alignItems: 'center',
  },
  downloadDetails: {
    flex: 1,
    gap: 4,
  },
  downloadName: {
    color: '#FFD700',
    fontSize: 12,
    fontWeight: '500',
  },
  progressContainer: {
    gap: 4,
  },
  progressBar: {
    height: 4,
    backgroundColor: '#333',
    borderRadius: 2,
    overflow: 'hidden',
  },
  progressFill: {
    height: '100%',
  },
  downloadMeta: {
    alignItems: 'flex-end',
    gap: 4,
  },
  downloadProgress: {
    color: '#4CAF50',
    fontSize: 11,
    fontWeight: 'bold',
  },
  downloadSize: {
    color: '#A0826D',
    fontSize: 10,
  },
  downloadAction: {
    padding: 4,
  },
  statsContainer: {
    flexDirection: 'row',
    gap: 12,
  },
  statBox: {
    flex: 1,
    backgroundColor: '#1a1a1a',
    borderWidth: 2,
    borderColor: '#D4AF37',
    borderRadius: 8,
    paddingVertical: 16,
    alignItems: 'center',
  },
  statLabel: {
    color: '#A0826D',
    fontSize: 12,
    fontWeight: '500',
  },
  statValue: {
    color: '#FFD700',
    fontSize: 20,
    fontWeight: 'bold',
    marginTop: 4,
  },
});
