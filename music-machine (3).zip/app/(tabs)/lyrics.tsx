import React, { useState, useEffect } from 'react';
import { View, Text, ScrollView, ActivityIndicator, Pressable } from 'react-native';
import { ScreenContainer } from '@/components/screen-container';
import { useMusicPlayer } from '@/lib/music-player-context-v2';
import { lyricsService, type LyricsData } from '@/lib/lyrics-service';
import MaterialIcons from '@expo/vector-icons/MaterialIcons';

export default function LyricsScreen() {
  const musicPlayer = useMusicPlayer();
  const [lyrics, setLyrics] = useState<LyricsData | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Fetch lyrics when track changes
  useEffect(() => {
    if (!musicPlayer.currentTrack) {
      setLyrics(null);
      return;
    }

        const fetchLyrics = async () => {
          setLoading(true);
          setError(null);

          try {
            if (!musicPlayer.currentTrack) return;
            const result = await lyricsService.searchLyrics(
              musicPlayer.currentTrack.title,
              musicPlayer.currentTrack.artist || 'Unknown'
            );

        if (result) {
          setLyrics(result);
        } else {
          setError('Lyrics not found');
        }
      } catch (err) {
        console.error('[LyricsScreen] Error fetching lyrics:', err);
        setError('Failed to fetch lyrics');
      } finally {
        setLoading(false);
      }
    };

    fetchLyrics();
  }, [musicPlayer.currentTrack]);

  return (
    <ScreenContainer className="bg-background">
      <View className="flex-1 bg-background">
        {/* Header */}
        <View className="border-b border-border px-4 py-4">
          <Text className="text-xl font-bold text-foreground">Lyrics</Text>
          {musicPlayer.currentTrack && (
            <View className="mt-2">
              <Text className="text-base font-semibold text-foreground">
                {musicPlayer.currentTrack.title}
              </Text>
              <Text className="text-sm text-muted">{musicPlayer.currentTrack.artist}</Text>
            </View>
          )}
        </View>

        {/* Content */}
        {!musicPlayer.currentTrack ? (
          <View className="flex-1 items-center justify-center">
            <MaterialIcons name="music-note" size={48} color="#999" />
            <Text className="mt-4 text-center text-muted">No track playing</Text>
          </View>
        ) : loading ? (
          <View className="flex-1 items-center justify-center">
            <ActivityIndicator size="large" color="#a78bfa" />
            <Text className="mt-4 text-muted">Fetching lyrics...</Text>
          </View>
        ) : error ? (
          <View className="flex-1 items-center justify-center px-4">
            <MaterialIcons name="error-outline" size={48} color="#ef4444" />
            <Text className="mt-4 text-center text-error">{error}</Text>
            <Pressable
              onPress={() => {
                if (musicPlayer.currentTrack) {
                  setLoading(true);
                  const track = musicPlayer.currentTrack;
                  lyricsService
                    .searchLyrics(
                      track.title,
                      track.artist || 'Unknown'
                    )
                    .then((result) => {
                      if (result) setLyrics(result);
                      else setError('Lyrics not found');
                    })
                    .catch(() => setError('Failed to fetch lyrics'))
                    .finally(() => setLoading(false));
                }
              }}
              className="mt-6 rounded-lg bg-primary px-6 py-3"
            >
              <Text className="text-center font-semibold text-background">Retry</Text>
            </Pressable>
          </View>
        ) : lyrics ? (
          <ScrollView className="flex-1 px-4 py-4">
            <Text className="text-center text-lg font-bold text-foreground">{lyrics.title}</Text>
            <Text className="mt-2 text-center text-muted">{lyrics.artist}</Text>

            {typeof lyrics.lyrics === 'string' ? (
              // Plain text lyrics
              <View className="mt-6">
                {lyrics.lyrics.split('\n').map((line, index) => (
                  <Text key={index} className="mb-3 text-base leading-relaxed text-foreground">
                    {line}
                  </Text>
                ))}
              </View>
            ) : Array.isArray(lyrics.lyrics) ? (
              // Synchronized lyrics
              <View className="mt-6">
                {lyrics.lyrics.map((lyric, index) => (
                  <View key={index} className="mb-4">
                    <Text className="text-xs text-muted">
                      {Math.floor(lyric.time / 60000)}:
                      {String(Math.floor((lyric.time % 60000) / 1000)).padStart(2, '0')}
                    </Text>
                    <Text className="mt-1 text-base text-foreground">{lyric.text}</Text>
                  </View>
                ))}
              </View>
            ) : null}

            {lyrics.source === 'genius' && lyrics.url && (
              <View className="mt-8 border-t border-border pt-4">
                <Text className="text-xs text-muted">
                  Lyrics from{' '}
                  <Text className="font-semibold text-primary">Genius</Text>
                </Text>
              </View>
            )}
          </ScrollView>
        ) : null}
      </View>
    </ScreenContainer>
  );
}
