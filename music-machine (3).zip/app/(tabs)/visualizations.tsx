import { ScrollView, Text, View, TouchableOpacity, FlatList } from 'react-native';
import { ScreenContainer } from '@/components/screen-container';
import { useColors } from '@/hooks/use-colors';
import MaterialIcons from '@expo/vector-icons/MaterialIcons';
import { useState, useCallback } from 'react';
import { useMusicPlayer } from '@/lib/music-player-context-v2';
import { VisualizerEngine, VisualizerType } from '@/lib/visualizer-engine';

interface VisualizerOption {
  type: VisualizerType;
  label: string;
  description: string;
}

export default function VisualizationsScreen() {
  const colors = useColors();
  const musicPlayer = useMusicPlayer();
  const [selectedViz, setSelectedViz] = useState<VisualizerType>('spectrum');
  const [intensity, setIntensity] = useState(70);
  const [speed, setSpeed] = useState(50);
  const [size, setSize] = useState(60);
  const [opacity, setOpacity] = useState(100);

  const visualizers: VisualizerOption[] = VisualizerEngine.getAllVisualizers().map((type) => ({
    type,
    label: VisualizerEngine.getVisualizerLabel(type),
    description: `${type} visualization`,
  }));

  const handleSelectVisualizer = useCallback((type: VisualizerType) => {
    setSelectedViz(type);
    const allViz = VisualizerEngine.getAllVisualizers();
    const idx = allViz.indexOf(type);
    musicPlayer.setVisualizerType(idx >= 0 ? idx : 0);
  }, [musicPlayer]);

  const renderVisualizerItem = ({ item }: { item: VisualizerOption }) => (
    <TouchableOpacity
      onPress={() => handleSelectVisualizer(item.type)}
      className="px-4 py-4 border-b"
      style={{
        borderColor: colors.border,
        backgroundColor: selectedViz === item.type ? colors.surface : colors.background,
      }}
    >
      <View className="flex-row items-center gap-3">
        <View
          className="w-12 h-12 rounded-lg items-center justify-center"
          style={{
            backgroundColor: selectedViz === item.type ? colors.primary : colors.surface,
          }}
        >
          <MaterialIcons
            name="show-chart"
            size={24}
            color={selectedViz === item.type ? colors.background : colors.primary}
          />
        </View>
        <View className="flex-1">
          <Text
            className="text-foreground font-semibold"
            style={{
              color: selectedViz === item.type ? colors.primary : colors.foreground,
            }}
          >
            {item.label}
          </Text>
          <Text className="text-muted text-xs mt-1">{item.description}</Text>
        </View>
        {selectedViz === item.type && (
          <MaterialIcons name="check-circle" size={24} color={colors.primary} />
        )}
      </View>
    </TouchableOpacity>
  );

  const renderSlider = (label: string, value: number, onChange: (v: number) => void) => (
    <View className="gap-2">
      <View className="flex-row justify-between items-center">
        <Text className="text-foreground font-semibold text-sm">{label}</Text>
        <Text className="text-primary font-bold text-sm">{value}%</Text>
      </View>
      <View
        className="h-2 rounded-full overflow-hidden"
        style={{ backgroundColor: colors.border }}
      >
        <View
          style={{
            width: `${value}%`,
            height: '100%',
            backgroundColor: colors.primary,
          }}
        />
      </View>
    </View>
  );

  return (
    <ScreenContainer className="flex-1 bg-background" containerClassName="bg-background">
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View className="px-6 pt-6 pb-4">
          <Text className="text-2xl font-bold text-foreground">Visualizations</Text>
          <Text className="text-muted text-sm mt-1">Choose from 22 custom visualizers</Text>
        </View>

        {/* Visualizer Preview */}
        <View
          className="mx-6 mb-6 rounded-lg items-center justify-center"
          style={{
            height: 200,
            backgroundColor: colors.surface,
            borderWidth: 1,
            borderColor: colors.border,
          }}
        >
          {musicPlayer.isPlaying ? (
            <View className="items-center gap-3">
              <MaterialIcons name="show-chart" size={64} color={colors.primary} />
              <Text className="text-foreground text-sm">{VisualizerEngine.getVisualizerLabel(selectedViz)}</Text>
            </View>
          ) : (
            <View className="items-center gap-3">
              <MaterialIcons name="play-circle-outline" size={64} color={colors.muted} />
              <Text className="text-muted text-sm">Play music to see visualizer</Text>
            </View>
          )}
        </View>

        {/* Settings */}
        <View className="px-6 pb-6 gap-4">
          <Text className="text-lg font-bold text-foreground">Settings</Text>
          {renderSlider('Intensity', intensity, setIntensity)}
          {renderSlider('Speed', speed, setSpeed)}
          {renderSlider('Size', size, setSize)}
          {renderSlider('Opacity', opacity, setOpacity)}
        </View>

        {/* Visualizer List */}
        <View className="px-6 pb-4">
          <Text className="text-lg font-bold text-foreground mb-3">All Visualizers</Text>
        </View>

        <FlatList
          data={visualizers}
          renderItem={renderVisualizerItem}
          keyExtractor={(item) => item.type}
          scrollEnabled={false}
          nestedScrollEnabled={false}
        />

        {/* Info */}
        <View className="px-6 py-6">
          <View
            className="p-4 rounded-lg gap-2"
            style={{ backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border }}
          >
            <Text className="text-foreground font-semibold text-sm">About Visualizers</Text>
            <Text className="text-muted text-xs leading-relaxed">
              Music Machine includes 22 unique visualizations that react to your music in real-time. Each visualizer has customizable settings for intensity, speed, size, and opacity. Visualizers display when playing local audio files.
            </Text>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
