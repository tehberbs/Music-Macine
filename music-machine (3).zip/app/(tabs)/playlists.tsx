import { ScrollView, Text, View, TouchableOpacity, FlatList, Modal, TextInput, Alert } from 'react-native';
import { ScreenContainer } from '@/components/screen-container';
import { useColors } from '@/hooks/use-colors';
import MaterialIcons from '@expo/vector-icons/MaterialIcons';
import { useState, useEffect, useCallback } from 'react';
import { getPlaylistService, type Playlist } from '@/lib/playlist-service';

export default function PlaylistsScreen() {
  const colors = useColors();
  const playlistService = getPlaylistService();
  const [playlists, setPlaylists] = useState<Playlist[]>([]);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [newPlaylistName, setNewPlaylistName] = useState('');
  const [newPlaylistDescription, setNewPlaylistDescription] = useState('');
  const [selectedColor, setSelectedColor] = useState('#7C3AED');

  // Load playlists on mount
  useEffect(() => {
    const unsubscribe = playlistService.subscribe((updatedPlaylists) => {
      setPlaylists(updatedPlaylists);
    });

    // Load initial playlists
    setPlaylists(playlistService.getAllPlaylists());

    return unsubscribe;
  }, []);

  const handleCreatePlaylist = useCallback(async () => {
    if (!newPlaylistName.trim()) {
      Alert.alert('Error', 'Please enter a playlist name');
      return;
    }

    await playlistService.createPlaylist(
      newPlaylistName,
      newPlaylistDescription || undefined,
      selectedColor
    );

    setNewPlaylistName('');
    setNewPlaylistDescription('');
    setSelectedColor('#7C3AED');
    setShowCreateModal(false);
  }, [newPlaylistName, newPlaylistDescription, selectedColor]);

  const handleDeletePlaylist = useCallback((playlistId: string, playlistName: string) => {
    Alert.alert('Delete Playlist', `Are you sure you want to delete "${playlistName}"?`, [
      { text: 'Cancel', onPress: () => {}, style: 'cancel' },
      {
        text: 'Delete',
        onPress: async () => {
          await playlistService.deletePlaylist(playlistId);
        },
        style: 'destructive',
      },
    ]);
  }, []);

  const handleDuplicatePlaylist = useCallback(async (playlistId: string) => {
    await playlistService.duplicatePlaylist(playlistId);
  }, []);

  const colorOptions = ['#7C3AED', '#06B6D4', '#EC4899', '#F59E0B', '#10B981', '#EF4444'];

  const renderPlaylistItem = ({ item }: { item: Playlist }) => {
    return (
      <TouchableOpacity
        activeOpacity={0.7}
        className="flex-row items-center gap-4 px-6 py-4 border-b"
        style={{
          borderBottomColor: colors.border,
          backgroundColor: colors.surface,
          marginHorizontal: 16,
          marginVertical: 8,
          borderRadius: 12,
          borderWidth: 1,
          borderColor: colors.border,
        }}
      >
        <View
          className="items-center justify-center rounded-lg"
          style={{
            width: 56,
            height: 56,
            backgroundColor: item.coverColor || '#7C3AED',
          }}
        >
          <MaterialIcons name="playlist-play" size={28} color={colors.background} />
        </View>

        <View className="flex-1">
          <Text className="text-foreground font-semibold text-base" numberOfLines={1}>
            {item.name}
          </Text>
          <Text className="text-muted text-xs" numberOfLines={1}>
            {item.trackIds.length} track{item.trackIds.length !== 1 ? 's' : ''}
          </Text>
          {item.description && (
            <Text className="text-muted text-xs mt-1" numberOfLines={1}>
              {item.description}
            </Text>
          )}
        </View>

        <View className="flex-row gap-2">
          <TouchableOpacity
            onPress={() => handleDuplicatePlaylist(item.id)}
            className="p-2"
            style={{ backgroundColor: colors.surface }}
          >
            <MaterialIcons name="content-copy" size={20} color={colors.primary} />
          </TouchableOpacity>

          <TouchableOpacity
            onPress={() => handleDeletePlaylist(item.id, item.name)}
            className="p-2"
            style={{ backgroundColor: colors.surface }}
          >
            <MaterialIcons name="delete" size={20} color={colors.error} />
          </TouchableOpacity>
        </View>
      </TouchableOpacity>
    );
  };

  return (
    <ScreenContainer className="flex-1 bg-background" containerClassName="bg-background">
      <View className="flex-1">
        {/* Header */}
        <View className="flex-row items-center justify-between px-6 pt-6 pb-4">
          <Text className="text-2xl font-bold text-foreground">Playlists</Text>
          <TouchableOpacity
            onPress={() => setShowCreateModal(true)}
            className="p-2 rounded-lg"
            style={{ backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border }}
          >
            <MaterialIcons name="add" size={24} color={colors.primary} />
          </TouchableOpacity>
        </View>

        {/* Playlists List */}
        {playlists.length > 0 ? (
          <FlatList
            data={playlists}
            renderItem={renderPlaylistItem}
            keyExtractor={(item) => item.id}
            scrollEnabled={true}
            contentContainerStyle={{ paddingBottom: 20 }}
          />
        ) : (
          <View className="flex-1 items-center justify-center px-6">
            <MaterialIcons name="playlist-play" size={64} color={colors.muted} />
            <Text className="text-foreground text-lg font-semibold mt-4">
              No playlists yet
            </Text>
            <Text className="text-muted text-sm mt-2 text-center">
              Create your first playlist to organize your music
            </Text>
            <TouchableOpacity
              onPress={() => setShowCreateModal(true)}
              className="mt-6 px-6 py-3 rounded-lg"
              style={{ backgroundColor: colors.primary }}
            >
              <Text className="text-background font-semibold">Create Playlist</Text>
            </TouchableOpacity>
          </View>
        )}
      </View>

      {/* Create Playlist Modal */}
      <Modal
        visible={showCreateModal}
        animationType="slide"
        transparent={true}
        onRequestClose={() => setShowCreateModal(false)}
      >
        <View
          className="flex-1 justify-end"
          style={{ backgroundColor: 'rgba(0, 0, 0, 0.5)' }}
        >
          <View
            className="rounded-t-3xl p-6 gap-4"
            style={{ backgroundColor: colors.surface }}
          >
            {/* Header */}
            <View className="flex-row items-center justify-between mb-4">
              <Text className="text-xl font-bold text-foreground">Create Playlist</Text>
              <TouchableOpacity onPress={() => setShowCreateModal(false)}>
                <MaterialIcons name="close" size={24} color={colors.foreground} />
              </TouchableOpacity>
            </View>

            {/* Playlist Name Input */}
            <View>
              <Text className="text-foreground font-semibold mb-2">Playlist Name</Text>
              <TextInput
                placeholder="Enter playlist name"
                placeholderTextColor={colors.muted}
                value={newPlaylistName}
                onChangeText={setNewPlaylistName}
                style={{
                  backgroundColor: colors.background,
                  color: colors.foreground,
                  borderWidth: 1,
                  borderColor: colors.border,
                  borderRadius: 8,
                  paddingHorizontal: 12,
                  paddingVertical: 10,
                }}
              />
            </View>

            {/* Playlist Description Input */}
            <View>
              <Text className="text-foreground font-semibold mb-2">Description (Optional)</Text>
              <TextInput
                placeholder="Enter playlist description"
                placeholderTextColor={colors.muted}
                value={newPlaylistDescription}
                onChangeText={setNewPlaylistDescription}
                multiline
                numberOfLines={3}
                style={{
                  backgroundColor: colors.background,
                  color: colors.foreground,
                  borderWidth: 1,
                  borderColor: colors.border,
                  borderRadius: 8,
                  paddingHorizontal: 12,
                  paddingVertical: 10,
                  textAlignVertical: 'top',
                }}
              />
            </View>

            {/* Color Picker */}
            <View>
              <Text className="text-foreground font-semibold mb-2">Cover Color</Text>
              <View className="flex-row gap-3">
                {colorOptions.map((color) => (
                  <TouchableOpacity
                    key={color}
                    onPress={() => setSelectedColor(color)}
                    className="rounded-full items-center justify-center"
                    style={{
                      width: 48,
                      height: 48,
                      backgroundColor: color,
                      borderWidth: selectedColor === color ? 3 : 0,
                      borderColor: colors.foreground,
                    }}
                  >
                    {selectedColor === color && (
                      <MaterialIcons name="check" size={24} color={colors.background} />
                    )}
                  </TouchableOpacity>
                ))}
              </View>
            </View>

            {/* Action Buttons */}
            <View className="flex-row gap-3 mt-4">
              <TouchableOpacity
                onPress={() => setShowCreateModal(false)}
                className="flex-1 py-3 rounded-lg items-center"
                style={{ backgroundColor: colors.border }}
              >
                <Text className="text-foreground font-semibold">Cancel</Text>
              </TouchableOpacity>

              <TouchableOpacity
                onPress={handleCreatePlaylist}
                className="flex-1 py-3 rounded-lg items-center"
                style={{ backgroundColor: colors.primary }}
              >
                <Text className="text-background font-semibold">Create</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </ScreenContainer>
  );
}
