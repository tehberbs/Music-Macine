import { ScrollView, Text, View, TouchableOpacity, FlatList } from 'react-native';
import { ScreenContainer } from '@/components/screen-container';
import { useColors } from '@/hooks/use-colors';
import MaterialIcons from '@expo/vector-icons/MaterialIcons';
import { useState, useCallback } from 'react';
import { VisualizerEngine, VisualizerType } from '@/lib/visualizer-engine';

interface VisualizerOption {
  type: VisualizerType;
  label: string;
}

export default function VisualizerSettingsScreen() {
  const colors = useColors();
  const [selectedViz, setSelectedViz] = useState<VisualizerType>('spectrum');
  const [intensity, setIntensity] = useState(70);
  const [speed, setSpeed] = useState(50);
  const [size, setSize] = useState(60);
  const [opacity, setOpacity] = useState(100);
  const [primaryColor, setPrimaryColor] = useState('#7C3AED');

  const visualizers = VisualizerEngine.getAllVisualizers().map((type) => ({
    type,
    label: VisualizerEngine.getVisualizerLabel(type),
  }));

  const colorOptions = [
    '#7C3AED', // Purple
    '#EC4899', // Pink
    '#06B6D4', // Cyan
    '#10B981', // Green
    '#F59E0B', // Amber
    '#EF4444', // Red
    '#3B82F6', // Blue
    '#8B5CF6', // Violet
  ];

  const handleSelectViz = useCallback((type: VisualizerType) => {
    setSelectedViz(type);
  }, []);

  const handleColorSelect = useCallback((color: string) => {
    setPrimaryColor(color);
  }, []);

  const renderVisualizerOption = ({ item }: { item: VisualizerOption }) => {
    const isSelected = selectedViz === item.type;
    return (
      <TouchableOpacity
        onPress={() => handleSelectViz(item.type)}
        className="flex-1 py-3 px-3 rounded-lg m-1 items-center"
        style={{
          backgroundColor: isSelected ? colors.primary : colors.surface,
          borderWidth: isSelected ? 2 : 1,
          borderColor: isSelected ? colors.primary : colors.border,
        }}
      >
        <Text
          className="text-xs font-semibold text-center"
          style={{
            color: isSelected ? colors.background : colors.foreground,
          }}
          numberOfLines={2}
        >
          {item.label}
        </Text>
      </TouchableOpacity>
    );
  };

  const renderColorOption = (color: string) => (
    <TouchableOpacity
      key={color}
      onPress={() => handleColorSelect(color)}
      className="rounded-full m-2 border-2"
      style={{
        width: 50,
        height: 50,
        backgroundColor: color,
        borderColor: primaryColor === color ? colors.foreground : 'transparent',
      }}
    />
  );

  const renderSlider = (label: string, value: number, onChange: (v: number) => void, min = 0, max = 100) => {
    const percentage = ((value - min) / (max - min)) * 100;
    return (
      <View className="gap-2">
        <View className="flex-row items-center justify-between">
          <Text className="text-foreground font-semibold text-sm">{label}</Text>
          <Text className="text-primary font-semibold text-sm">{value}%</Text>
        </View>
        <TouchableOpacity
          activeOpacity={0.8}
          style={{
            height: 40,
            justifyContent: 'center',
            backgroundColor: colors.surface,
            borderRadius: 8,
            borderWidth: 1,
            borderColor: colors.border,
          }}
        >
          <View
            style={{
              height: 6,
              backgroundColor: colors.border,
              borderRadius: 3,
              marginHorizontal: 12,
            }}
          >
            <View
              style={{
                height: 6,
                backgroundColor: colors.primary,
                borderRadius: 3,
                width: `${percentage}%`,
              }}
            />
          </View>
        </TouchableOpacity>
      </View>
    );
  };

  return (
    <ScreenContainer className="flex-1 bg-background" containerClassName="bg-background">
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ flexGrow: 1 }}>
        {/* Header */}
        <View className="px-6 pt-6 pb-4">
          <Text className="text-2xl font-bold text-foreground">Visualizer Settings</Text>
          <Text className="text-muted text-sm mt-1">Customize your audio visualization</Text>
        </View>

        {/* Visualizer Selection */}
        <View className="px-6 py-4">
          <Text className="text-foreground font-semibold mb-3">Choose Visualizer (22 Options)</Text>
          <FlatList
            data={visualizers}
            renderItem={renderVisualizerOption}
            keyExtractor={(item) => item.type}
            numColumns={3}
            scrollEnabled={false}
            contentContainerStyle={{ gap: 4 }}
          />
        </View>

        {/* Color Selection */}
        <View className="px-6 py-4">
          <Text className="text-foreground font-semibold mb-3">Primary Color</Text>
          <View className="flex-row flex-wrap justify-center">
            {colorOptions.map((color) => renderColorOption(color))}
          </View>
        </View>

        {/* Sliders */}
        <View className="px-6 py-4 gap-6">
          <Text className="text-foreground font-semibold">Settings</Text>
          {renderSlider('Intensity', intensity, setIntensity)}
          {renderSlider('Speed', speed, setSpeed)}
          {renderSlider('Size', size, setSize)}
          {renderSlider('Opacity', opacity, setOpacity)}
        </View>

        {/* Preview Info */}
        <View className="px-6 py-4">
          <View
            className="p-4 rounded-lg gap-2"
            style={{ backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border }}
          >
            <View className="flex-row items-center gap-2">
              <MaterialIcons name="info" size={20} color={colors.primary} />
              <Text className="text-foreground font-semibold text-sm flex-1">Current Selection</Text>
            </View>
            <Text className="text-muted text-xs">
              {VisualizerEngine.getVisualizerLabel(selectedViz)} • Intensity: {intensity}% • Speed: {speed}%
            </Text>
          </View>
        </View>

        {/* Info */}
        <View className="px-6 py-4 mb-6">
          <View
            className="p-4 rounded-lg gap-2"
            style={{ backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border }}
          >
            <Text className="text-foreground font-semibold text-sm">22 Visualizations Available</Text>
            <Text className="text-muted text-xs leading-relaxed">
              Waveform, Spectrum, Circular Spectrum, Particles, Geometric, Kaleidoscope, Tunnel, Liquid Waves, Radial Burst, Fractal, Aurora, Orb, Mesh Grid, Plasma, Flower Bloom, Meteor Shower, DNA Helix, Sound Bars 3D, Equalizer Bars, Pulse Rings, Butterfly Wings, and Crystal Lattice.
            </Text>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
