import React, { useState } from 'react';
import { View, Text, ScrollView, Switch, TouchableOpacity, StyleSheet } from 'react-native';
import { ScreenContainer } from '@/components/screen-container';
import MaterialIcons from '@expo/vector-icons/MaterialIcons';

interface SettingItemProps {
  label: string;
  value?: boolean | string | number;
  onToggle?: (value: boolean) => void;
  onPress?: () => void;
  type?: 'toggle' | 'slider' | 'dropdown' | 'text';
  icon?: string;
}

function SettingItem({
  label,
  value,
  onToggle,
  onPress,
  type = 'toggle',
  icon,
}: SettingItemProps) {
  if (type === 'toggle') {
    return (
      <View style={styles.settingRow}>
        <View style={styles.settingLabel}>
          {icon && <MaterialIcons name={icon as any} size={20} color="#FFD700" style={{ marginRight: 8 }} />}
          <Text style={styles.settingText}>{label}</Text>
        </View>
        <View style={styles.toggleContainer}>
          <Text style={styles.toggleValue}>{value ? 'ON' : 'OFF'}</Text>
          <Switch
            value={typeof value === 'boolean' ? value : false}
            onValueChange={onToggle}
            trackColor={{ false: '#333', true: '#4CAF50' }}
            thumbColor={typeof value === 'boolean' && value ? '#FFD700' : '#888'}
          />
        </View>
      </View>
    );
  }

  if (type === 'slider') {
    return (
      <View style={styles.settingRow}>
        <View style={styles.settingLabel}>
          {icon && <MaterialIcons name={icon as any} size={20} color="#FFD700" style={{ marginRight: 8 }} />}
          <Text style={styles.settingText}>{label}</Text>
        </View>
        <View style={styles.sliderContainer}>
          <Text style={styles.sliderValue}>{value}</Text>
          <View style={styles.sliderBar}>
            <View style={[styles.sliderFill, { width: `${((value as number) / 100) * 100}%` }]} />
          </View>
        </View>
      </View>
    );
  }

  if (type === 'dropdown') {
    return (
      <TouchableOpacity style={styles.settingRow} onPress={onPress}>
        <View style={styles.settingLabel}>
          {icon && <MaterialIcons name={icon as any} size={20} color="#FFD700" style={{ marginRight: 8 }} />}
          <Text style={styles.settingText}>{label}</Text>
        </View>
        <View style={styles.dropdownContainer}>
          <Text style={styles.dropdownValue}>{value}</Text>
          <MaterialIcons name="expand-more" size={20} color="#D4AF37" />
        </View>
      </TouchableOpacity>
    );
  }

  return null;
}

export default function SettingsScreen() {
  const [notifications, setNotifications] = useState(true);
  const [autoSave, setAutoSave] = useState(true);
  const [darkMode, setDarkMode] = useState(true);
  const [masterVolume, setMasterVolume] = useState(58);
  const [bass, setBass] = useState(50);
  const [mid, setMid] = useState(50);
  const [treble, setTreble] = useState(50);
  const [audioOutput, setAudioOutput] = useState('Standard');
  const [display, setDisplay] = useState('Standard');
  const [language, setLanguage] = useState('English (US)');

  return (
    <ScreenContainer className="bg-transparent">
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.container}>
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.headerTitle}>Settings</Text>
        </View>

        {/* Two Column Layout */}
        <View style={styles.columnsContainer}>
          {/* Left Column - General Settings */}
          <View style={styles.column}>
            <Text style={styles.sectionTitle}>General</Text>
            <View style={styles.settingsBox}>
              <SettingItem
                label="Enable Notifications"
                value={notifications}
                onToggle={setNotifications}
                type="toggle"
              />
              <View style={styles.divider} />
              <SettingItem
                label="Auto Save Settings"
                value={autoSave}
                onToggle={setAutoSave}
                type="toggle"
              />
              <View style={styles.divider} />
              <SettingItem
                label="Dark Mode"
                value={darkMode}
                onToggle={setDarkMode}
                type="toggle"
              />

              <Text style={styles.subsectionTitle}>Audio Levels</Text>
              <View style={styles.divider} />
              <SettingItem
                label="Master Volume"
                value={masterVolume}
                type="slider"
              />
              <View style={styles.divider} />
              <SettingItem
                label="Bass"
                value={bass}
                type="slider"
              />
              <View style={styles.divider} />
              <SettingItem
                label="Mid"
                value={mid}
                type="slider"
              />
              <View style={styles.divider} />
              <SettingItem
                label="Treble"
                value={treble}
                type="slider"
              />
            </View>
          </View>

          {/* Right Column - Audio Levels & More Settings */}
          <View style={styles.column}>
            <Text style={styles.sectionTitle}>Audio Levels</Text>
            <View style={styles.eqVisualizerBox}>
              {/* EQ Bars Visualization */}
              <View style={styles.eqBarsContainer}>
                {[bass, 40, mid, 60, treble, 45, 55, 50].map((value, i) => (
                  <View key={i} style={styles.eqBar}>
                    <View
                      style={[
                        styles.eqBarFill,
                        {
                          height: `${(value / 100) * 100}%`,
                          backgroundColor: value > 70 ? '#FF6B6B' : value > 40 ? '#FFD700' : '#4CAF50',
                        },
                      ]}
                    />
                  </View>
                ))}
              </View>
            </View>

            <Text style={styles.sectionTitle}>More Settings</Text>
            <View style={styles.settingsBox}>
              <SettingItem
                label="Audio Output"
                value={audioOutput}
                type="dropdown"
              />
              <View style={styles.divider} />
              <SettingItem
                label="Display"
                value={display}
                type="dropdown"
              />
              <View style={styles.divider} />
              <SettingItem
                label="Language"
                value={language}
                type="dropdown"
              />
            </View>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 16,
    paddingBottom: 100,
  },
  header: {
    marginBottom: 24,
  },
  headerTitle: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#FFD700',
    textAlign: 'center',
  },
  columnsContainer: {
    flexDirection: 'row',
    gap: 16,
  },
  column: {
    flex: 1,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#FFD700',
    marginBottom: 12,
  },
  subsectionTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#FFD700',
    marginTop: 16,
    marginBottom: 8,
  },
  settingsBox: {
    backgroundColor: '#1a1a1a',
    borderWidth: 2,
    borderColor: '#D4AF37',
    borderRadius: 8,
    overflow: 'hidden',
  },
  settingRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 12,
    paddingHorizontal: 12,
  },
  settingLabel: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  settingText: {
    color: '#FFD700',
    fontSize: 14,
    fontWeight: '500',
  },
  toggleContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  toggleValue: {
    color: '#4CAF50',
    fontSize: 12,
    fontWeight: 'bold',
  },
  sliderContainer: {
    flex: 1,
    marginLeft: 12,
    gap: 4,
  },
  sliderValue: {
    color: '#FFD700',
    fontSize: 12,
    fontWeight: 'bold',
  },
  sliderBar: {
    height: 6,
    backgroundColor: '#333',
    borderRadius: 3,
    overflow: 'hidden',
  },
  sliderFill: {
    height: '100%',
    backgroundColor: '#FFD700',
  },
  dropdownContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  dropdownValue: {
    color: '#A0826D',
    fontSize: 12,
  },
  divider: {
    height: 1,
    backgroundColor: '#333',
  },
  eqVisualizerBox: {
    backgroundColor: '#1a1a1a',
    borderWidth: 2,
    borderColor: '#D4AF37',
    borderRadius: 8,
    padding: 16,
    marginBottom: 16,
  },
  eqBarsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'flex-end',
    height: 120,
    gap: 4,
  },
  eqBar: {
    flex: 1,
    height: '100%',
    backgroundColor: '#0d0d0d',
    borderRadius: 2,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: '#333',
  },
  eqBarFill: {
    width: '100%',
  },
});
