import React, { useState, useCallback } from 'react';
import {
  ScrollView,
  Text,
  View,
  TouchableOpacity,
  StyleSheet,
} from 'react-native';
import { ScreenContainer } from '@/components/screen-container';
import { useColors } from '@/hooks/use-colors';
import MaterialIcons from '@expo/vector-icons/MaterialIcons';
import { useMusicPlayer } from '@/lib/music-player-context-v2';

const EQ_BANDS = 30;

const EQ_PRESETS: Record<string, { name: string; values: number[] }> = {
  flat: { name: 'Flat', values: Array(EQ_BANDS).fill(0) },
  bassBoost: {
    name: 'Bass Boost',
    values: [...Array(10).fill(8), ...Array(10).fill(0), ...Array(10).fill(-4)],
  },
  trebleBoost: {
    name: 'Treble Boost',
    values: [...Array(10).fill(-4), ...Array(10).fill(0), ...Array(10).fill(8)],
  },
  vocal: {
    name: 'Vocal',
    values: [
      ...Array(5).fill(-3),
      ...Array(10).fill(5),
      ...Array(10).fill(2),
      ...Array(5).fill(-3),
    ],
  },
  rock: {
    name: 'Rock',
    values: [
      ...Array(5).fill(6),
      ...Array(5).fill(3),
      ...Array(10).fill(0),
      ...Array(5).fill(3),
      ...Array(5).fill(5),
    ],
  },
  classical: {
    name: 'Classical',
    values: [
      ...Array(5).fill(4),
      ...Array(10).fill(0),
      ...Array(5).fill(2),
      ...Array(5).fill(0),
      ...Array(5).fill(4),
    ],
  },
};

// Map 30 bands to frequency labels (1–999 Hz)
function getFreqLabel(index: number): string {
  const freq = Math.round(1 + (index / (EQ_BANDS - 1)) * 998);
  if (freq < 1000) return `${freq}`;
  return `${(freq / 1000).toFixed(1)}k`;
}

export default function EqualizerScreen() {
  const colors = useColors();
  const musicPlayer = useMusicPlayer();
  const [selectedPreset, setSelectedPreset] = useState<string | null>('flat');

  const handleBandChange = useCallback(
    (index: number, delta: number) => {
      const current = musicPlayer.eqBands[index] ?? 0;
      const next = Math.max(-12, Math.min(12, current + delta));
      musicPlayer.setEQBand(index, next);
      setSelectedPreset(null);
    },
    [musicPlayer]
  );

  const applyPreset = useCallback(
    (key: string) => {
      const preset = EQ_PRESETS[key];
      preset.values.forEach((v, i) => musicPlayer.setEQBand(i, v));
      setSelectedPreset(key);
    },
    [musicPlayer]
  );

  const handleReset = useCallback(() => {
    musicPlayer.resetEQ();
    setSelectedPreset('flat');
  }, [musicPlayer]);

  return (
    <ScreenContainer containerClassName="bg-background">
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scroll}>
        {/* Header */}
        <View style={styles.header}>
          <Text style={[styles.title, { color: colors.foreground }]}>Equalizer</Text>
          <Text style={[styles.subtitle, { color: colors.muted }]}>30-Band EQ · 1–999 Hz</Text>
        </View>

        {/* Presets */}
        <View style={styles.section}>
          <Text style={[styles.sectionLabel, { color: colors.foreground }]}>Presets</Text>
          <View style={styles.presetRow}>
            {Object.entries(EQ_PRESETS).map(([key, preset]) => (
              <TouchableOpacity
                key={key}
                onPress={() => applyPreset(key)}
                style={[
                  styles.presetBtn,
                  {
                    backgroundColor: selectedPreset === key ? colors.primary : colors.surface,
                    borderColor: selectedPreset === key ? colors.primary : colors.border,
                  },
                ]}
              >
                <Text
                  style={[
                    styles.presetText,
                    { color: selectedPreset === key ? '#fff' : colors.foreground },
                  ]}
                >
                  {preset.name}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* EQ Bands */}
        <View style={styles.section}>
          <Text style={[styles.sectionLabel, { color: colors.foreground }]}>Frequency Bands</Text>
          <View style={styles.bandsContainer}>
            {musicPlayer.eqBands.map((value, index) => {
              const pct = ((value + 12) / 24) * 100;
              return (
                <View key={index} style={styles.bandRow}>
                  <Text style={[styles.bandFreq, { color: colors.muted }]}>
                    {getFreqLabel(index)}
                  </Text>
                  <View style={styles.bandSliderWrap}>
                    {/* Track */}
                    <View style={[styles.bandTrack, { backgroundColor: colors.border }]}>
                      {/* Fill */}
                      <View
                        style={[
                          styles.bandFill,
                          {
                            width: `${pct}%`,
                            backgroundColor: value >= 0 ? colors.primary : colors.error,
                          },
                        ]}
                      />
                    </View>
                    {/* Buttons */}
                    <TouchableOpacity
                      style={[styles.bandBtn, { backgroundColor: colors.surface }]}
                      onPress={() => handleBandChange(index, -1)}
                    >
                      <MaterialIcons name="remove" size={14} color={colors.primary} />
                    </TouchableOpacity>
                    <TouchableOpacity
                      style={[styles.bandBtn, { backgroundColor: colors.surface }]}
                      onPress={() => handleBandChange(index, 1)}
                    >
                      <MaterialIcons name="add" size={14} color={colors.primary} />
                    </TouchableOpacity>
                  </View>
                  <Text style={[styles.bandValue, { color: colors.primary }]}>
                    {value > 0 ? '+' : ''}{value}
                  </Text>
                </View>
              );
            })}
          </View>
        </View>

        {/* Reset */}
        <View style={[styles.section, { paddingBottom: 32 }]}>
          <TouchableOpacity
            onPress={handleReset}
            style={[styles.resetBtn, { backgroundColor: colors.surface, borderColor: colors.border }]}
          >
            <MaterialIcons name="refresh" size={18} color={colors.primary} />
            <Text style={[styles.resetText, { color: colors.foreground }]}>Reset to Flat</Text>
          </TouchableOpacity>
          <View style={[styles.infoBox, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            <Text style={[styles.infoText, { color: colors.muted }]}>
              Adjust each of the 30 frequency bands from −12 to +12 dB. Changes apply in real-time to both local files and YouTube playback.
            </Text>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  scroll: { paddingBottom: 24 },
  header: { paddingHorizontal: 24, paddingTop: 24, paddingBottom: 16 },
  title: { fontSize: 26, fontWeight: '800' },
  subtitle: { fontSize: 13, marginTop: 4 },
  section: { paddingHorizontal: 20, paddingBottom: 20 },
  sectionLabel: { fontSize: 14, fontWeight: '700', marginBottom: 12 },
  presetRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  presetBtn: { paddingHorizontal: 14, paddingVertical: 8, borderRadius: 20, borderWidth: 1 },
  presetText: { fontSize: 13, fontWeight: '600' },
  bandsContainer: { gap: 10 },
  bandRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  bandFreq: { width: 36, fontSize: 10, textAlign: 'right' },
  bandSliderWrap: { flex: 1, flexDirection: 'row', alignItems: 'center', gap: 6 },
  bandTrack: { flex: 1, height: 6, borderRadius: 3, overflow: 'hidden' },
  bandFill: { height: '100%', borderRadius: 3 },
  bandBtn: { width: 26, height: 26, borderRadius: 13, alignItems: 'center', justifyContent: 'center' },
  bandValue: { width: 30, fontSize: 11, fontWeight: '700', textAlign: 'right' },
  resetBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, paddingVertical: 14, borderRadius: 12, borderWidth: 1, marginBottom: 16 },
  resetText: { fontSize: 15, fontWeight: '600' },
  infoBox: { padding: 14, borderRadius: 12, borderWidth: 1 },
  infoText: { fontSize: 12, lineHeight: 18 },
});
