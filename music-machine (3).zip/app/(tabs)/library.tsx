import React, { useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet, FlatList } from 'react-native';
import { ScreenContainer } from '@/components/screen-container';
import MaterialIcons from '@expo/vector-icons/MaterialIcons';

type TabType = 'albums' | 'artists' | 'remixes' | 'tracks';

interface Album {
  id: string;
  name: string;
  artist: string;
}

interface Artist {
  id: string;
  name: string;
  songs: number;
}

interface Track {
  id: string;
  title: string;
  artist: string;
  duration: string;
}

const mockAlbums: Album[] = [
  { id: '1', name: 'Album 1', artist: 'Artist 1' },
  { id: '2', name: 'Album 1', artist: 'Artist 1' },
  { id: '3', name: 'Album 2', artist: 'Artist 2' },
  { id: '4', name: 'Album 3', artist: 'Artist 3' },
  { id: '5', name: 'Album 4', artist: 'Artist 4' },
  { id: '6', name: 'Album 5', artist: 'Artist 5' },
];

const mockArtists: Artist[] = [
  { id: '1', name: 'Artist 2', songs: 12 },
  { id: '2', name: 'Artist 1', songs: 8 },
  { id: '3', name: 'Artist 2', songs: 15 },
  { id: '4', name: 'Artist 3', songs: 10 },
  { id: '5', name: 'Artist 4', songs: 7 },
  { id: '6', name: 'Artist 5', songs: 20 },
];

const mockTracks: Track[] = [
  { id: '1', title: 'Song Title 1', artist: 'Dongs', duration: '20:10' },
  { id: '2', title: 'Song Title 1', artist: 'Artist 1', duration: '20:10' },
  { id: '3', title: 'Song Title 2', artist: 'Artist 2', duration: '20:10' },
  { id: '4', title: 'Song Title 9', artist: 'Artist 3', duration: '20:10' },
  { id: '5', title: 'Song Title 5', artist: 'Artist 2', duration: '20:10' },
  { id: '6', title: 'Song Title 9', artist: 'Artist 5', duration: '20:10' },
  { id: '7', title: 'Song Title 10', artist: 'Artist 2', duration: '20:10' },
];

export default function LibraryScreen() {
  const [activeTab, setActiveTab] = useState<TabType>('albums');

  const TabButton = ({ tab, label }: { tab: TabType; label: string }) => (
    <TouchableOpacity
      onPress={() => setActiveTab(tab)}
      style={[
        styles.tabButton,
        activeTab === tab && styles.tabButtonActive,
      ]}
    >
      <Text
        style={[
          styles.tabButtonText,
          activeTab === tab && styles.tabButtonTextActive,
        ]}
      >
        {label}
      </Text>
    </TouchableOpacity>
  );

  const AlbumItem = ({ album }: { album: Album }) => (
    <TouchableOpacity style={styles.listItem}>
      <View style={styles.listItemIcon}>
        <MaterialIcons name="album" size={20} color="#FFD700" />
      </View>
      <Text style={styles.listItemText}>{album.name}</Text>
    </TouchableOpacity>
  );

  const ArtistItem = ({ artist }: { artist: Artist }) => (
    <TouchableOpacity style={styles.listItem}>
      <View style={styles.listItemIcon}>
        <MaterialIcons name="person" size={20} color="#FFD700" />
      </View>
      <View>
        <Text style={styles.listItemText}>{artist.name}</Text>
        <Text style={styles.listItemSubtext}>{artist.songs} songs</Text>
      </View>
    </TouchableOpacity>
  );

  const TrackItem = ({ track }: { track: Track }) => (
    <TouchableOpacity style={styles.trackItem}>
      <View style={styles.trackInfo}>
        <Text style={styles.trackTitle}>{track.title}</Text>
        <Text style={styles.trackArtist}>{track.artist}</Text>
      </View>
      <Text style={styles.trackDuration}>{track.duration}</Text>
    </TouchableOpacity>
  );

  return (
    <ScreenContainer className="bg-transparent">
      <View style={styles.container}>
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.headerTitle}>Music Library</Text>
        </View>

        {/* Tabs */}
        <View style={styles.tabsContainer}>
          <TabButton tab="albums" label="Albums" />
          <TabButton tab="artists" label="Artists" />
          <TabButton tab="remixes" label="Remixes" />
          <TabButton tab="tracks" label="Tracks" />
        </View>

        {/* Content */}
        <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.contentContainer}>
          <View style={styles.contentBox}>
            {/* Left Column - Albums/Artists */}
            <View style={styles.column}>
              {activeTab === 'albums' && (
                <FlatList
                  scrollEnabled={false}
                  data={mockAlbums}
                  keyExtractor={(item) => item.id}
                  renderItem={({ item }) => <AlbumItem album={item} />}
                />
              )}
              {activeTab === 'artists' && (
                <FlatList
                  scrollEnabled={false}
                  data={mockArtists}
                  keyExtractor={(item) => item.id}
                  renderItem={({ item }) => <ArtistItem artist={item} />}
                />
              )}
            </View>

            {/* Right Column - Tracks */}
            <View style={styles.column}>
              <View style={styles.tracksHeader}>
                <Text style={styles.tracksHeaderText}>Tracks</Text>
                <MaterialIcons name="search" size={20} color="#FFD700" />
              </View>
              <FlatList
                scrollEnabled={false}
                data={mockTracks}
                keyExtractor={(item) => item.id}
                renderItem={({ item }) => <TrackItem track={item} />}
              />
            </View>
          </View>
        </ScrollView>
      </View>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    paddingVertical: 16,
    paddingHorizontal: 16,
    borderBottomWidth: 2,
    borderBottomColor: '#D4AF37',
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#FFD700',
    textAlign: 'center',
  },
  tabsContainer: {
    flexDirection: 'row',
    paddingHorizontal: 16,
    paddingVertical: 12,
    gap: 8,
    borderBottomWidth: 1,
    borderBottomColor: '#333',
  },
  tabButton: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 4,
    backgroundColor: '#1a1a1a',
    borderWidth: 1,
    borderColor: '#333',
  },
  tabButtonActive: {
    backgroundColor: '#D4AF37',
    borderColor: '#FFD700',
  },
  tabButtonText: {
    color: '#A0826D',
    fontSize: 12,
    fontWeight: '600',
  },
  tabButtonTextActive: {
    color: '#0d0d0d',
  },
  contentContainer: {
    paddingBottom: 100,
  },
  contentBox: {
    flexDirection: 'row',
    padding: 16,
    gap: 16,
    backgroundColor: '#1a1a1a',
    borderWidth: 2,
    borderColor: '#D4AF37',
    borderRadius: 8,
    margin: 16,
  },
  column: {
    flex: 1,
  },
  listItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 8,
    paddingHorizontal: 8,
    borderBottomWidth: 1,
    borderBottomColor: '#333',
    gap: 8,
  },
  listItemIcon: {
    width: 24,
    height: 24,
    justifyContent: 'center',
    alignItems: 'center',
  },
  listItemText: {
    color: '#FFD700',
    fontSize: 13,
    fontWeight: '500',
  },
  listItemSubtext: {
    color: '#A0826D',
    fontSize: 11,
    marginTop: 2,
  },
  tracksHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 8,
    paddingHorizontal: 8,
    borderBottomWidth: 1,
    borderBottomColor: '#333',
    marginBottom: 8,
  },
  tracksHeaderText: {
    color: '#FFD700',
    fontSize: 13,
    fontWeight: '600',
  },
  trackItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 8,
    paddingHorizontal: 8,
    borderBottomWidth: 1,
    borderBottomColor: '#333',
  },
  trackInfo: {
    flex: 1,
  },
  trackTitle: {
    color: '#FFD700',
    fontSize: 12,
    fontWeight: '500',
  },
  trackArtist: {
    color: '#A0826D',
    fontSize: 11,
    marginTop: 2,
  },
  trackDuration: {
    color: '#A0826D',
    fontSize: 11,
    marginLeft: 8,
  },
});
