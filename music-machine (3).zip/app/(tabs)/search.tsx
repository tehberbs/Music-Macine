import { ScrollView, Text, View, TouchableOpacity, FlatList, TextInput } from 'react-native';
import { ScreenContainer } from '@/components/screen-container';
import { useColors } from '@/hooks/use-colors';
import MaterialIcons from '@expo/vector-icons/MaterialIcons';
import { useState, useCallback } from 'react';
import { useMusicPlayer } from '@/lib/music-player-context-v2';

interface SearchResult {
  id: string;
  title: string;
  artist: string;
  type: 'local' | 'youtube';
}

export default function SearchScreen() {
  const colors = useColors();
  const musicPlayer = useMusicPlayer();
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<SearchResult[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [recentSearches, setRecentSearches] = useState<string[]>([
    'Drake',
    'The Weeknd',
    'Billie Eilish',
    'Taylor Swift',
  ]);

  const handleSearch = useCallback(async () => {
    if (!searchQuery.trim()) return;

    setIsSearching(true);

    // Simulate search across local library and YouTube
    const results: SearchResult[] = [
      {
        id: '1',
        title: `${searchQuery} - Track 1`,
        artist: 'Artist Name',
        type: 'local',
      },
      {
        id: '2',
        title: `${searchQuery} - Music Video`,
        artist: 'Artist Name',
        type: 'youtube',
      },
      {
        id: '3',
        title: `${searchQuery} - Live Performance`,
        artist: 'Artist Name',
        type: 'youtube',
      },
      {
        id: '4',
        title: `${searchQuery} - Remix`,
        artist: 'Producer Name',
        type: 'local',
      },
    ];

    setSearchResults(results);

    // Add to recent searches
    if (!recentSearches.includes(searchQuery)) {
      setRecentSearches([searchQuery, ...recentSearches.slice(0, 4)]);
    }

    setIsSearching(false);
  }, [searchQuery, recentSearches]);

  const handlePlayResult = useCallback(
    (result: SearchResult) => {
      musicPlayer.playTrack({
        id: result.id,
        title: result.title,
        artist: result.artist,
        duration: 0,
        uri: '',
      });
    },
    [musicPlayer]
  );

  const renderSearchResult = ({ item }: { item: SearchResult }) => (
    <TouchableOpacity
      onPress={() => handlePlayResult(item)}
      className="px-4 py-3 border-b flex-row items-center justify-between"
      style={{ borderColor: colors.border }}
    >
      <View className="flex-row items-center gap-3 flex-1">
        <View
          className="w-12 h-12 rounded-lg items-center justify-center"
          style={{ backgroundColor: colors.surface }}
        >
          <MaterialIcons
            name={item.type === 'youtube' ? 'play-circle-outline' : 'music-note'}
            size={24}
            color={colors.primary}
          />
        </View>
        <View className="flex-1">
          <Text className="text-foreground font-semibold" numberOfLines={1}>
            {item.title}
          </Text>
          <Text className="text-muted text-xs mt-1">
            {item.artist} • {item.type === 'youtube' ? 'YouTube' : 'Local'}
          </Text>
        </View>
      </View>
      <MaterialIcons name="play-arrow" size={24} color={colors.primary} />
    </TouchableOpacity>
  );

  const renderRecentSearch = (search: string) => (
    <TouchableOpacity
      key={search}
      onPress={() => {
        setSearchQuery(search);
        handleSearch();
      }}
      className="px-3 py-2 rounded-full mr-2 mb-2"
      style={{ backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border }}
    >
      <Text className="text-foreground text-sm">{search}</Text>
    </TouchableOpacity>
  );

  return (
    <ScreenContainer className="flex-1 bg-background" containerClassName="bg-background">
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View className="px-6 pt-6 pb-4">
          <Text className="text-2xl font-bold text-foreground">Search</Text>
          <Text className="text-muted text-sm mt-1">Find music in your library or YouTube</Text>
        </View>

        {/* Search Bar */}
        <View className="px-6 pb-4">
          <View
            className="flex-row items-center px-4 py-3 rounded-lg border"
            style={{ backgroundColor: colors.surface, borderColor: colors.border }}
          >
            <MaterialIcons name="search" size={20} color={colors.muted} />
            <TextInput
              placeholder="Search tracks, artists..."
              placeholderTextColor={colors.muted}
              value={searchQuery}
              onChangeText={setSearchQuery}
              onSubmitEditing={handleSearch}
              returnKeyType="search"
              className="flex-1 ml-2 text-foreground"
              style={{ color: colors.foreground }}
            />
            {searchQuery.length > 0 && (
              <TouchableOpacity onPress={() => setSearchQuery('')}>
                <MaterialIcons name="close" size={20} color={colors.muted} />
              </TouchableOpacity>
            )}
          </View>
        </View>

        {/* Search Results or Recent Searches */}
        {searchResults.length > 0 ? (
          <View className="pb-6">
            <View className="px-6 py-3">
              <Text className="text-lg font-bold text-foreground">Results ({searchResults.length})</Text>
            </View>
            <FlatList
              data={searchResults}
              renderItem={renderSearchResult}
              keyExtractor={(item) => item.id}
              scrollEnabled={false}
              nestedScrollEnabled={false}
            />
          </View>
        ) : (
          <View className="px-6 pb-6">
            <Text className="text-lg font-bold text-foreground mb-3">Recent Searches</Text>
            <View className="flex-row flex-wrap">
              {recentSearches.map((search) => renderRecentSearch(search))}
            </View>

            {/* Search Tips */}
            <View className="mt-6 p-4 rounded-lg" style={{ backgroundColor: colors.surface }}>
              <Text className="text-foreground font-semibold mb-2">Search Tips</Text>
              <Text className="text-muted text-xs leading-relaxed">
                • Search by artist name, song title, or album{'\n'}
                • Results include both local library and YouTube{'\n'}
                • Tap any result to play immediately
              </Text>
            </View>
          </View>
        )}
      </ScrollView>
    </ScreenContainer>
  );
}
