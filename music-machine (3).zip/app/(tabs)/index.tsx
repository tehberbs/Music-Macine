import React, { useState, useCallback, useEffect } from 'react';
import {
  ScrollView,
  Text,
  View,
  TouchableOpacity,
  Modal,
  TextInput,
  FlatList,
  Linking,
  ActivityIndicator,
  StyleSheet,
} from 'react-native';
import { useRouter } from 'expo-router';
import { ScreenContainer } from '@/components/screen-container';
import { useColors } from '@/hooks/use-colors';
import MaterialIcons from '@expo/vector-icons/MaterialIcons';
import { useMusicPlayer } from '@/lib/music-player-context-v2';
import { GlobalSearchService, type SearchResult } from '@/lib/global-search-service';
import { useKeepAwake } from 'expo-keep-awake';
import { SteampunkBackgroundV2 } from '@/components/steampunk-background-v2';
import { MechanicalConnectors } from '@/components/mechanical-connectors';
import { SwipeGestureDetector } from '@/components/swipe-gesture-detector';
import { useSwipeControls } from '@/hooks/use-swipe-controls';
import { useVolumeControl } from '@/hooks/use-volume-control';
import { CentralGear, SurroundingGear } from '@/components/central-gear';
import { SteampunkLayoutBackground } from '@/components/steampunk-layout-background';
import { AnimatedEqualizer } from '@/components/animated-equalizer';
import { ReorganizedControls, CompactControls } from '@/components/reorganized-controls';

function formatTime(seconds: number): string {
  const m = Math.floor(seconds / 60);
  const s = Math.floor(seconds % 60);
  return `${m}:${s.toString().padStart(2, '0')}`;
}

export default function HomeScreen() {
  const colors = useColors();
  const router = useRouter();
  const musicPlayer = useMusicPlayer();
  const { handleSwipeLeft, handleSwipeRight, handleSwipeUp, handleSwipeDown } = useSwipeControls();
  const { volume, increaseVolume, decreaseVolume } = useVolumeControl(0.7);
  useKeepAwake();

  const [showSearch, setShowSearch] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<SearchResult[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [searchError, setSearchError] = useState('');
  const [useNewLayout, setUseNewLayout] = useState(true);
  const [activeControlTab, setActiveControlTab] = useState<'eq' | 'siema' | 'viz' | null>(null);

  const handleSwipeLeftWithVolume = useCallback(() => {
    handleSwipeLeft();
  }, [handleSwipeLeft]);

  const handleSwipeRightWithVolume = useCallback(() => {
    handleSwipeRight();
  }, [handleSwipeRight]);

  const handleSwipeUpWithVolume = useCallback(() => {
    increaseVolume();
    handleSwipeUp();
  }, [increaseVolume, handleSwipeUp]);

  const handleSwipeDownWithVolume = useCallback(() => {
    decreaseVolume();
    handleSwipeDown();
  }, [decreaseVolume, handleSwipeDown]);

  const handleSearch = useCallback(async () => {
    if (!searchQuery.trim()) return;
    setIsSearching(true);
    setSearchError('');
    try {
      const results = await GlobalSearchService.globalSearch(searchQuery.trim(), ['youtube']);
      setSearchResults(results);
    } catch (error) {
      setSearchError('Search failed. Please check your connection.');
      console.error('Search failed:', error);
    } finally {
      setIsSearching(false);
    }
  }, [searchQuery]);

  const handleEmailPress = useCallback(async () => {
    const url = `mailto:berblivion@gmail.com?subject=${encodeURIComponent('Music Machine - Feedback')}&body=${encodeURIComponent('Hi Jeremy,\n\nI love Music Machine! Here is my feedback:\n\n')}`;
    try {
      await Linking.openURL(url);
    } catch (error) {
      console.error('Failed to open email:', error);
    }
  }, []);

  const progressPct =
    musicPlayer.duration > 0 ? (musicPlayer.currentTime / musicPlayer.duration) * 100 : 0;

  const renderSearchResult = ({ item }: { item: SearchResult }) => (
    <TouchableOpacity
      style={[styles.resultRow, { borderBottomColor: colors.border }]}
      onPress={() => {
        setShowSearch(false);
        router.push('/(tabs)/youtube');
      }}
    >
      <View style={[styles.resultThumb, { backgroundColor: colors.surface }]}>
        <MaterialIcons name="play-circle-outline" size={32} color={colors.primary} />
      </View>
      <View style={styles.resultInfo}>
        <Text style={[styles.resultTitle, { color: colors.foreground }]} numberOfLines={2}>
          {item.title}
        </Text>
        <Text style={[styles.resultSub, { color: colors.muted }]} numberOfLines={1}>
          {item.channel || item.source}
        </Text>
        {item.duration ? (
          <Text style={[styles.resultDur, { color: colors.muted }]}>
            {typeof item.duration === 'number'
              ? formatTime(item.duration)
              : item.duration}
          </Text>
        ) : null}
      </View>
      <MaterialIcons name="chevron-right" size={20} color={colors.muted} />
    </TouchableOpacity>
  );

  // Render new layout or old layout based on state
  if (useNewLayout) {
    return (
      <SwipeGestureDetector
        onSwipeLeft={handleSwipeLeftWithVolume}
        onSwipeRight={handleSwipeRightWithVolume}
        onSwipeUp={handleSwipeUpWithVolume}
        onSwipeDown={handleSwipeDownWithVolume}
      >
        <SteampunkLayoutBackground isPlaying={musicPlayer.isPlaying}>
          <View style={{ width: '100%', height: '100%', justifyContent: 'space-between', alignItems: 'center', paddingVertical: 30 }}>
            {/* Top: Animated Equalizer */}
            <AnimatedEqualizer isPlaying={musicPlayer.isPlaying} barCount={32} height={60} />

            {/* Middle: Central Gear + Controls */}
            <View style={{ alignItems: 'center', gap: 20 }}>
              <CentralGear
                isPlaying={musicPlayer.isPlaying}
                onPress={() => musicPlayer.isPlaying ? musicPlayer.pauseTrack() : musicPlayer.resumeTrack()}
                size={100}
              />
              <ReorganizedControls
                onPlayPause={() => musicPlayer.isPlaying ? musicPlayer.pauseTrack() : musicPlayer.resumeTrack()}
                onSkipNext={() => musicPlayer.nextTrack()}
                onSkipPrev={() => musicPlayer.previousTrack()}
                onShuffle={() => musicPlayer.toggleShuffle()}
                onRepeat={() => musicPlayer.toggleRepeat()}
                isPlaying={musicPlayer.isPlaying}
                isShuffle={musicPlayer.isShuffle}
                repeatMode={musicPlayer.repeatMode}
                currentTrackTitle={musicPlayer.currentTrack?.title ?? 'No Track'}
                currentArtist={musicPlayer.currentTrack?.artist ?? 'Unknown'}
              />
            </View>

            {/* Bottom: Compact Controls */}
            <CompactControls
              onEQ={() => setActiveControlTab('eq')}
              onSiema={() => setActiveControlTab('siema')}
              onViz={() => setActiveControlTab('viz')}
              activeTab={activeControlTab}
            />
          </View>
        </SteampunkLayoutBackground>
      </SwipeGestureDetector>
    );
  }

  // Old layout fallback
  return (
    <SwipeGestureDetector
      onSwipeLeft={handleSwipeLeftWithVolume}
      onSwipeRight={handleSwipeRightWithVolume}
      onSwipeUp={handleSwipeUpWithVolume}
      onSwipeDown={handleSwipeDownWithVolume}
    >
      <View style={{ flex: 1, backgroundColor: '#0d0d0d' }}>
      {/* Steampunk Background with 35+ Gears */}
      <SteampunkBackgroundV2 />
      <MechanicalConnectors />

      <ScreenContainer containerClassName="bg-transparent">
        <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scroll}>

          {/* ── Header ── */}
          <View style={styles.header}>
            <View>
              <Text style={[styles.appTitle, { color: '#FFD700' }]}>⚙️ MUSIC MACHINE ⚙️</Text>
              <Text style={[styles.appSubtitle, { color: '#A0826D' }]}>Industrial Audio Processing System</Text>
            </View>
            <TouchableOpacity
              style={[styles.searchBtn, { backgroundColor: '#1a1a1a', borderColor: '#D4AF37', borderWidth: 2 }]}
              onPress={() => setShowSearch(true)}
            >
              <MaterialIcons name="search" size={24} color="#FFD700" />
            </TouchableOpacity>
          </View>

          {/* ── Now Playing Card ── */}
          <View style={[styles.card, { backgroundColor: '#1a1a1a', borderColor: '#D4AF37', borderWidth: 2 }]}>
            {/* Visualizer / Album Art Area */}
            <View style={[styles.vizArea, { backgroundColor: '#0d0d0d' }]}>
              {musicPlayer.isPlaying ? (
                /* Animated bars when playing */
                <View style={styles.vizBars}>
                  {musicPlayer.frequencies.slice(0, 24).map((f, i) => (
                    <View
                      key={i}
                      style={[
                        styles.vizBar,
                        {
                          height: Math.max(4, f * 80),
                          backgroundColor: '#FFD700',
                          opacity: 0.6 + f * 0.4,
                        },
                      ]}
                    />
                  ))}
                </View>
              ) : (
                <View style={styles.vizEmpty}>
                  <MaterialIcons name="music-note" size={56} color="#8B7355" />
                  <Text style={[styles.vizEmptyText, { color: '#8B7355' }]}>
                    {musicPlayer.currentTrack ? 'Paused' : 'No track playing'}
                  </Text>
                  {!musicPlayer.currentTrack && (
                    <Text style={[styles.vizEmptyHint, { color: '#8B7355' }]}>
                      Browse Library or search YouTube
                    </Text>
                  )}
                </View>
              )}
            </View>

            {/* Track Info */}
            <View style={styles.trackInfo}>
              <Text style={[styles.trackTitle, { color: '#FFD700' }]} numberOfLines={1}>
                {musicPlayer.currentTrack?.title ?? 'No Track Selected'}
              </Text>
              <Text style={[styles.trackArtist, { color: '#A0826D' }]} numberOfLines={1}>
                {musicPlayer.currentTrack?.artist ?? 'Open Library to load music'}
              </Text>
            </View>

            {/* Progress Bar */}
            <View style={styles.progressContainer}>
              <View style={[styles.progressTrack, { backgroundColor: '#333' }]}>
                <View
                  style={[
                    styles.progressFill,
                    { width: `${progressPct}%`, backgroundColor: '#FFD700' },
                  ]}
                />
              </View>
              <View style={styles.progressTimes}>
                <Text style={[styles.timeText, { color: '#A0826D' }]}>
                  {formatTime(musicPlayer.currentTime)}
                </Text>
                <Text style={[styles.timeText, { color: '#A0826D' }]}>
                  {formatTime(musicPlayer.duration)}
                </Text>
              </View>
            </View>
          </View>

          {/* ── Playback Controls ── */}
          <View style={styles.controls}>
            <TouchableOpacity
              style={[styles.ctrlBtn, { backgroundColor: '#1a1a1a', borderColor: '#D4AF37', borderWidth: 2 }]}
              onPress={musicPlayer.previousTrack}
            >
              <MaterialIcons name="skip-previous" size={30} color="#FFD700" />
            </TouchableOpacity>

            <TouchableOpacity
              style={[styles.playBtn, { backgroundColor: '#D4AF37', borderColor: '#FFD700', borderWidth: 2 }]}
              onPress={musicPlayer.isPlaying ? musicPlayer.pauseTrack : musicPlayer.resumeTrack}
            >
              <MaterialIcons
                name={musicPlayer.isPlaying ? 'pause' : 'play-arrow'}
                size={42}
                color="#000"
              />
            </TouchableOpacity>

            <TouchableOpacity
              style={[styles.ctrlBtn, { backgroundColor: '#1a1a1a', borderColor: '#D4AF37', borderWidth: 2 }]}
              onPress={musicPlayer.nextTrack}
            >
              <MaterialIcons name="skip-next" size={30} color="#FFD700" />
            </TouchableOpacity>
          </View>

          {/* ── Shuffle & Repeat ── */}
          <View style={styles.modeRow}>
            <TouchableOpacity
              style={[
                styles.modeBtn,
                {
                  backgroundColor: musicPlayer.isShuffle ? '#D4AF37' : '#1a1a1a',
                  borderColor: '#D4AF37',
                  borderWidth: 2,
                },
              ]}
              onPress={musicPlayer.toggleShuffle}
            >
              <MaterialIcons
                name="shuffle"
                size={20}
                color={musicPlayer.isShuffle ? '#000' : '#FFD700'}
              />
              <Text
                style={[
                  styles.modeBtnText,
                  { color: musicPlayer.isShuffle ? '#000' : '#FFD700' },
                ]}
              >
                Shuffle
              </Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={[
                styles.modeBtn,
                {
                  backgroundColor: musicPlayer.repeatMode !== 'off' ? '#D4AF37' : '#1a1a1a',
                  borderColor: '#D4AF37',
                  borderWidth: 2,
                },
              ]}
              onPress={musicPlayer.toggleRepeat}
            >
              <MaterialIcons
                name={musicPlayer.repeatMode === 'one' ? 'repeat-one' : 'repeat'}
                size={20}
                color={musicPlayer.repeatMode !== 'off' ? '#000' : '#FFD700'}
              />
              <Text
                style={[
                  styles.modeBtnText,
                  { color: musicPlayer.repeatMode !== 'off' ? '#000' : '#FFD700' },
                ]}
              >
                {musicPlayer.repeatMode === 'off'
                  ? 'Repeat Off'
                  : musicPlayer.repeatMode === 'one'
                    ? 'Repeat One'
                    : 'Repeat All'}
              </Text>
            </TouchableOpacity>
          </View>

          {/* ── Quick Actions ── */}
          <View style={styles.quickActionsRow}>
            <TouchableOpacity
              style={[styles.quickBtn, { backgroundColor: '#1a1a1a', borderColor: '#D4AF37', borderWidth: 2 }]}
              onPress={() => router.push('/equalizer')}
            >
              <MaterialIcons name="equalizer" size={24} color="#FFD700" />
              <Text style={[styles.quickBtnText, { color: '#FFD700' }]}>EQ</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={[styles.quickBtn, { backgroundColor: '#1a1a1a', borderColor: '#D4AF37', borderWidth: 2 }]}
              onPress={() => router.push('/stems')}
            >
              <MaterialIcons name="tune" size={24} color="#FFD700" />
              <Text style={[styles.quickBtnText, { color: '#FFD700' }]}>Stems</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={[styles.quickBtn, { backgroundColor: '#1a1a1a', borderColor: '#D4AF37', borderWidth: 2 }]}
              onPress={() => router.push('/visualizations')}
            >
              <MaterialIcons name="graphic-eq" size={24} color="#FFD700" />
              <Text style={[styles.quickBtnText, { color: '#FFD700' }]}>Viz</Text>
            </TouchableOpacity>
          </View>

          {/* ── Footer ── */}
          <View style={[styles.footer, { borderTopColor: '#D4AF37' }]}>
            <Text style={{ color: '#A0826D', fontSize: 12, marginBottom: 4 }}>Created by</Text>
            <TouchableOpacity onPress={handleEmailPress}>
              <Text style={{ color: '#FFD700', fontSize: 14, fontWeight: 'bold', textDecorationLine: 'underline' }}>
                Jeremy Earl
              </Text>
            </TouchableOpacity>
            <Text style={{ color: '#666', fontSize: 11, marginTop: 4 }}>© April 18, 2026</Text>
          </View>
        </ScrollView>
      </ScreenContainer>

      {/* ── Search Modal ── */}
      <Modal visible={showSearch} animationType="slide" transparent={true}>
        <View style={[styles.modalOverlay, { backgroundColor: 'rgba(0, 0, 0, 0.8)' }]}>
          <View style={[styles.modalContent, { backgroundColor: '#1a1a1a', borderTopColor: '#D4AF37' }]}>
            <View style={styles.modalHeader}>
              <Text style={{ color: '#FFD700', fontSize: 18, fontWeight: 'bold', flex: 1 }}>Search</Text>
              <TouchableOpacity onPress={() => setShowSearch(false)}>
                <MaterialIcons name="close" size={24} color="#FFD700" />
              </TouchableOpacity>
            </View>

            <TextInput
              placeholder="Search YouTube..."
              placeholderTextColor="#666"
              value={searchQuery}
              onChangeText={setSearchQuery}
              onSubmitEditing={handleSearch}
              style={[styles.searchInput, { backgroundColor: '#0d0d0d', borderColor: '#D4AF37', color: '#FFD700' }]}
              returnKeyType="search"
            />

            {isSearching && <ActivityIndicator color="#FFD700" style={{ marginTop: 16 }} />}
            {searchError ? (
              <Text style={{ color: '#EF4444', marginTop: 12 }}>{searchError}</Text>
            ) : null}

            <FlatList
              data={searchResults}
              keyExtractor={(item) => item.id}
              renderItem={renderSearchResult}
              scrollEnabled={true}
              style={{ marginTop: 12 }}
              ListEmptyComponent={
                !isSearching ? (
                  <Text style={{ color: '#A0826D', textAlign: 'center', marginTop: 32 }}>
                    {searchQuery ? 'No results found' : 'Type to search...'}
                  </Text>
                ) : null
              }
            />
          </View>
        </View>
        </Modal>
      </View>
    </SwipeGestureDetector>
  );
}

const styles = StyleSheet.create({
  scroll: {
    paddingBottom: 32,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
    paddingHorizontal: 4,
  },
  appTitle: {
    fontSize: 28,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  appSubtitle: {
    fontSize: 12,
  },
  searchBtn: {
    width: 48,
    height: 48,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
  },
  card: {
    borderRadius: 16,
    padding: 16,
    marginBottom: 20,
  },
  vizArea: {
    height: 160,
    borderRadius: 12,
    marginBottom: 16,
    justifyContent: 'center',
    alignItems: 'center',
  },
  vizBars: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    justifyContent: 'center',
    gap: 3,
    height: '100%',
    paddingVertical: 12,
  },
  vizBar: {
    width: 4,
    borderRadius: 2,
  },
  vizEmpty: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  vizEmptyText: {
    fontSize: 16,
    fontWeight: '600',
    marginTop: 8,
  },
  vizEmptyHint: {
    fontSize: 12,
    marginTop: 4,
  },
  trackInfo: {
    marginBottom: 12,
  },
  trackTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  trackArtist: {
    fontSize: 14,
  },
  progressContainer: {
    gap: 8,
  },
  progressTrack: {
    height: 6,
    borderRadius: 3,
    overflow: 'hidden',
  },
  progressFill: {
    height: '100%',
  },
  progressTimes: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  timeText: {
    fontSize: 12,
  },
  controls: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 16,
    marginBottom: 20,
  },
  ctrlBtn: {
    width: 56,
    height: 56,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
  },
  playBtn: {
    width: 72,
    height: 72,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
  },
  modeRow: {
    flexDirection: 'row',
    gap: 12,
    marginBottom: 20,
  },
  modeBtn: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 12,
    borderRadius: 12,
  },
  modeBtnText: {
    fontSize: 13,
    fontWeight: '600',
  },
  quickActionsRow: {
    flexDirection: 'row',
    gap: 12,
    marginBottom: 20,
  },
  quickBtn: {
    flex: 1,
    paddingVertical: 12,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  quickBtnText: {
    fontSize: 11,
    fontWeight: '600',
    marginTop: 4,
  },
  footer: {
    alignItems: 'center',
    paddingTop: 16,
    borderTopWidth: 2,
    marginTop: 20,
  },
  modalOverlay: {
    flex: 1,
    justifyContent: 'flex-end',
  },
  modalContent: {
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    paddingTop: 16,
    paddingHorizontal: 16,
    maxHeight: '80%',
    borderTopWidth: 2,
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  searchInput: {
    borderWidth: 2,
    borderRadius: 12,
    paddingHorizontal: 12,
    paddingVertical: 10,
    fontSize: 14,
  },
  resultRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 1,
    gap: 12,
  },
  resultThumb: {
    width: 48,
    height: 48,
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
  },
  resultInfo: {
    flex: 1,
  },
  resultTitle: {
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 2,
  },
  resultSub: {
    fontSize: 12,
    marginBottom: 2,
  },
  resultDur: {
    fontSize: 11,
  },
});
