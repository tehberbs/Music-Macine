import { ScrollView, Text, View, TouchableOpacity, Dimensions, Animated } from 'react-native';
import { ScreenContainer } from '@/components/screen-container';
import { useColors } from '@/hooks/use-colors';
import MaterialIcons from '@expo/vector-icons/MaterialIcons';
import { useState, useEffect, useRef } from 'react';
import { useMusicPlayer, type RepeatMode } from '@/lib/music-player-context-v2';

export default function NowPlayingScreen() {
  const colors = useColors();
  const musicPlayer = useMusicPlayer();
  const { width } = Dimensions.get('window');
  const scaleAnim = useRef(new Animated.Value(1)).current;

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  // Pulse animation for album art
  useEffect(() => {
    if (musicPlayer.isPlaying) {
      Animated.loop(
        Animated.sequence([
          Animated.timing(scaleAnim, {
            toValue: 1.05,
            duration: 1000,
            useNativeDriver: true,
          }),
          Animated.timing(scaleAnim, {
            toValue: 1,
            duration: 1000,
            useNativeDriver: true,
          }),
        ])
      ).start();
    } else {
      scaleAnim.setValue(1);
    }
  }, [musicPlayer.isPlaying]);

  const getRepeatIcon = (mode: RepeatMode) => {
    if (mode === 'one') return 'repeat-one';
    if (mode === 'all') return 'repeat';
    return 'repeat';
  };

  const getRepeatColor = (mode: RepeatMode) => {
    if (mode === 'off') return colors.muted;
    return colors.primary;
  };

  return (
    <ScreenContainer className="flex-1 bg-background" containerClassName="bg-background">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} showsVerticalScrollIndicator={false}>
        <View className="flex-1 justify-between py-6 px-6">
          {/* Header */}
          <View className="flex-row items-center justify-between">
            <TouchableOpacity className="p-2">
              <MaterialIcons name="expand-more" size={28} color={colors.foreground} />
            </TouchableOpacity>
            <Text className="text-foreground font-semibold">Now Playing</Text>
            <TouchableOpacity className="p-2">
              <MaterialIcons name="more-vert" size={28} color={colors.foreground} />
            </TouchableOpacity>
          </View>

          {/* Album Art */}
          <View className="items-center my-8">
            <Animated.View
              style={{
                transform: [{ scale: scaleAnim }],
              }}
            >
              <View
                className="rounded-3xl items-center justify-center shadow-lg"
                style={{
                  width: width - 64,
                  height: width - 64,
                  backgroundColor: musicPlayer.currentTrack?.coverColor || colors.primary,
                }}
              >
                <MaterialIcons name="music-note" size={80} color={colors.background} />
              </View>
            </Animated.View>
          </View>

          {/* Track Info */}
          <View className="gap-2 mb-8">
            <Text className="text-2xl font-bold text-foreground text-center" numberOfLines={2}>
              {musicPlayer.currentTrack?.title || 'No Track Selected'}
            </Text>
            <Text className="text-lg text-muted text-center" numberOfLines={1}>
              {musicPlayer.currentTrack?.artist || 'Unknown Artist'}
            </Text>
          </View>

          {/* Progress Bar */}
          <View className="gap-2 mb-6">
            <View
              className="h-1 rounded-full overflow-hidden"
              style={{ backgroundColor: colors.border }}
            >
              <View
                style={{
                  width: `${musicPlayer.duration > 0 ? (musicPlayer.currentTime / musicPlayer.duration) * 100 : 0}%`,
                  height: '100%',
                  backgroundColor: colors.primary,
                }}
              />
            </View>
            <View className="flex-row justify-between">
              <Text className="text-xs text-muted">{formatTime(musicPlayer.currentTime)}</Text>
              <Text className="text-xs text-muted">{formatTime(musicPlayer.duration)}</Text>
            </View>
          </View>

          {/* Playback Controls */}
          <View className="gap-6">
            {/* Shuffle & Repeat */}
            <View className="flex-row justify-between items-center px-6">
              <TouchableOpacity
                onPress={musicPlayer.toggleShuffle}
                className="p-3 rounded-full"
                style={{
                  backgroundColor: musicPlayer.isShuffle ? colors.primary : colors.surface,
                }}
              >
                <MaterialIcons
                  name="shuffle"
                  size={24}
                  color={musicPlayer.isShuffle ? colors.background : colors.muted}
                />
              </TouchableOpacity>

              <TouchableOpacity
                onPress={musicPlayer.toggleRepeat}
                className="p-3 rounded-full"
                style={{
                  backgroundColor: musicPlayer.repeatMode !== 'off' ? colors.primary : colors.surface,
                }}
              >
                <MaterialIcons
                  name={getRepeatIcon(musicPlayer.repeatMode)}
                  size={24}
                  color={getRepeatColor(musicPlayer.repeatMode) === colors.primary ? colors.background : colors.muted}
                />
              </TouchableOpacity>
            </View>

            {/* Main Controls */}
            <View className="flex-row items-center justify-center gap-6">
              {/* Previous */}
              <TouchableOpacity
                onPress={musicPlayer.previousTrack}
                className="p-4 rounded-full"
                style={{ backgroundColor: colors.surface }}
              >
                <MaterialIcons name="skip-previous" size={32} color={colors.primary} />
              </TouchableOpacity>

              {/* Play/Pause */}
              <TouchableOpacity
                onPress={musicPlayer.isPlaying ? musicPlayer.pauseTrack : musicPlayer.resumeTrack}
                className="p-6 rounded-full items-center justify-center"
                style={{
                  width: 80,
                  height: 80,
                  backgroundColor: colors.primary,
                }}
              >
                <MaterialIcons
                  name={musicPlayer.isPlaying ? 'pause' : 'play-arrow'}
                  size={48}
                  color={colors.background}
                />
              </TouchableOpacity>

              {/* Next */}
              <TouchableOpacity
                onPress={musicPlayer.nextTrack}
                className="p-4 rounded-full"
                style={{ backgroundColor: colors.surface }}
              >
                <MaterialIcons name="skip-next" size={32} color={colors.primary} />
              </TouchableOpacity>
            </View>

            {/* Volume Control */}
            <View className="gap-3 px-6">
              <View className="flex-row items-center gap-3">
                <MaterialIcons name="volume-down" size={20} color={colors.muted} />
                <View
                  className="flex-1 h-1 rounded-full overflow-hidden"
                  style={{ backgroundColor: colors.border }}
                >
                  <View
                    style={{
                      width: '70%',
                      height: '100%',
                      backgroundColor: colors.primary,
                    }}
                  />
                </View>
                <MaterialIcons name="volume-up" size={20} color={colors.muted} />
              </View>
            </View>

            {/* Quick Actions */}
            <View className="flex-row justify-around px-6 gap-3">
              <TouchableOpacity
                className="flex-1 flex-row items-center justify-center gap-2 py-3 rounded-lg"
                style={{ backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border }}
              >
                <MaterialIcons name="graphic-eq" size={20} color={colors.primary} />
                <Text className="text-foreground font-semibold text-sm">EQ</Text>
              </TouchableOpacity>

              <TouchableOpacity
                className="flex-1 flex-row items-center justify-center gap-2 py-3 rounded-lg"
                style={{ backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border }}
              >
                <MaterialIcons name="tune" size={20} color={colors.primary} />
                <Text className="text-foreground font-semibold text-sm">Stems</Text>
              </TouchableOpacity>

              <TouchableOpacity
                className="flex-1 flex-row items-center justify-center gap-2 py-3 rounded-lg"
                style={{ backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border }}
              >
                <MaterialIcons name="show-chart" size={20} color={colors.primary} />
                <Text className="text-foreground font-semibold text-sm">Viz</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
