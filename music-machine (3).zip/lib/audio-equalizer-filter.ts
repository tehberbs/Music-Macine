/**
 * Audio Equalizer Filter Service
 * Applies frequency-based filtering to audio using Web Audio API
 */

export interface EQBand {
  frequency: number;
  gain: number;
  Q: number;
}

export class AudioEqualizerFilter {
  private audioContext: AudioContext | null = null;
  private analyser: AnalyserNode | null = null;
  private biquadFilters: BiquadFilterNode[] = [];
  private gainNode: GainNode | null = null;
  private sourceNode: AudioBufferSourceNode | MediaElementAudioSourceNode | null = null;

  /**
   * Initialize the equalizer with audio context
   */
  initialize(audioContext: AudioContext): void {
    this.audioContext = audioContext;
    this.analyser = audioContext.createAnalyser();
    this.gainNode = audioContext.createGain();

    // Connect analyser to destination
    this.gainNode.connect(this.analyser);
    this.analyser.connect(audioContext.destination);
  }

  /**
   * Create 30-band equalizer (1-999 Hz scale)
   */
  create30BandEQ(): EQBand[] {
    const bands: EQBand[] = [];
    const minFreq = 20;
    const maxFreq = 20000;

    for (let i = 0; i < 30; i++) {
      // Logarithmic frequency distribution
      const freq =
        minFreq * Math.pow(maxFreq / minFreq, i / 29);
      bands.push({
        frequency: freq,
        gain: 0,
        Q: 1,
      });
    }

    return bands;
  }

  /**
   * Apply EQ bands to audio
   */
  applyEQBands(bands: number[]): void {
    if (!this.audioContext || !this.gainNode) {
      console.warn('[AudioEQ] Equalizer not initialized');
      return;
    }

    // Clear existing filters
    this.biquadFilters.forEach((filter) => {
      try {
        filter.disconnect();
      } catch (_) {}
    });
    this.biquadFilters = [];

    // Create new filters for each band
    const eqBands = this.create30BandEQ();

    let prevNode: AudioNode = this.gainNode;

    for (let i = 0; i < Math.min(bands.length, eqBands.length); i++) {
      const filter = this.audioContext.createBiquadFilter();
      filter.type = 'peaking';
      filter.frequency.value = eqBands[i].frequency;
      filter.gain.value = bands[i] * 12; // Convert 0-100 to -12 to +12 dB
      filter.Q.value = eqBands[i].Q;

      prevNode.connect(filter);
      prevNode = filter;
      this.biquadFilters.push(filter);
    }

    // Connect last filter to analyser
    prevNode.connect(this.analyser!);
  }

  /**
   * Set individual band gain
   */
  setBandGain(bandIndex: number, gain: number): void {
    if (bandIndex >= 0 && bandIndex < this.biquadFilters.length) {
      this.biquadFilters[bandIndex].gain.value = gain * 12; // Convert to dB
    }
  }

  /**
   * Reset all bands to 0 gain
   */
  resetEQ(): void {
    this.biquadFilters.forEach((filter) => {
      filter.gain.value = 0;
    });
  }

  /**
   * Apply preset EQ settings
   */
  applyPreset(presetName: string): void {
    const presets: Record<string, number[]> = {
      flat: Array(30).fill(0),
      bass: [
        0.8, 0.8, 0.7, 0.6, 0.5, 0.4, 0.3, 0.2, 0.1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0,
      ],
      treble: [
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0.1, 0.2,
        0.3, 0.4, 0.5, 0.6,
      ],
      vocal: [
        0, 0, 0, 0, 0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.5, 0.4, 0.3, 0.2, 0.1, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0,
      ],
      rock: [
        0.6, 0.5, 0.4, 0.3, 0.2, 0.1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0.1, 0.2, 0.3, 0.4, 0.5, 0.6,
      ],
      pop: [
        0.3, 0.2, 0.1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0.1, 0.2, 0.3, 0.4,
      ],
    };

    const preset = presets[presetName] || presets.flat;
    this.applyEQBands(preset);
  }

  /**
   * Get frequency data for visualization
   */
  getFrequencyData(): Uint8Array {
    if (!this.analyser) {
      return new Uint8Array(256);
    }

    const dataArray = new Uint8Array(this.analyser.frequencyBinCount);
    this.analyser.getByteFrequencyData(dataArray);
    return dataArray;
  }

  /**
   * Get waveform data for visualization
   */
  getWaveformData(): Uint8Array {
    if (!this.analyser) {
      return new Uint8Array(256);
    }

    const dataArray = new Uint8Array(this.analyser.frequencyBinCount);
    this.analyser.getByteTimeDomainData(dataArray);
    return dataArray;
  }

  /**
   * Cleanup
   */
  dispose(): void {
    this.biquadFilters.forEach((filter) => {
      try {
        filter.disconnect();
      } catch (_) {}
    });
    this.biquadFilters = [];

    if (this.analyser) {
      try {
        this.analyser.disconnect();
      } catch (_) {}
    }

    if (this.gainNode) {
      try {
        this.gainNode.disconnect();
      } catch (_) {}
    }
  }
}

export const audioEqualizerFilter = new AudioEqualizerFilter();
