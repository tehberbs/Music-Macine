import * as ImagePicker from 'expo-image-picker';
import * as FileSystem from 'expo-file-system/legacy';
import { Platform } from 'react-native';

export interface UploadedImage {
  uri: string;
  name: string;
  size: number;
  type: 'background' | 'element' | 'icon';
  uploadedAt: number;
}

class ThemeImageUploadService {
  private static instance: ThemeImageUploadService;
  private uploadedImages: UploadedImage[] = [];

  private constructor() {}

  static getInstance(): ThemeImageUploadService {
    if (!ThemeImageUploadService.instance) {
      ThemeImageUploadService.instance = new ThemeImageUploadService();
    }
    return ThemeImageUploadService.instance;
  }

  async pickImage(type: 'background' | 'element' | 'icon'): Promise<UploadedImage | null> {
    try {
      // Request permissions
      if (Platform.OS !== 'web') {
        const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
        if (status !== 'granted') {
          console.error('Permission to access media library denied');
          return null;
        }
      }

      // Pick image
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        aspect: type === 'background' ? [9, 16] : [1, 1],
        quality: 0.8,
      });

      if (result.canceled) {
        return null;
      }

      const asset = result.assets[0];
      const uploadedImage = await this.processImage(asset.uri, type);
      
      if (uploadedImage) {
        this.uploadedImages.push(uploadedImage);
      }

      return uploadedImage;
    } catch (error) {
      console.error('Failed to pick image:', error);
      return null;
    }
  }

  private async processImage(uri: string, type: 'background' | 'element' | 'icon'): Promise<UploadedImage | null> {
    try {
      // Get file info
      const fileInfo = await FileSystem.getInfoAsync(uri);
      if (!fileInfo.exists) {
        throw new Error('File does not exist');
      }

      // Get filename
      const filename = uri.split('/').pop() || `image-${Date.now()}.jpg`;

      // Create theme images directory if it doesn't exist
      const themeImagesDir = `${FileSystem.cacheDirectory}theme-images`;
      const dirInfo = await FileSystem.getInfoAsync(themeImagesDir);
      if (!dirInfo.exists) {
        await FileSystem.makeDirectoryAsync(themeImagesDir, { intermediates: true });
      }

      // Copy image to app directory
      const newPath = `${themeImagesDir}/${type}-${Date.now()}-${filename}`;
      await FileSystem.copyAsync({
        from: uri,
        to: newPath,
      });

      return {
        uri: newPath,
        name: filename,
        size: fileInfo.size || 0,
        type,
        uploadedAt: Date.now(),
      };
    } catch (error) {
      console.error('Failed to process image:', error);
      return null;
    }
  }

  async deleteImage(uri: string): Promise<boolean> {
    try {
      await FileSystem.deleteAsync(uri, { idempotent: true });
      this.uploadedImages = this.uploadedImages.filter((img) => img.uri !== uri);
      return true;
    } catch (error) {
      console.error('Failed to delete image:', error);
      return false;
    }
  }

  getUploadedImages(type?: 'background' | 'element' | 'icon'): UploadedImage[] {
    if (type) {
      return this.uploadedImages.filter((img) => img.type === type);
    }
    return this.uploadedImages;
  }

  async clearOldImages(maxAge: number = 30 * 24 * 60 * 60 * 1000): Promise<void> {
    const now = Date.now();
    const imagesToDelete = this.uploadedImages.filter((img) => now - img.uploadedAt > maxAge);

    for (const img of imagesToDelete) {
      await this.deleteImage(img.uri);
    }
  }

  async getImageBase64(uri: string): Promise<string | null> {
    try {
      return await FileSystem.readAsStringAsync(uri, { encoding: 'base64' });
    } catch (error) {
      console.error('Failed to read image as base64:', error);
      return null;
    }
  }

  async resizeImage(
    uri: string,
    width: number,
    height: number
  ): Promise<string | null> {
    try {
      // For now, return the original URI
      // Full image resizing would require native modules or external service
      return uri;
    } catch (error) {
      console.error('Failed to resize image:', error);
      return null;
    }
  }
}

export const themeImageUploadService = ThemeImageUploadService.getInstance();
