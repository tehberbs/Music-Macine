// Playback Controller - Manages audio playback and track state
export interface Track {
  id: string;
  uri: string;
  title: string;
  artist: string;
  duration: number;
  isLocal: boolean;
  source: 'local' | 'youtube';
}

export interface PlaybackState {
  currentTrack: Track | null;
  isPlaying: boolean;
  currentTime: number;
  duration: number;
  volume: number;
  queue: Track[];
  currentIndex: number;
}

export class PlaybackController {
  private state: PlaybackState = {
    currentTrack: null,
    isPlaying: false,
    currentTime: 0,
    duration: 0,
    volume: 1,
    queue: [],
    currentIndex: -1,
  };

  private audioElement: HTMLAudioElement | null = null;
  private listeners: Set<(state: PlaybackState) => void> = new Set();

  constructor() {
    this.initializeAudioElement();
  }

  private initializeAudioElement() {
    if (typeof window !== 'undefined') {
      this.audioElement = new Audio();
      this.audioElement.addEventListener('timeupdate', () => this.updateCurrentTime());
      this.audioElement.addEventListener('loadedmetadata', () => this.updateDuration());
      this.audioElement.addEventListener('ended', () => this.playNext());
      this.audioElement.addEventListener('play', () => this.updatePlayingState());
      this.audioElement.addEventListener('pause', () => this.updatePlayingState());
    }
  }

  /**
   * Load and play a track
   */
  async loadTrack(track: Track) {
    if (!this.audioElement) return;

    this.state.currentTrack = track;
    this.state.currentTime = 0;

    try {
      // Set audio source
      this.audioElement.src = track.uri;
      this.audioElement.load();

      // Auto-play
      await this.audioElement.play();
      this.state.isPlaying = true;
      this.notifyListeners();
    } catch (error) {
      console.error('Failed to load track:', error);
    }
  }

  /**
   * Play current track
   */
  async play() {
    if (!this.audioElement || !this.state.currentTrack) return;

    try {
      await this.audioElement.play();
      this.state.isPlaying = true;
      this.notifyListeners();
    } catch (error) {
      console.error('Playback failed:', error);
    }
  }

  /**
   * Pause current track
   */
  pause() {
    if (!this.audioElement) return;

    this.audioElement.pause();
    this.state.isPlaying = false;
    this.notifyListeners();
  }

  /**
   * Toggle play/pause
   */
  togglePlayPause() {
    if (this.state.isPlaying) {
      this.pause();
    } else {
      this.play();
    }
  }

  /**
   * Seek to time
   */
  seek(time: number) {
    if (!this.audioElement) return;

    this.audioElement.currentTime = time;
    this.state.currentTime = time;
    this.notifyListeners();
  }

  /**
   * Set volume (0-1)
   */
  setVolume(volume: number) {
    if (!this.audioElement) return;

    const clampedVolume = Math.max(0, Math.min(1, volume));
    this.audioElement.volume = clampedVolume;
    this.state.volume = clampedVolume;
    this.notifyListeners();
  }

  /**
   * Add track to queue
   */
  addToQueue(track: Track) {
    this.state.queue.push(track);
    this.notifyListeners();
  }

  /**
   * Set queue
   */
  setQueue(tracks: Track[]) {
    this.state.queue = tracks;
    this.state.currentIndex = -1;
    this.notifyListeners();
  }

  /**
   * Play next track
   */
  async playNext() {
    if (this.state.currentIndex < this.state.queue.length - 1) {
      this.state.currentIndex++;
      const nextTrack = this.state.queue[this.state.currentIndex];
      await this.loadTrack(nextTrack);
    }
  }

  /**
   * Play previous track
   */
  async playPrevious() {
    if (this.state.currentIndex > 0) {
      this.state.currentIndex--;
      const prevTrack = this.state.queue[this.state.currentIndex];
      await this.loadTrack(prevTrack);
    }
  }

  /**
   * Get current playback state
   */
  getState(): PlaybackState {
    return { ...this.state };
  }

  /**
   * Subscribe to state changes
   */
  subscribe(listener: (state: PlaybackState) => void): () => void {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  /**
   * Notify all listeners of state change
   */
  private notifyListeners() {
    this.listeners.forEach((listener) => listener(this.getState()));
  }

  /**
   * Update current time
   */
  private updateCurrentTime() {
    if (!this.audioElement) return;
    this.state.currentTime = this.audioElement.currentTime;
    this.notifyListeners();
  }

  /**
   * Update duration
   */
  private updateDuration() {
    if (!this.audioElement) return;
    this.state.duration = this.audioElement.duration || 0;
    this.notifyListeners();
  }

  /**
   * Update playing state
   */
  private updatePlayingState() {
    if (!this.audioElement) return;
    this.state.isPlaying = !this.audioElement.paused;
    this.notifyListeners();
  }

  /**
   * Get audio element (for connecting to Web Audio API)
   */
  getAudioElement(): HTMLAudioElement | null {
    return this.audioElement;
  }
}

// Singleton instance
let playbackController: PlaybackController | null = null;

export function getPlaybackController(): PlaybackController {
  if (!playbackController) {
    playbackController = new PlaybackController();
  }
  return playbackController;
}
