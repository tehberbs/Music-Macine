/**
 * Lyrics Service - Fetches lyrics from multiple sources
 * Uses Genius API as primary source, with fallback to local cache
 */

export interface Lyric {
  time: number; // in milliseconds
  text: string;
}

export interface LyricsData {
  title: string;
  artist: string;
  lyrics: string | Lyric[]; // Can be plain text or synchronized lyrics
  source: 'genius' | 'local' | 'unknown';
  url?: string;
}

const GENIUS_API_BASE = 'https://api.genius.com';
const GENIUS_API_KEY = process.env.GENIUS_API_KEY || '';

class LyricsService {
  private cache: Map<string, LyricsData> = new Map();

  /**
   * Search for lyrics by track title and artist
   */
  async searchLyrics(title: string, artist: string): Promise<LyricsData | null> {
    const cacheKey = `${artist}-${title}`.toLowerCase();

    // Check cache first
    if (this.cache.has(cacheKey)) {
      return this.cache.get(cacheKey) || null;
    }

    try {
      // Try Genius API
      const geniusLyrics = await this.searchGenius(title, artist);
      if (geniusLyrics) {
        this.cache.set(cacheKey, geniusLyrics);
        return geniusLyrics;
      }
    } catch (error) {
      console.warn('[LyricsService] Genius API error:', error);
    }

    // Return null if not found
    return null;
  }

  /**
   * Search Genius API for lyrics
   */
  private async searchGenius(title: string, artist: string): Promise<LyricsData | null> {
    if (!GENIUS_API_KEY) {
      console.warn('[LyricsService] Genius API key not configured');
      return null;
    }

    try {
      const query = `${title} ${artist}`;
      const response = await fetch(
        `${GENIUS_API_BASE}/search?q=${encodeURIComponent(query)}&access_token=${GENIUS_API_KEY}`
      );

      if (!response.ok) {
        throw new Error(`Genius API error: ${response.status}`);
      }

      const data = await response.json();
      const hits = data.response?.hits || [];

      if (hits.length === 0) {
        return null;
      }

      // Get the first result
      const hit = hits[0];
      const song = hit.result;

      // Fetch full lyrics from the song URL
      const lyricsText = await this.scrapeLyricsFromGenius(song.url);

      if (!lyricsText) {
        return null;
      }

      return {
        title: song.title,
        artist: song.primary_artist.name,
        lyrics: lyricsText,
        source: 'genius',
        url: song.url,
      };
    } catch (error) {
      console.error('[LyricsService] Genius search error:', error);
      return null;
    }
  }

  /**
   * Scrape lyrics from Genius website (fallback method)
   * Note: This is a simplified version. In production, use a proper lyrics API
   */
  private async scrapeLyricsFromGenius(url: string): Promise<string | null> {
    try {
      // This is a placeholder - in production, you'd use a proper scraping library
      // or a dedicated lyrics API like LyricFind or AZLyrics
      console.log('[LyricsService] Would scrape lyrics from:', url);
      return null;
    } catch (error) {
      console.error('[LyricsService] Scraping error:', error);
      return null;
    }
  }

  /**
   * Parse synchronized lyrics (LRC format)
   * Format: [mm:ss.xx]Lyric text
   */
  parseLRCLyrics(lrcText: string): Lyric[] {
    const lines = lrcText.split('\n');
    const lyrics: Lyric[] = [];

    for (const line of lines) {
      const match = line.match(/\[(\d{2}):(\d{2})\.(\d{2})\](.*)/);
      if (match) {
        const minutes = parseInt(match[1], 10);
        const seconds = parseInt(match[2], 10);
        const centiseconds = parseInt(match[3], 10);
        const time = (minutes * 60 + seconds) * 1000 + centiseconds * 10;
        const text = match[4].trim();

        if (text) {
          lyrics.push({ time, text });
        }
      }
    }

    return lyrics.sort((a, b) => a.time - b.time);
  }

  /**
   * Get lyrics at specific playback time
   */
  getLyricsAtTime(lyrics: Lyric[], currentTime: number): string | null {
    for (let i = lyrics.length - 1; i >= 0; i--) {
      if (lyrics[i].time <= currentTime) {
        return lyrics[i].text;
      }
    }
    return null;
  }

  /**
   * Get next lyrics line
   */
  getNextLyricsLine(lyrics: Lyric[], currentTime: number): Lyric | null {
    for (const lyric of lyrics) {
      if (lyric.time > currentTime) {
        return lyric;
      }
    }
    return null;
  }

  /**
   * Clear cache
   */
  clearCache(): void {
    this.cache.clear();
  }
}

export const lyricsService = new LyricsService();
