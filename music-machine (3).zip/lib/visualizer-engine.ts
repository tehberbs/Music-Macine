// Visualizer Engine - Generates visualization data for 22 different styles
export type VisualizerType = 
  | 'waveform'
  | 'spectrum'
  | 'circular-spectrum'
  | 'particles'
  | 'geometric'
  | 'kaleidoscope'
  | 'tunnel'
  | 'liquid-waves'
  | 'radial-burst'
  | 'fractal'
  | 'aurora'
  | 'orb'
  | 'mesh-grid'
  | 'plasma'
  | 'flower-bloom'
  | 'meteor-shower'
  | 'dna-helix'
  | 'sound-bars-3d'
  | 'equalizer-bars'
  | 'pulse-rings'
  | 'butterfly-wings'
  | 'crystal-lattice';

export interface VisualizerSettings {
  type: VisualizerType;
  color: string;
  secondaryColor?: string;
  intensity: number; // 0-100
  speed: number; // 0-100
  size: number; // 0-100
  opacity: number; // 0-100
}

export interface VisualizerData {
  bars: number[];
  particles?: Array<{ x: number; y: number; size: number; opacity: number }>;
  rotation?: number;
  scale?: number;
  time?: number;
}

export class VisualizerEngine {
  private audioData: Uint8Array = new Uint8Array(256);
  private time: number = 0;
  private settings: VisualizerSettings;

  constructor(settings: VisualizerSettings) {
    this.settings = settings;
  }

  updateSettings(settings: Partial<VisualizerSettings>) {
    this.settings = { ...this.settings, ...settings };
  }

  updateAudioData(data: Uint8Array) {
    this.audioData = data;
  }

  generateVisualizerData(): VisualizerData {
    this.time += this.settings.speed / 100;

    switch (this.settings.type) {
      case 'waveform':
        return this.generateWaveform();
      case 'spectrum':
        return this.generateSpectrum();
      case 'circular-spectrum':
        return this.generateCircularSpectrum();
      case 'particles':
        return this.generateParticles();
      case 'geometric':
        return this.generateGeometric();
      case 'kaleidoscope':
        return this.generateKaleidoscope();
      case 'tunnel':
        return this.generateTunnel();
      case 'liquid-waves':
        return this.generateLiquidWaves();
      case 'radial-burst':
        return this.generateRadialBurst();
      case 'fractal':
        return this.generateFractal();
      case 'aurora':
        return this.generateAurora();
      case 'orb':
        return this.generateOrb();
      case 'mesh-grid':
        return this.generateMeshGrid();
      case 'plasma':
        return this.generatePlasma();
      case 'flower-bloom':
        return this.generateFlowerBloom();
      case 'meteor-shower':
        return this.generateMeteorShower();
      case 'dna-helix':
        return this.generateDNAHelix();
      case 'sound-bars-3d':
        return this.generateSoundBars3D();
      case 'equalizer-bars':
        return this.generateEqualizerBars();
      case 'pulse-rings':
        return this.generatePulseRings();
      case 'butterfly-wings':
        return this.generateButterflyWings();
      case 'crystal-lattice':
        return this.generateCrystalLattice();
      default:
        return this.generateSpectrum();
    }
  }

  private generateWaveform(): VisualizerData {
    const bars: number[] = [];
    for (let i = 0; i < 64; i++) {
      const index = Math.floor((i / 64) * this.audioData.length);
      bars.push(this.audioData[index] / 255);
    }
    return { bars };
  }

  private generateSpectrum(): VisualizerData {
    const bars: number[] = [];
    const binSize = Math.floor(this.audioData.length / 32);
    for (let i = 0; i < 32; i++) {
      let sum = 0;
      for (let j = 0; j < binSize; j++) {
        sum += this.audioData[i * binSize + j];
      }
      bars.push((sum / binSize) / 255);
    }
    return { bars };
  }

  private generateCircularSpectrum(): VisualizerData {
    const bars = this.generateSpectrum().bars;
    return {
      bars,
      rotation: this.time * 0.5,
    };
  }

  private generateParticles(): VisualizerData {
    const particles = [];
    const avgAudio = this.audioData.reduce((a, b) => a + b) / this.audioData.length / 255;
    
    for (let i = 0; i < 50; i++) {
      const angle = (i / 50) * Math.PI * 2 + this.time;
      const radius = avgAudio * 100 + 50;
      particles.push({
        x: Math.cos(angle) * radius,
        y: Math.sin(angle) * radius,
        size: Math.random() * 10 + 5,
        opacity: avgAudio,
      });
    }
    return { bars: [], particles };
  }

  private generateGeometric(): VisualizerData {
    const bars = this.generateSpectrum().bars;
    return {
      bars,
      scale: 0.5 + (this.audioData[0] / 255) * 0.5,
      rotation: this.time,
    };
  }

  private generateKaleidoscope(): VisualizerData {
    const bars = this.generateSpectrum().bars;
    return {
      bars,
      rotation: this.time * 2,
      scale: 0.3 + (this.audioData[128] / 255) * 0.7,
    };
  }

  private generateTunnel(): VisualizerData {
    const bars: number[] = [];
    for (let i = 0; i < 32; i++) {
      const depth = i / 32;
      const index = Math.floor(depth * this.audioData.length);
      bars.push(this.audioData[index] / 255);
    }
    return { bars, scale: 0.5 + (this.time % 1) * 0.5 };
  }

  private generateLiquidWaves(): VisualizerData {
    const bars: number[] = [];
    for (let i = 0; i < 32; i++) {
      const wave = Math.sin((i / 32) * Math.PI * 2 + this.time) * 0.5 + 0.5;
      const index = Math.floor((i / 32) * this.audioData.length);
      const audio = this.audioData[index] / 255;
      bars.push(wave * audio);
    }
    return { bars };
  }

  private generateRadialBurst(): VisualizerData {
    const bars = this.generateSpectrum().bars;
    const avgAudio = this.audioData.reduce((a, b) => a + b) / this.audioData.length / 255;
    return {
      bars,
      scale: 1 + avgAudio * 0.5,
      rotation: this.time,
    };
  }

  private generateFractal(): VisualizerData {
    const bars: number[] = [];
    for (let i = 0; i < 32; i++) {
      const index = Math.floor((i / 32) * this.audioData.length);
      const val = this.audioData[index] / 255;
      bars.push(Math.pow(val, 1.5));
    }
    return { bars, rotation: this.time * 0.3 };
  }

  private generateAurora(): VisualizerData {
    const bars: number[] = [];
    for (let i = 0; i < 32; i++) {
      const wave = Math.sin((i / 32) * Math.PI + this.time * 0.5) * 0.5 + 0.5;
      const index = Math.floor((i / 32) * this.audioData.length);
      bars.push((this.audioData[index] / 255) * wave);
    }
    return { bars };
  }

  private generateOrb(): VisualizerData {
    const avgAudio = this.audioData.reduce((a, b) => a + b) / this.audioData.length / 255;
    return {
      bars: [avgAudio],
      scale: 0.5 + avgAudio * 0.5,
      rotation: this.time,
    };
  }

  private generateMeshGrid(): VisualizerData {
    const bars: number[] = [];
    for (let i = 0; i < 64; i++) {
      const index = Math.floor((i / 64) * this.audioData.length);
      bars.push(this.audioData[index] / 255);
    }
    return { bars, rotation: this.time * 0.2 };
  }

  private generatePlasma(): VisualizerData {
    const bars: number[] = [];
    for (let i = 0; i < 32; i++) {
      const val1 = Math.sin((i / 32) * Math.PI * 2 + this.time) * 0.5 + 0.5;
      const val2 = Math.cos((i / 32) * Math.PI * 2 + this.time * 1.5) * 0.5 + 0.5;
      const index = Math.floor((i / 32) * this.audioData.length);
      const audio = this.audioData[index] / 255;
      bars.push((val1 + val2) * audio * 0.5);
    }
    return { bars };
  }

  private generateFlowerBloom(): VisualizerData {
    const bars: number[] = [];
    for (let i = 0; i < 32; i++) {
      const petal = Math.sin((i / 32) * Math.PI * 6 + this.time) * 0.5 + 0.5;
      const index = Math.floor((i / 32) * this.audioData.length);
      bars.push((this.audioData[index] / 255) * petal);
    }
    return { bars, rotation: this.time * 0.5 };
  }

  private generateMeteorShower(): VisualizerData {
    const particles = [];
    for (let i = 0; i < 30; i++) {
      const index = Math.floor(Math.random() * this.audioData.length);
      const audio = this.audioData[index] / 255;
      particles.push({
        x: Math.random() * 200 - 100,
        y: Math.random() * 200 - 100 + this.time * 50,
        size: audio * 10 + 2,
        opacity: audio,
      });
    }
    return { bars: [], particles };
  }

  private generateDNAHelix(): VisualizerData {
    const bars: number[] = [];
    for (let i = 0; i < 32; i++) {
      const helix = Math.sin((i / 32) * Math.PI * 4 + this.time) * 0.5 + 0.5;
      const index = Math.floor((i / 32) * this.audioData.length);
      bars.push((this.audioData[index] / 255) * helix);
    }
    return { bars, rotation: this.time * 0.3 };
  }

  private generateSoundBars3D(): VisualizerData {
    const bars: number[] = [];
    const binSize = Math.floor(this.audioData.length / 32);
    for (let i = 0; i < 32; i++) {
      let sum = 0;
      for (let j = 0; j < binSize; j++) {
        sum += this.audioData[i * binSize + j];
      }
      const normalized = (sum / binSize) / 255;
      bars.push(Math.pow(normalized, 0.8));
    }
    return { bars, scale: 0.8 + (this.audioData[0] / 255) * 0.4 };
  }

  private generateEqualizerBars(): VisualizerData {
    const bars: number[] = [];
    const binSize = Math.floor(this.audioData.length / 16);
    for (let i = 0; i < 16; i++) {
      let sum = 0;
      for (let j = 0; j < binSize; j++) {
        sum += this.audioData[i * binSize + j];
      }
      bars.push((sum / binSize) / 255);
    }
    return { bars };
  }

  private generatePulseRings(): VisualizerData {
    const avgAudio = this.audioData.reduce((a, b) => a + b) / this.audioData.length / 255;
    const bars: number[] = [];
    for (let i = 0; i < 8; i++) {
      const ring = Math.sin(this.time - i * 0.3) * 0.5 + 0.5;
      bars.push(ring * avgAudio);
    }
    return { bars, scale: 0.5 + avgAudio * 0.5 };
  }

  private generateButterflyWings(): VisualizerData {
    const bars: number[] = [];
    for (let i = 0; i < 32; i++) {
      const wing = Math.abs(Math.sin((i / 32) * Math.PI * 2 + this.time * 2));
      const index = Math.floor((i / 32) * this.audioData.length);
      bars.push((this.audioData[index] / 255) * wing);
    }
    return { bars, rotation: this.time };
  }

  private generateCrystalLattice(): VisualizerData {
    const bars: number[] = [];
    for (let i = 0; i < 32; i++) {
      const crystal = Math.sin((i / 32) * Math.PI * 3 + this.time * 0.5) * 0.5 + 0.5;
      const index = Math.floor((i / 32) * this.audioData.length);
      bars.push((this.audioData[index] / 255) * crystal);
    }
    return { bars, rotation: this.time * 0.2, scale: 0.7 + (this.audioData[128] / 255) * 0.3 };
  }

  static getAllVisualizers(): VisualizerType[] {
    return [
      'waveform',
      'spectrum',
      'circular-spectrum',
      'particles',
      'geometric',
      'kaleidoscope',
      'tunnel',
      'liquid-waves',
      'radial-burst',
      'fractal',
      'aurora',
      'orb',
      'mesh-grid',
      'plasma',
      'flower-bloom',
      'meteor-shower',
      'dna-helix',
      'sound-bars-3d',
      'equalizer-bars',
      'pulse-rings',
      'butterfly-wings',
      'crystal-lattice',
    ];
  }

  static getVisualizerLabel(type: VisualizerType): string {
    const labels: Record<VisualizerType, string> = {
      'waveform': 'Waveform',
      'spectrum': 'Spectrum',
      'circular-spectrum': 'Circular Spectrum',
      'particles': 'Particles',
      'geometric': 'Geometric',
      'kaleidoscope': 'Kaleidoscope',
      'tunnel': 'Tunnel',
      'liquid-waves': 'Liquid Waves',
      'radial-burst': 'Radial Burst',
      'fractal': 'Fractal',
      'aurora': 'Aurora',
      'orb': 'Orb',
      'mesh-grid': 'Mesh Grid',
      'plasma': 'Plasma',
      'flower-bloom': 'Flower Bloom',
      'meteor-shower': 'Meteor Shower',
      'dna-helix': 'DNA Helix',
      'sound-bars-3d': 'Sound Bars 3D',
      'equalizer-bars': 'Equalizer Bars',
      'pulse-rings': 'Pulse Rings',
      'butterfly-wings': 'Butterfly Wings',
      'crystal-lattice': 'Crystal Lattice',
    };
    return labels[type] || type;
  }
}
