// Audio Processor - Real-time audio analysis and processing
export interface AudioData {
  frequencies: number[];
  waveform: number[];
  bass: number;
  mid: number;
  treble: number;
  energy: number;
  peak: number;
}

export interface EqualizerSettings {
  bass: number; // -12 to +12 dB
  mid: number; // -12 to +12 dB
  treble: number; // -12 to +12 dB
  bands: number[]; // 30-point equalizer (1-999 Hz scale)
}

export class AudioProcessor {
  private audioContext: AudioContext | null = null;
  private analyser: AnalyserNode | null = null;
  private dataArray: Uint8Array<ArrayBuffer> | null = null;
  private waveformArray: Uint8Array<ArrayBuffer> | null = null;
  private frequencyData: number[] = [];
  private waveformData: number[] = [];
  private eqSettings: EqualizerSettings = {
    bass: 0,
    mid: 0,
    treble: 0,
    bands: Array(30).fill(0),
  };
  private biquadFilters: BiquadFilterNode[] = [];
  private gainNode: GainNode | null = null;

  constructor() {
    this.initializeAudioContext();
  }

  private initializeAudioContext() {
    try {
      const AudioContextClass = (window as any).AudioContext || (window as any).webkitAudioContext;
      if (AudioContextClass) {
        this.audioContext = new AudioContextClass() as AudioContext;
        this.analyser = this.audioContext.createAnalyser();
        this.analyser.fftSize = 2048;
        this.dataArray = new Uint8Array(this.analyser.frequencyBinCount) as Uint8Array<ArrayBuffer>;
        this.waveformArray = new Uint8Array(this.analyser.fftSize) as Uint8Array<ArrayBuffer>;
        this.gainNode = this.audioContext.createGain();
        this.gainNode.connect(this.analyser);
        this.analyser.connect(this.audioContext.destination);
        this.initializeEqualizer();
      }
    } catch (error) {
      console.warn('Web Audio API not available:', error);
    }
  }

  private initializeEqualizer() {
    if (!this.audioContext) return;

    // Create 30-point equalizer with biquad filters
    const frequencies = this.generateEqualizerFrequencies();
    for (let i = 0; i < frequencies.length; i++) {
      const filter = this.audioContext.createBiquadFilter();
      filter.type = 'peaking';
      filter.frequency.value = frequencies[i];
      filter.Q.value = 1;
      filter.gain.value = 0;

      if (i === 0) {
        filter.connect(this.gainNode!);
      } else {
        filter.connect(this.biquadFilters[i - 1]);
      }

      this.biquadFilters.push(filter);
    }
  }

  private generateEqualizerFrequencies(): number[] {
    // Generate 30 frequencies from 1 Hz to 999 Hz on a logarithmic scale
    const frequencies: number[] = [];
    const minFreq = 1;
    const maxFreq = 999;
    const logMin = Math.log10(minFreq);
    const logMax = Math.log10(maxFreq);

    for (let i = 0; i < 30; i++) {
      const logFreq = logMin + ((i / 29) * (logMax - logMin));
      frequencies.push(Math.pow(10, logFreq));
    }

    return frequencies;
  }

  /**
   * Update equalizer settings
   */
  updateEqualizerSettings(settings: Partial<EqualizerSettings>) {
    this.eqSettings = { ...this.eqSettings, ...settings };

    if (this.audioContext && this.biquadFilters.length > 0) {
      // Apply bass, mid, treble adjustments
      if (this.biquadFilters[0]) this.biquadFilters[0].gain.value = this.eqSettings.bass;
      if (this.biquadFilters[14]) this.biquadFilters[14].gain.value = this.eqSettings.mid;
      if (this.biquadFilters[29]) this.biquadFilters[29].gain.value = this.eqSettings.treble;

      // Apply 30-point band adjustments
      for (let i = 0; i < Math.min(this.eqSettings.bands.length, this.biquadFilters.length); i++) {
        this.biquadFilters[i].gain.value = (this.eqSettings.bands[i] - 50) * 0.24; // Convert 0-100 to -12 to +12 dB
      }
    }
  }

  /**
   * Get current audio data for visualization
   */
  getAudioData(): AudioData {
    if (!this.analyser || !this.dataArray) {
      return {
        frequencies: Array(128).fill(0),
        waveform: Array(512).fill(0),
        bass: 0,
        mid: 0,
        treble: 0,
        energy: 0,
        peak: 0,
      };
    }

    // Get frequency data
    this.analyser.getByteFrequencyData(this.dataArray);
    this.frequencyData = Array.from(this.dataArray).slice(0, 128);

    // Get waveform data
    if (!this.waveformArray) {
      this.waveformArray = new Uint8Array(this.analyser.fftSize) as Uint8Array<ArrayBuffer>;
    }
    this.analyser.getByteTimeDomainData(this.waveformArray);
    this.waveformData = Array.from(this.waveformArray).map((v) => (v - 128) / 128);

    // Calculate frequency bands
    const bass = this.calculateBandEnergy(0, 10);
    const mid = this.calculateBandEnergy(40, 90);
    const treble = this.calculateBandEnergy(100, 127);
    const energy = (bass + mid + treble) / 3;
    const peak = Math.max(...this.frequencyData) / 255;

    return {
      frequencies: this.frequencyData.map((v) => v / 255),
      waveform: this.waveformData,
      bass,
      mid,
      treble,
      energy,
      peak,
    };
  }

  private calculateBandEnergy(start: number, end: number): number {
    if (!this.frequencyData) return 0;
    const slice = this.frequencyData.slice(start, end + 1);
    const sum = slice.reduce((a, b) => a + b, 0);
    return (sum / (end - start + 1)) / 255;
  }

  /**
   * Connect audio source to processor
   */
  connectAudioSource(source: AudioNode) {
    if (this.gainNode && this.biquadFilters.length > 0) {
      source.connect(this.biquadFilters[this.biquadFilters.length - 1]);
    }
  }

  /**
   * Get audio context
   */
  getAudioContext(): AudioContext | null {
    return this.audioContext;
  }

  /**
   * Get gain node for volume control
   */
  getGainNode(): GainNode | null {
    return this.gainNode;
  }

  /**
   * Resume audio context (required for user interaction)
   */
  async resumeAudioContext() {
    if (this.audioContext && this.audioContext.state === 'suspended') {
      await this.audioContext.resume();
    }
  }
}

// Singleton instance
let audioProcessor: AudioProcessor | null = null;

export function getAudioProcessor(): AudioProcessor {
  if (!audioProcessor) {
    audioProcessor = new AudioProcessor();
  }
  return audioProcessor;
}
