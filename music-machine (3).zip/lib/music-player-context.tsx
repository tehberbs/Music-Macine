import React, { createContext, useContext, useReducer, useCallback, ReactNode } from 'react';
import { setAudioModeAsync } from 'expo-audio';

export interface Track {
  id: string;
  uri: string;
  title: string;
  artist: string;
  duration: number;
  isLocal: boolean;
  source: 'local' | 'youtube';
}

export interface PlayerState {
  currentTrack: Track | null;
  isPlaying: boolean;
  currentTime: number;
  queue: Track[];
  queueIndex: number;
  volume: number;
  isMuted: boolean;
  visualizationType: number;
  eqValues: number[];
  stemControls: {
    drums: number;
    guitar: number;
    synth: number;
    vocals: number;
  };
}

type PlayerAction =
  | { type: 'SET_CURRENT_TRACK'; payload: Track }
  | { type: 'PLAY' }
  | { type: 'PAUSE' }
  | { type: 'SET_TIME'; payload: number }
  | { type: 'SET_QUEUE'; payload: Track[] }
  | { type: 'SET_QUEUE_INDEX'; payload: number }
  | { type: 'SET_VOLUME'; payload: number }
  | { type: 'TOGGLE_MUTE' }
  | { type: 'SET_VISUALIZER'; payload: number }
  | { type: 'SET_EQ'; payload: number[] }
  | { type: 'SET_STEM_CONTROL'; payload: { key: keyof PlayerState['stemControls']; value: number } };

const initialState: PlayerState = {
  currentTrack: null,
  isPlaying: false,
  currentTime: 0,
  queue: [],
  queueIndex: 0,
  volume: 1,
  isMuted: false,
  visualizationType: 0,
  eqValues: Array(30).fill(0),
  stemControls: {
    drums: 0,
    guitar: 0,
    synth: 0,
    vocals: 0,
  },
};

function playerReducer(state: PlayerState, action: PlayerAction): PlayerState {
  switch (action.type) {
    case 'SET_CURRENT_TRACK':
      return { ...state, currentTrack: action.payload };
    case 'PLAY':
      return { ...state, isPlaying: true };
    case 'PAUSE':
      return { ...state, isPlaying: false };
    case 'SET_TIME':
      return { ...state, currentTime: action.payload };
    case 'SET_QUEUE':
      return { ...state, queue: action.payload };
    case 'SET_QUEUE_INDEX':
      return { ...state, queueIndex: action.payload };
    case 'SET_VOLUME':
      return { ...state, volume: Math.max(0, Math.min(1, action.payload)) };
    case 'TOGGLE_MUTE':
      return { ...state, isMuted: !state.isMuted };
    case 'SET_VISUALIZER':
      return { ...state, visualizationType: action.payload };
    case 'SET_EQ':
      return { ...state, eqValues: action.payload };
    case 'SET_STEM_CONTROL':
      return {
        ...state,
        stemControls: {
          ...state.stemControls,
          [action.payload.key]: action.payload.value,
        },
      };
    default:
      return state;
  }
}

interface MusicPlayerContextType {
  state: PlayerState;
  playTrack: (track: Track) => void;
  pauseTrack: () => void;
  resumeTrack: () => void;
  setCurrentTime: (time: number) => void;
  setQueue: (tracks: Track[]) => void;
  setQueueIndex: (index: number) => void;
  setVolume: (volume: number) => void;
  toggleMute: () => void;
  setVisualizerType: (type: number) => void;
  setEQValues: (values: number[]) => void;
  setStemControl: (key: keyof PlayerState['stemControls'], value: number) => void;
  nextTrack: () => void;
  previousTrack: () => void;
}

const MusicPlayerContext = createContext<MusicPlayerContextType | undefined>(undefined);

export function MusicPlayerProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(playerReducer, initialState);

  // Initialize audio mode on mount
  React.useEffect(() => {
    const initAudio = async () => {
      try {
        await setAudioModeAsync({
          playsInSilentMode: true,
        });
      } catch (error) {
        console.error('Failed to set audio mode:', error);
      }
    };
    initAudio();
  }, []);

  const playTrack = useCallback((track: Track) => {
    dispatch({ type: 'SET_CURRENT_TRACK', payload: track });
    dispatch({ type: 'PLAY' });
  }, []);

  const pauseTrack = useCallback(() => {
    dispatch({ type: 'PAUSE' });
  }, []);

  const resumeTrack = useCallback(() => {
    dispatch({ type: 'PLAY' });
  }, []);

  const setCurrentTime = useCallback((time: number) => {
    dispatch({ type: 'SET_TIME', payload: time });
  }, []);

  const setQueue = useCallback((tracks: Track[]) => {
    dispatch({ type: 'SET_QUEUE', payload: tracks });
  }, []);

  const setQueueIndex = useCallback((index: number) => {
    dispatch({ type: 'SET_QUEUE_INDEX', payload: index });
  }, []);

  const setVolume = useCallback((volume: number) => {
    dispatch({ type: 'SET_VOLUME', payload: volume });
  }, []);

  const toggleMute = useCallback(() => {
    dispatch({ type: 'TOGGLE_MUTE' });
  }, []);

  const setVisualizerType = useCallback((type: number) => {
    dispatch({ type: 'SET_VISUALIZER', payload: type });
  }, []);

  const setEQValues = useCallback((values: number[]) => {
    dispatch({ type: 'SET_EQ', payload: values });
  }, []);

  const setStemControl = useCallback(
    (key: keyof PlayerState['stemControls'], value: number) => {
      dispatch({ type: 'SET_STEM_CONTROL', payload: { key, value } });
    },
    []
  );

  const nextTrack = useCallback(() => {
    if (state.queue.length > 0) {
      const nextIndex = (state.queueIndex + 1) % state.queue.length;
      dispatch({ type: 'SET_QUEUE_INDEX', payload: nextIndex });
      playTrack(state.queue[nextIndex]);
    }
  }, [state.queue, state.queueIndex, playTrack]);

  const previousTrack = useCallback(() => {
    if (state.queue.length > 0) {
      const prevIndex = (state.queueIndex - 1 + state.queue.length) % state.queue.length;
      dispatch({ type: 'SET_QUEUE_INDEX', payload: prevIndex });
      playTrack(state.queue[prevIndex]);
    }
  }, [state.queue, state.queueIndex, playTrack]);

  const value: MusicPlayerContextType = {
    state,
    playTrack,
    pauseTrack,
    resumeTrack,
    setCurrentTime,
    setQueue,
    setQueueIndex,
    setVolume,
    toggleMute,
    setVisualizerType,
    setEQValues,
    setStemControl,
    nextTrack,
    previousTrack,
  };

  return (
    <MusicPlayerContext.Provider value={value}>
      {children}
    </MusicPlayerContext.Provider>
  );
}

export function useMusicPlayer() {
  const context = useContext(MusicPlayerContext);
  if (context === undefined) {
    throw new Error('useMusicPlayer must be used within MusicPlayerProvider');
  }
  return context;
}
