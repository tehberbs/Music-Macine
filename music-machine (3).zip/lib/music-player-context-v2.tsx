import React, {
  createContext,
  useContext,
  useState,
  useCallback,
  useEffect,
  useRef,
} from 'react';
import {
  createAudioPlayer,
  setAudioModeAsync,
  useAudioPlayerStatus,
  type AudioPlayer,
} from 'expo-audio';
import { useKeepAwake } from 'expo-keep-awake';
export type RepeatMode = 'off' | 'one' | 'all';

export interface Track {
  id: string;
  title: string;
  artist?: string;
  album?: string;
  duration: number;
  uri: string;
  coverColor?: string;
}

export interface MusicPlayerContextType {
  currentTrack: Track | null;
  isPlaying: boolean;
  currentTime: number;
  duration: number;
  queue: Track[];
  currentIndex: number;
  repeatMode: RepeatMode;
  isShuffle: boolean;
  eqBands: number[];
  drumVolume: number;
  guitarVolume: number;
  synthVolume: number;
  vocalVolume: number;
  frequencies: number[];
  waveform: number[];
  currentVisualizerType: number;
  playTrack: (track: Track, newQueue?: Track[]) => Promise<void>;
  pauseTrack: () => void;
  resumeTrack: () => void;
  nextTrack: () => Promise<void>;
  previousTrack: () => Promise<void>;
  seekTo: (time: number) => void;
  setQueue: (tracks: Track[]) => void;
  addToQueue: (track: Track) => void;
  removeFromQueue: (index: number) => void;
  toggleRepeat: () => void;
  toggleShuffle: () => void;
  setEQBand: (bandIndex: number, value: number) => void;
  resetEQ: () => void;
  setDrumVolume: (volume: number) => void;
  setGuitarVolume: (volume: number) => void;
  setSynthVolume: (volume: number) => void;
  setVocalVolume: (volume: number) => void;
  setVisualizerType: (type: number) => void;
  updateFrequencies: (frequencies: number[]) => void;
  updateWaveform: (waveform: number[]) => void;
}

export const MusicPlayerContext = createContext<MusicPlayerContextType | undefined>(undefined);



export function MusicPlayerProvider({ children }: { children: React.ReactNode }) {
  useKeepAwake();

  // We manage a ref to the current AudioPlayer instance so we can swap it on track change
  const playerRef = useRef<AudioPlayer | null>(null);

  const [currentTrack, setCurrentTrack] = useState<Track | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [queue, setQueueState] = useState<Track[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [repeatMode, setRepeatMode] = useState<RepeatMode>('off');
  const [isShuffle, setIsShuffle] = useState(false);
  const [eqBands, setEQBands] = useState<number[]>(Array(30).fill(0));
  const [drumVolume, setDrumVolume] = useState(1);
  const [guitarVolume, setGuitarVolume] = useState(1);
  const [synthVolume, setSynthVolume] = useState(1);
  const [vocalVolume, setVocalVolume] = useState(1);
  const [frequencies, setFrequencies] = useState<number[]>(Array(64).fill(0));
  const [waveformState, setWaveformState] = useState<number[]>(Array(256).fill(0));
  const [currentVisualizerType, setCurrentVisualizerType] = useState(0);

  // Initialize audio mode for background playback
  useEffect(() => {
    const initAudioMode = async () => {
      try {
        // Enable background playback
        await setAudioModeAsync({
          playsInSilentMode: true,
        });


      } catch (err) {
        console.warn('[MusicPlayer] Audio mode initialization failed:', err);
      }
    };

    initAudioMode();
  }, []);

  // Poll playback position every 500ms when playing
  useEffect(() => {
    if (!isPlaying) return;
    const interval = setInterval(() => {
      const p = playerRef.current;
      if (p) {
        try {
          const pos = (p as any).currentTime ?? 0;
          const dur = (p as any).duration ?? 0;
          setCurrentTime(pos);
          if (dur > 0) setDuration(dur);
          // Auto-advance when track ends
          if (dur > 0 && pos >= dur - 0.5) {
            handleTrackEnd();
          }
        } catch (_) {}
      }
    }, 500);
    return () => clearInterval(interval);
  }, [isPlaying, currentIndex, queue, repeatMode, isShuffle]);

  // Animate visualizer frequencies when playing
  useEffect(() => {
    if (!isPlaying) {
      setFrequencies(Array(64).fill(0));
      return;
    }
    const interval = setInterval(() => {
      const t = Date.now() * 0.001;
      setFrequencies(
        Array(64)
          .fill(0)
          .map((_, i) => Math.abs(Math.sin(t * (0.5 + i * 0.05) + i * 0.3)) * 0.85 + 0.05)
      );
      setWaveformState(
        Array(256)
          .fill(0)
          .map((_, i) => Math.sin((i / 256) * Math.PI * 4 + t) * 0.5)
      );
    }, 50);
    return () => clearInterval(interval);
  }, [isPlaying]);

  const handleTrackEnd = useCallback(() => {
    setQueueState((q) => {
      setCurrentIndex((idx) => {
        if (repeatMode === 'one') {
          const p = playerRef.current;
          if (p) { try { p.seekTo(0); p.play(); } catch (_) {} }
          return idx;
        }
        let next = isShuffle ? Math.floor(Math.random() * q.length) : idx + 1;
        if (next >= q.length) {
          if (repeatMode === 'all') next = 0;
          else { setIsPlaying(false); return idx; }
        }
        const nextTrack = q[next];
        if (nextTrack) loadAndPlay(nextTrack);
        return next;
      });
      return q;
    });
  }, [repeatMode, isShuffle]);

  const loadAndPlay = useCallback(async (track: Track) => {
    try {
      console.log('[MusicPlayer] Loading track:', track.title, 'URI:', track.uri);

      // Ensure audio mode is set for background playback
      try {
        await setAudioModeAsync({
          playsInSilentMode: true,
        });
      } catch (modeErr) {
        console.warn('[MusicPlayer] setAudioModeAsync failed:', modeErr);
      }

      // Remove previous player
      if (playerRef.current) {
        try { playerRef.current.pause(); } catch (_) {}
        try { playerRef.current.remove(); } catch (_) {}
        playerRef.current = null;
      }

      setCurrentTrack(track);
      setCurrentTime(0);
      setDuration(track.duration || 0);
      setIsPlaying(false);

      // Create player — pass URI directly as string for file:// and http:// URIs
      const source = track.uri.startsWith('http') ? { uri: track.uri } : { uri: track.uri };
      const newPlayer = createAudioPlayer(source);
      playerRef.current = newPlayer;

      // Wait for player to be ready (expo-audio needs a tick to initialize)
      await new Promise((r) => setTimeout(r, 300));

      if (playerRef.current === newPlayer) {
        try {
          await newPlayer.play();
          setIsPlaying(true);
          console.log('[MusicPlayer] Playing:', track.title);
        } catch (playErr) {
          console.error('[MusicPlayer] Play error:', playErr);
          setIsPlaying(false);
        }
      }
    } catch (err) {
      console.error('[MusicPlayer] loadAndPlay error:', err);
      setIsPlaying(false);
    }
  }, []);

  const playTrack = useCallback(async (track: Track, newQueue?: Track[]) => {
    if (newQueue) {
      setQueueState(newQueue);
      const index = newQueue.findIndex((t) => t.id === track.id);
      setCurrentIndex(index >= 0 ? index : 0);
    }
    await loadAndPlay(track);
  }, [loadAndPlay]);

  const pauseTrack = useCallback(() => {
    const p = playerRef.current;
    if (p) {
      try {
        p.pause();
        setIsPlaying(false);
      } catch (err) {
        console.error('[MusicPlayer] Pause error:', err);
      }
    }
  }, []);

  const resumeTrack = useCallback(() => {
    const p = playerRef.current;
    if (p) {
      try {
        p.play();
        setIsPlaying(true);
      } catch (err) {
        console.error('[MusicPlayer] Resume error:', err);
      }
    }
  }, []);

  const nextTrack = useCallback(async () => {
    setCurrentIndex((idx) => {
      let next = isShuffle ? Math.floor(Math.random() * queue.length) : idx + 1;
      if (next >= queue.length) next = repeatMode === 'all' ? 0 : idx;
      if (next !== idx && queue[next]) {
        loadAndPlay(queue[next]);
      }
      return next;
    });
  }, [queue, isShuffle, repeatMode, loadAndPlay]);

  const previousTrack = useCallback(async () => {
    setCurrentIndex((idx) => {
      let prev = idx - 1;
      if (prev < 0) prev = repeatMode === 'all' ? queue.length - 1 : 0;
      if (prev !== idx && queue[prev]) {
        loadAndPlay(queue[prev]);
      }
      return prev;
    });
  }, [queue, repeatMode, loadAndPlay]);

  const seekTo = useCallback((time: number) => {
    const p = playerRef.current;
    if (p) {
      try {
        p.seekTo(time);
      } catch (err) {
        console.error('[MusicPlayer] Seek error:', err);
      }
    }
  }, []);

  const setQueue = useCallback((tracks: Track[]) => {
    setQueueState(tracks);
  }, []);

  const addToQueue = useCallback((track: Track) => {
    setQueueState((q) => [...q, track]);
  }, []);

  const removeFromQueue = useCallback((index: number) => {
    setQueueState((q) => q.filter((_, i) => i !== index));
  }, []);

  const toggleRepeat = useCallback(() => {
    setRepeatMode((mode) => {
      const modes: RepeatMode[] = ['off', 'one', 'all'];
      const currentIndex = modes.indexOf(mode);
      return modes[(currentIndex + 1) % modes.length];
    });
  }, []);

  const toggleShuffle = useCallback(() => {
    setIsShuffle((s) => !s);
  }, []);

  const setEQBand = useCallback((bandIndex: number, value: number) => {
    setEQBands((bands) => {
      const newBands = [...bands];
      newBands[bandIndex] = value;
      return newBands;
    });
  }, []);

  const resetEQ = useCallback(() => {
    setEQBands(Array(30).fill(0));
  }, []);

  const value: MusicPlayerContextType = {
    currentTrack,
    isPlaying,
    currentTime,
    duration,
    queue,
    currentIndex,
    repeatMode,
    isShuffle,
    eqBands,
    drumVolume,
    guitarVolume,
    synthVolume,
    vocalVolume,
    frequencies,
    waveform: waveformState,
    currentVisualizerType,
    playTrack,
    pauseTrack,
    resumeTrack,
    nextTrack,
    previousTrack,
    seekTo,
    setQueue,
    addToQueue,
    removeFromQueue,
    toggleRepeat,
    toggleShuffle,
    setEQBand,
    resetEQ,
    setDrumVolume,
    setGuitarVolume,
    setSynthVolume,
    setVocalVolume,
    setVisualizerType: setCurrentVisualizerType,
    updateFrequencies: setFrequencies,
    updateWaveform: setWaveformState,
  };

  return (
    <MusicPlayerContext.Provider value={value}>
      {children}
    </MusicPlayerContext.Provider>
  );
}

export function useMusicPlayer(): MusicPlayerContextType {
  const context = useContext(MusicPlayerContext);
  if (!context) {
    throw new Error('useMusicPlayer must be used within MusicPlayerProvider');
  }
  return context;
}
