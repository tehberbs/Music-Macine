/**
 * Real Stem Separation Service
 * Implements frequency-based stem separation using Web Audio API
 * Separates audio into different frequency bands corresponding to instruments
 */

export interface StemSeparationResult {
  drums: Float32Array;
  bass: Float32Array;
  guitar: Float32Array;
  vocals: Float32Array;
  other: Float32Array;
}

export class RealStemSeparator {
  private audioContext: AudioContext | null = null;
  private analyser: AnalyserNode | null = null;

  constructor() {
    // Initialize on first use
  }

  /**
   * Initialize Web Audio API context
   */
  private initializeAudioContext(): AudioContext {
    if (!this.audioContext) {
      this.audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
    }
    return this.audioContext;
  }

  /**
   * Separate audio into stems using frequency analysis
   * Frequency ranges:
   * - Drums: 20-200 Hz (kick and snare)
   * - Bass: 40-250 Hz (bass guitar, low synth)
   * - Guitar: 250-2000 Hz (guitars, mid-range instruments)
   * - Vocals: 80-8000 Hz (human voice range)
   * - Other: 2000+ Hz (high-frequency instruments)
   */
  async separateAudio(audioBuffer: AudioBuffer): Promise<StemSeparationResult> {
    const audioContext = this.initializeAudioContext();
    const sampleRate = audioBuffer.sampleRate;
    const numberOfChannels = audioBuffer.numberOfChannels;
    const length = audioBuffer.length;

    // Create offline context for processing
    const offlineContext = new OfflineAudioContext(
      numberOfChannels,
      length,
      sampleRate
    );

    // Create source
    const source = offlineContext.createBufferSource();
    source.buffer = audioBuffer;

    // Create filter nodes for each stem
    const drumFilter = offlineContext.createBiquadFilter();
    drumFilter.type = 'lowpass';
    drumFilter.frequency.value = 200; // Drums: 20-200 Hz

    const bassFilter = offlineContext.createBiquadFilter();
    bassFilter.type = 'bandpass';
    bassFilter.frequency.value = 100; // Bass: 40-250 Hz
    bassFilter.Q.value = 0.5;

    const guitarFilter = offlineContext.createBiquadFilter();
    guitarFilter.type = 'bandpass';
    guitarFilter.frequency.value = 1000; // Guitar: 250-2000 Hz
    guitarFilter.Q.value = 0.5;

    const vocalFilter = offlineContext.createBiquadFilter();
    vocalFilter.type = 'bandpass';
    vocalFilter.frequency.value = 2000; // Vocals: 80-8000 Hz
    vocalFilter.Q.value = 0.3;

    const otherFilter = offlineContext.createBiquadFilter();
    otherFilter.type = 'highpass';
    otherFilter.frequency.value = 2000; // Other: 2000+ Hz

    // Connect source to filters
    source.connect(drumFilter);
    source.connect(bassFilter);
    source.connect(guitarFilter);
    source.connect(vocalFilter);
    source.connect(otherFilter);

    // Connect filters to destination for rendering
    drumFilter.connect(offlineContext.destination);
    bassFilter.connect(offlineContext.destination);
    guitarFilter.connect(offlineContext.destination);
    vocalFilter.connect(offlineContext.destination);
    otherFilter.connect(offlineContext.destination);

    // Start playback
    source.start(0);

    try {
      // Render the audio
      const renderedBuffer = await offlineContext.startRendering();

      // Extract stems from rendered buffer
      const stems: StemSeparationResult = {
        drums: this.extractStemFromBuffer(renderedBuffer, 0),
        bass: this.extractStemFromBuffer(renderedBuffer, 1),
        guitar: this.extractStemFromBuffer(renderedBuffer, 2),
        vocals: this.extractStemFromBuffer(renderedBuffer, 3),
        other: this.extractStemFromBuffer(renderedBuffer, 4),
      };

      return stems;
    } catch (error) {
      console.error('Stem separation failed:', error);
      // Return original audio in all stems as fallback
      const originalData = audioBuffer.getChannelData(0);
      return {
        drums: originalData,
        bass: originalData,
        guitar: originalData,
        vocals: originalData,
        other: originalData,
      };
    }
  }

  /**
   * Extract stem data from rendered buffer
   */
  private extractStemFromBuffer(buffer: AudioBuffer, channelIndex: number): Float32Array {
    if (channelIndex < buffer.numberOfChannels) {
      return buffer.getChannelData(channelIndex);
    }
    // Return silence if channel doesn't exist
    return new Float32Array(buffer.length);
  }

  /**
   * Apply stem volume adjustments to audio
   */
  applyVolumes(
    stems: StemSeparationResult,
    drumVolume: number,
    bassVolume: number,
    guitarVolume: number,
    vocalVolume: number
  ): Float32Array {
    const length = stems.drums.length;
    const result = new Float32Array(length);

    const drumGain = drumVolume / 100;
    const bassGain = bassVolume / 100;
    const guitarGain = guitarVolume / 100;
    const vocalGain = vocalVolume / 100;

    for (let i = 0; i < length; i++) {
      result[i] =
        stems.drums[i] * drumGain +
        stems.bass[i] * bassGain +
        stems.guitar[i] * guitarGain +
        stems.vocals[i] * vocalGain;
    }

    return result;
  }

  /**
   * Detect dominant frequencies in audio
   */
  async detectDominantFrequencies(audioBuffer: AudioBuffer): Promise<{
    drums: number;
    bass: number;
    guitar: number;
    vocals: number;
  }> {
    const audioContext = this.initializeAudioContext();
    const analyser = audioContext.createAnalyser();
    analyser.fftSize = 2048;

    const dataArray = new Uint8Array(analyser.frequencyBinCount);
    analyser.getByteFrequencyData(dataArray);

    // Calculate average frequency in each range
    const drumFreq = this.getAverageFrequency(dataArray, 0, 50); // 20-200 Hz
    const bassFreq = this.getAverageFrequency(dataArray, 50, 100); // 40-250 Hz
    const guitarFreq = this.getAverageFrequency(dataArray, 100, 500); // 250-2000 Hz
    const vocalFreq = this.getAverageFrequency(dataArray, 200, 2000); // 80-8000 Hz

    return {
      drums: drumFreq,
      bass: bassFreq,
      guitar: guitarFreq,
      vocals: vocalFreq,
    };
  }

  /**
   * Calculate average frequency in range
   */
  private getAverageFrequency(dataArray: Uint8Array, start: number, end: number): number {
    let sum = 0;
    const count = end - start;

    for (let i = start; i < end; i++) {
      sum += dataArray[i];
    }

    return count > 0 ? sum / count : 0;
  }

  /**
   * Cleanup audio context
   */
  dispose(): void {
    if (this.audioContext) {
      this.audioContext.close();
      this.audioContext = null;
    }
  }
}

// Singleton instance
let instance: RealStemSeparator | null = null;

export function getRealStemSeparator(): RealStemSeparator {
  if (!instance) {
    instance = new RealStemSeparator();
  }
  return instance;
}
