// Playlist Management Service
import AsyncStorage from '@react-native-async-storage/async-storage';

export interface Playlist {
  id: string;
  name: string;
  description?: string;
  trackIds: string[];
  createdAt: number;
  updatedAt: number;
  coverColor?: string;
}

export interface PlaylistTrack {
  trackId: string;
  addedAt: number;
}

const PLAYLISTS_KEY = 'music_machine_playlists';
const PLAYLIST_PREFIX = 'playlist_';

export class PlaylistService {
  private playlists: Map<string, Playlist> = new Map();
  private listeners: Set<(playlists: Playlist[]) => void> = new Set();

  constructor() {
    this.initialize();
  }

  /**
   * Initialize and load playlists from storage
   */
  private async initialize() {
    try {
      const stored = await AsyncStorage.getItem(PLAYLISTS_KEY);
      if (stored) {
        const playlistsArray = JSON.parse(stored);
        playlistsArray.forEach((playlist: Playlist) => {
          this.playlists.set(playlist.id, playlist);
        });
      }
    } catch (error) {
      console.error('Failed to load playlists:', error);
    }
  }

  /**
   * Create a new playlist
   */
  async createPlaylist(name: string, description?: string, coverColor?: string): Promise<Playlist> {
    const id = `playlist_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    const now = Date.now();

    const playlist: Playlist = {
      id,
      name,
      description,
      trackIds: [],
      createdAt: now,
      updatedAt: now,
      coverColor: coverColor || '#7C3AED',
    };

    this.playlists.set(id, playlist);
    await this.saveToStorage();
    this.notifyListeners();

    return playlist;
  }

  /**
   * Get all playlists
   */
  getAllPlaylists(): Playlist[] {
    return Array.from(this.playlists.values());
  }

  /**
   * Get playlist by ID
   */
  getPlaylistById(id: string): Playlist | undefined {
    return this.playlists.get(id);
  }

  /**
   * Update playlist
   */
  async updatePlaylist(id: string, updates: Partial<Playlist>): Promise<Playlist | null> {
    const playlist = this.playlists.get(id);
    if (!playlist) return null;

    const updated: Playlist = {
      ...playlist,
      ...updates,
      id: playlist.id, // Don't allow ID change
      createdAt: playlist.createdAt, // Don't allow creation time change
      updatedAt: Date.now(),
    };

    this.playlists.set(id, updated);
    await this.saveToStorage();
    this.notifyListeners();

    return updated;
  }

  /**
   * Delete playlist
   */
  async deletePlaylist(id: string): Promise<boolean> {
    const deleted = this.playlists.delete(id);
    if (deleted) {
      await this.saveToStorage();
      this.notifyListeners();
    }
    return deleted;
  }

  /**
   * Add track to playlist
   */
  async addTrackToPlaylist(playlistId: string, trackId: string): Promise<boolean> {
    const playlist = this.playlists.get(playlistId);
    if (!playlist) return false;

    // Avoid duplicates
    if (playlist.trackIds.includes(trackId)) return false;

    playlist.trackIds.push(trackId);
    playlist.updatedAt = Date.now();

    await this.saveToStorage();
    this.notifyListeners();

    return true;
  }

  /**
   * Remove track from playlist
   */
  async removeTrackFromPlaylist(playlistId: string, trackId: string): Promise<boolean> {
    const playlist = this.playlists.get(playlistId);
    if (!playlist) return false;

    const index = playlist.trackIds.indexOf(trackId);
    if (index === -1) return false;

    playlist.trackIds.splice(index, 1);
    playlist.updatedAt = Date.now();

    await this.saveToStorage();
    this.notifyListeners();

    return true;
  }

  /**
   * Reorder tracks in playlist
   */
  async reorderPlaylistTracks(playlistId: string, fromIndex: number, toIndex: number): Promise<boolean> {
    const playlist = this.playlists.get(playlistId);
    if (!playlist || fromIndex < 0 || toIndex < 0 || fromIndex >= playlist.trackIds.length || toIndex >= playlist.trackIds.length) {
      return false;
    }

    const [removed] = playlist.trackIds.splice(fromIndex, 1);
    playlist.trackIds.splice(toIndex, 0, removed);
    playlist.updatedAt = Date.now();

    await this.saveToStorage();
    this.notifyListeners();

    return true;
  }

  /**
   * Get tracks in playlist
   */
  getPlaylistTracks(playlistId: string): string[] {
    const playlist = this.playlists.get(playlistId);
    return playlist ? [...playlist.trackIds] : [];
  }

  /**
   * Check if track is in playlist
   */
  isTrackInPlaylist(playlistId: string, trackId: string): boolean {
    const playlist = this.playlists.get(playlistId);
    return playlist ? playlist.trackIds.includes(trackId) : false;
  }

  /**
   * Clear all tracks from playlist
   */
  async clearPlaylist(playlistId: string): Promise<boolean> {
    const playlist = this.playlists.get(playlistId);
    if (!playlist) return false;

    playlist.trackIds = [];
    playlist.updatedAt = Date.now();

    await this.saveToStorage();
    this.notifyListeners();

    return true;
  }

  /**
   * Duplicate playlist
   */
  async duplicatePlaylist(playlistId: string): Promise<Playlist | null> {
    const original = this.playlists.get(playlistId);
    if (!original) return null;

    const newPlaylist = await this.createPlaylist(
      `${original.name} (Copy)`,
      original.description,
      original.coverColor
    );

    newPlaylist.trackIds = [...original.trackIds];
    this.playlists.set(newPlaylist.id, newPlaylist);

    await this.saveToStorage();
    this.notifyListeners();

    return newPlaylist;
  }

  /**
   * Merge playlists
   */
  async mergePlaylistsAsync(sourcePlaylistIds: string[], targetPlaylistId: string): Promise<boolean> {
    const targetPlaylist = this.playlists.get(targetPlaylistId);
    if (!targetPlaylist) return false;

    for (const sourceId of sourcePlaylistIds) {
      const sourcePlaylist = this.playlists.get(sourceId);
      if (sourcePlaylist) {
        for (const trackId of sourcePlaylist.trackIds) {
          if (!targetPlaylist.trackIds.includes(trackId)) {
            targetPlaylist.trackIds.push(trackId);
          }
        }
      }
    }

    targetPlaylist.updatedAt = Date.now();
    await this.saveToStorage();
    this.notifyListeners();

    return true;
  }

  /**
   * Subscribe to playlist changes
   */
  subscribe(listener: (playlists: Playlist[]) => void): () => void {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  /**
   * Notify all listeners
   */
  private notifyListeners() {
    const playlists = this.getAllPlaylists();
    this.listeners.forEach((listener) => listener(playlists));
  }

  /**
   * Save playlists to storage
   */
  private async saveToStorage() {
    try {
      const playlistsArray = Array.from(this.playlists.values());
      await AsyncStorage.setItem(PLAYLISTS_KEY, JSON.stringify(playlistsArray));
    } catch (error) {
      console.error('Failed to save playlists:', error);
    }
  }

  /**
   * Export playlists as JSON
   */
  exportPlaylistsAsJSON(): string {
    const playlists = this.getAllPlaylists();
    return JSON.stringify(playlists, null, 2);
  }

  /**
   * Import playlists from JSON
   */
  async importPlaylistsFromJSON(json: string): Promise<boolean> {
    try {
      const imported = JSON.parse(json);
      if (!Array.isArray(imported)) return false;

      for (const playlist of imported) {
        if (playlist.id && playlist.name && Array.isArray(playlist.trackIds)) {
          this.playlists.set(playlist.id, playlist);
        }
      }

      await this.saveToStorage();
      this.notifyListeners();

      return true;
    } catch (error) {
      console.error('Failed to import playlists:', error);
      return false;
    }
  }
}

// Singleton instance
let playlistService: PlaylistService | null = null;

export function getPlaylistService(): PlaylistService {
  if (!playlistService) {
    playlistService = new PlaylistService();
  }
  return playlistService;
}
