/**
 * Audio Visualizer Renderer
 * Real-time audio visualization using Web Audio API
 */

export interface VisualizerData {
  frequencies: Uint8Array;
  waveform: Uint8Array;
  spectrum: number[];
  bass: number;
  mid: number;
  treble: number;
  energy: number;
}

export class AudioVisualizerRenderer {
  private audioContext: AudioContext | null = null;
  private analyser: AnalyserNode | null = null;
  private dataArray: Uint8Array<ArrayBuffer> | null = null;
  private waveformData: Uint8Array<ArrayBuffer> | null = null;
  private animationFrameId: number | null = null;
  private isRunning = false;

  constructor() {
    this.initializeAudioContext();
  }

  /**
   * Initialize Web Audio API context
   */
  private initializeAudioContext(): void {
    if (!this.audioContext) {
      try {
        const AudioContextClass = (window as any).AudioContext || (window as any).webkitAudioContext;
        this.audioContext = new AudioContextClass();
      } catch (error) {
        console.error('Web Audio API not supported:', error);
      }
    }
  }

  /**
   * Connect audio source to analyser
   */
  connectAudioSource(source: AudioNode): void {
    if (!this.audioContext) return;

    if (!this.analyser) {
      this.analyser = this.audioContext.createAnalyser();
      this.analyser.fftSize = 2048;
      this.dataArray = new Uint8Array(this.analyser.frequencyBinCount) as Uint8Array<ArrayBuffer>;
      this.waveformData = new Uint8Array(this.analyser.fftSize) as Uint8Array<ArrayBuffer>;
    }

    source.connect(this.analyser);
    this.analyser.connect(this.audioContext.destination);
  }

  /**
   * Get current visualization data
   */
  getVisualizerData(): VisualizerData | null {
    if (!this.analyser || !this.dataArray || !this.waveformData) {
      return null;
    }

    // Get frequency data
    this.analyser.getByteFrequencyData(this.dataArray);
    this.analyser.getByteTimeDomainData(this.waveformData);

    // Calculate frequency bands
    const dataArray = this.dataArray;
    const length = dataArray.length;

    // Bass: 0-250 Hz (first ~10% of spectrum)
    const bassEnd = Math.floor(length * 0.1);
    const bass = this.getAverageFrequency(dataArray, 0, bassEnd) / 255;

    // Mid: 250-4000 Hz (middle 40% of spectrum)
    const midStart = bassEnd;
    const midEnd = Math.floor(length * 0.5);
    const mid = this.getAverageFrequency(dataArray, midStart, midEnd) / 255;

    // Treble: 4000+ Hz (top 50% of spectrum)
    const trebleStart = midEnd;
    const treble = this.getAverageFrequency(dataArray, trebleStart, length) / 255;

    // Overall energy
    const energy = (bass + mid + treble) / 3;

    // Create spectrum array (normalized to 0-1)
    const spectrum: number[] = [];
    const spectrumBands = 32;
    const bandSize = Math.floor(length / spectrumBands);

    for (let i = 0; i < spectrumBands; i++) {
      const start = i * bandSize;
      const end = start + bandSize;
      const bandValue = this.getAverageFrequency(dataArray, start, end) / 255;
      spectrum.push(bandValue);
    }

    return {
      frequencies: dataArray,
      waveform: this.waveformData,
      spectrum,
      bass,
      mid,
      treble,
      energy,
    };
  }

  /**
   * Calculate average frequency in range
   */
  private getAverageFrequency(dataArray: Uint8Array, start: number, end: number): number {
    let sum = 0;
    const count = end - start;

    for (let i = start; i < end; i++) {
      sum += dataArray[i];
    }

    return count > 0 ? sum / count : 0;
  }

  /**
   * Start continuous visualization updates
   */
  startVisualization(callback: (data: VisualizerData) => void): void {
    if (this.isRunning) return;

    this.isRunning = true;

    const update = () => {
      if (!this.isRunning) return;

      const data = this.getVisualizerData();
      if (data) {
        callback(data);
      }

      this.animationFrameId = requestAnimationFrame(update);
    };

    update();
  }

  /**
   * Stop visualization updates
   */
  stopVisualization(): void {
    this.isRunning = false;

    if (this.animationFrameId !== null) {
      cancelAnimationFrame(this.animationFrameId);
      this.animationFrameId = null;
    }
  }

  /**
   * Detect beat/kick
   */
  detectBeat(): boolean {
    if (!this.analyser || !this.dataArray) return false;

    this.analyser.getByteFrequencyData(this.dataArray);

    // Check if bass frequencies have sudden increase
    const bassEnd = Math.floor(this.dataArray.length * 0.1);
    const currentBass = this.getAverageFrequency(this.dataArray, 0, bassEnd);

    // Simple beat detection: if bass is above threshold
    return currentBass > 150;
  }

  /**
   * Cleanup resources
   */
  dispose(): void {
    this.stopVisualization();

    if (this.audioContext) {
      this.audioContext.close();
      this.audioContext = null;
    }

    this.analyser = null;
    this.dataArray = null;
    this.waveformData = null;
  }
}

// Singleton instance
let instance: AudioVisualizerRenderer | null = null;

export function getAudioVisualizerRenderer(): AudioVisualizerRenderer {
  if (!instance) {
    instance = new AudioVisualizerRenderer();
  }
  return instance;
}
