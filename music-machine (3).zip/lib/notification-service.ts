import { useNotification } from './notification-context';

/**
 * Notification service for triggering notifications from various app events
 * Use this to show notifications for playback, downloads, errors, etc.
 */
export class NotificationService {
  static instance: NotificationService | null = null;
  private notificationHook: ReturnType<typeof useNotification> | null = null;

  static getInstance() {
    if (!this.instance) {
      this.instance = new NotificationService();
    }
    return this.instance;
  }

  setNotificationHook(hook: ReturnType<typeof useNotification>) {
    this.notificationHook = hook;
  }

  private getHook() {
    if (!this.notificationHook) {
      throw new Error('NotificationService hook not initialized. Call setNotificationHook first.');
    }
    return this.notificationHook;
  }

  showSuccess(title: string, message: string, duration?: number) {
    const hook = this.getHook();
    return hook.show({
      type: 'success',
      title,
      message,
      duration: duration ?? 3000,
    });
  }

  showError(title: string, message: string, duration?: number) {
    const hook = this.getHook();
    return hook.show({
      type: 'error',
      title,
      message,
      duration: duration ?? 4000,
    });
  }

  showInfo(title: string, message: string, duration?: number) {
    const hook = this.getHook();
    return hook.show({
      type: 'info',
      title,
      message,
      duration: duration ?? 3000,
    });
  }

  showWarning(title: string, message: string, duration?: number) {
    const hook = this.getHook();
    return hook.show({
      type: 'warning',
      title,
      message,
      duration: duration ?? 4000,
    });
  }

  showDownload(title: string, message: string, action?: { label: string; onPress: () => void }) {
    const hook = this.getHook();
    return hook.show({
      type: 'download',
      title,
      message,
      duration: 0, // Indefinite until dismissed
      action,
    });
  }

  showPlayback(title: string, message: string, action?: { label: string; onPress: () => void }) {
    const hook = this.getHook();
    return hook.show({
      type: 'playback',
      title,
      message,
      duration: 3000,
      action,
    });
  }

  dismiss(id: string) {
    const hook = this.getHook();
    hook.hide(id);
  }

  clear() {
    const hook = this.getHook();
    hook.clear();
  }
}

/**
 * Hook to initialize notification service with the notification context
 * Call this once in your root layout or provider
 */
export function useNotificationService() {
  const notification = useNotification();
  const service = NotificationService.getInstance();

  // Set the hook once
  if (!service['notificationHook']) {
    service.setNotificationHook(notification);
  }

  return service;
}
