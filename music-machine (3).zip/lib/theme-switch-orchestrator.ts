import { useSharedValue, withTiming } from 'react-native-reanimated';

export interface ThemeTransitionState {
  isTransitioning: boolean;
  fromThemeId: string;
  toThemeId: string;
  progress: number;
}

export class ThemeSwitchOrchestrator {
  private static instance: ThemeSwitchOrchestrator;
  private transitionState: ThemeTransitionState = {
    isTransitioning: false,
    fromThemeId: 'default',
    toThemeId: 'default',
    progress: 0,
  };

  private constructor() {}

  static getInstance(): ThemeSwitchOrchestrator {
    if (!ThemeSwitchOrchestrator.instance) {
      ThemeSwitchOrchestrator.instance = new ThemeSwitchOrchestrator();
    }
    return ThemeSwitchOrchestrator.instance;
  }

  /**
   * Start theme transition
   */
  startThemeTransition(
    fromThemeId: string,
    toThemeId: string,
    onComplete?: () => void
  ): void {
    if (this.transitionState.isTransitioning) {
      return; // Already transitioning
    }

    this.transitionState = {
      isTransitioning: true,
      fromThemeId,
      toThemeId,
      progress: 0,
    };

    // Simulate transition completion after duration
    setTimeout(() => {
      this.transitionState.isTransitioning = false;
      this.transitionState.progress = 1;
      onComplete?.();
    }, 600);
  }

  /**
   * Get current transition state
   */
  getTransitionState(): ThemeTransitionState {
    return this.transitionState;
  }

  /**
   * Check if currently transitioning
   */
  isTransitioning(): boolean {
    return this.transitionState.isTransitioning;
  }

  /**
   * Cancel current transition
   */
  cancelTransition(): void {
    this.transitionState.isTransitioning = false;
    this.transitionState.progress = 0;
  }

  /**
   * Reset orchestrator state
   */
  reset(): void {
    this.transitionState = {
      isTransitioning: false,
      fromThemeId: 'default',
      toThemeId: 'default',
      progress: 0,
    };
  }
}

export const themeSwitchOrchestrator = ThemeSwitchOrchestrator.getInstance();

/**
 * Hook for orchestrating theme transitions
 */
export function useThemeSwitchOrchestrator() {
  const orchestrator = ThemeSwitchOrchestrator.getInstance();

  const startTransition = (
    fromThemeId: string,
    toThemeId: string,
    onComplete?: () => void
  ) => {
    orchestrator.startThemeTransition(fromThemeId, toThemeId, onComplete);
  };

  const getState = () => orchestrator.getTransitionState();
  const isTransitioning = () => orchestrator.isTransitioning();
  const cancel = () => orchestrator.cancelTransition();
  const reset = () => orchestrator.reset();

  return {
    startTransition,
    getState,
    isTransitioning,
    cancel,
    reset,
  };
}

/**
 * Orchestrate color transition sequence
 */
export function orchestrateColorTransition(
  fromColor: string,
  toColor: string,
  duration: number = 600
): {
  progress: number;
  currentColor: string;
} {
  const progress = useSharedValue(0);

  progress.value = withTiming(1, { duration });

  // This would be calculated in animated component
  return {
    progress: progress.value as any,
    currentColor: toColor,
  };
}

/**
 * Orchestrate layout transition sequence
 */
export function orchestrateLayoutTransition(
  fromLayout: { x: number; y: number; scale: number },
  toLayout: { x: number; y: number; scale: number },
  duration: number = 600
): {
  progress: number;
  currentLayout: typeof toLayout;
} {
  const progress = useSharedValue(0);

  progress.value = withTiming(1, { duration });

  return {
    progress: progress.value as any,
    currentLayout: toLayout,
  };
}

/**
 * Orchestrate complete theme transition
 */
export function orchestrateCompleteThemeTransition(
  fromTheme: any,
  toTheme: any,
  duration: number = 600,
  onComplete?: () => void
): void {
  const orchestrator = ThemeSwitchOrchestrator.getInstance();
  orchestrator.startThemeTransition(fromTheme.id, toTheme.id, onComplete);
}
