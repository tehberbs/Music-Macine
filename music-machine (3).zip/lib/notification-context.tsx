import React, { createContext, useCallback, useState, useRef, useEffect } from 'react';

export type NotificationType = 'success' | 'error' | 'info' | 'warning' | 'download' | 'playback';

export interface Notification {
  id: string;
  type: NotificationType;
  title: string;
  message: string;
  duration?: number; // ms, 0 = indefinite
  action?: {
    label: string;
    onPress: () => void;
  };
}

interface NotificationContextType {
  notifications: Notification[];
  show: (notification: Omit<Notification, 'id'>) => string;
  hide: (id: string) => void;
  clear: () => void;
}

export const NotificationContext = createContext<NotificationContextType | null>(null);

export function NotificationProvider({ children }: { children: React.ReactNode }) {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const idCounterRef = useRef(0);
  const timeoutsRef = useRef<{ [key: string]: ReturnType<typeof setTimeout> }>({});

  const show = useCallback((notification: Omit<Notification, 'id'>) => {
    const id = `notification-${++idCounterRef.current}`;
    const duration = notification.duration ?? 4000;

    setNotifications((prev) => [...prev, { ...notification, id }]);

    if (duration > 0) {
      const timeout = setTimeout(() => {
        hide(id);
      }, duration);
      timeoutsRef.current[id] = timeout;
    }

    return id;
  }, []);

  const hide = useCallback((id: string) => {
    setNotifications((prev) => prev.filter((n) => n.id !== id));
    if (timeoutsRef.current[id]) {
      clearTimeout(timeoutsRef.current[id]);
      delete timeoutsRef.current[id];
    }
  }, []);

  const clear = useCallback(() => {
    Object.values(timeoutsRef.current).forEach((timeout) => clearTimeout(timeout));
    timeoutsRef.current = {};
    setNotifications([]);
  }, []);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      Object.values(timeoutsRef.current).forEach((timeout) => clearTimeout(timeout));
    };
  }, []);

  return (
    <NotificationContext.Provider value={{ notifications, show, hide, clear }}>
      {children}
    </NotificationContext.Provider>
  );
}

export function useNotification() {
  const context = React.useContext(NotificationContext);
  if (!context) {
    throw new Error('useNotification must be used within NotificationProvider');
  }
  return context;
}
