/**
 * Recently Played Service
 * Manages user's playback history with persistent storage
 */

import AsyncStorage from '@react-native-async-storage/async-storage';

export interface RecentlyPlayedTrack {
  id: string;
  title: string;
  artist: string;
  uri: string;
  playedAt: number;
  duration: number;
  playCount: number;
}

const RECENTLY_PLAYED_KEY = 'music_machine_recently_played';
const MAX_HISTORY = 100;

export class RecentlyPlayedService {
  /**
   * Add track to recently played
   */
  static async addToHistory(track: Omit<RecentlyPlayedTrack, 'playedAt' | 'playCount'>): Promise<void> {
    try {
      const history = await this.getRecentlyPlayed();

      // Find existing entry
      const existingIndex = history.findIndex((t) => t.id === track.id);

      if (existingIndex >= 0) {
        // Update existing entry
        history[existingIndex].playedAt = Date.now();
        history[existingIndex].playCount += 1;
        // Move to front
        const [existing] = history.splice(existingIndex, 1);
        history.unshift(existing);
      } else {
        // Add new entry
        history.unshift({
          ...track,
          playedAt: Date.now(),
          playCount: 1,
        });
      }

      // Limit to max history
      if (history.length > MAX_HISTORY) {
        history.pop();
      }

      await AsyncStorage.setItem(RECENTLY_PLAYED_KEY, JSON.stringify(history));
    } catch (error) {
      console.error('Failed to add to history:', error);
    }
  }

  /**
   * Get recently played tracks
   */
  static async getRecentlyPlayed(): Promise<RecentlyPlayedTrack[]> {
    try {
      const data = await AsyncStorage.getItem(RECENTLY_PLAYED_KEY);
      return data ? JSON.parse(data) : [];
    } catch (error) {
      console.error('Failed to get recently played:', error);
      return [];
    }
  }

  /**
   * Get top played tracks
   */
  static async getTopPlayed(limit: number = 10): Promise<RecentlyPlayedTrack[]> {
    try {
      const history = await this.getRecentlyPlayed();
      return history.sort((a, b) => b.playCount - a.playCount).slice(0, limit);
    } catch (error) {
      console.error('Failed to get top played:', error);
      return [];
    }
  }

  /**
   * Get play statistics
   */
  static async getStatistics(): Promise<{
    totalTracks: number;
    totalPlays: number;
    mostPlayedTrack: RecentlyPlayedTrack | null;
    averagePlaysPerTrack: number;
  }> {
    try {
      const history = await this.getRecentlyPlayed();
      const totalPlays = history.reduce((sum, track) => sum + track.playCount, 0);
      const mostPlayedTrack = history.length > 0 ? history[0] : null;

      return {
        totalTracks: history.length,
        totalPlays,
        mostPlayedTrack,
        averagePlaysPerTrack: history.length > 0 ? totalPlays / history.length : 0,
      };
    } catch (error) {
      console.error('Failed to get statistics:', error);
      return {
        totalTracks: 0,
        totalPlays: 0,
        mostPlayedTrack: null,
        averagePlaysPerTrack: 0,
      };
    }
  }

  /**
   * Clear history
   */
  static async clearHistory(): Promise<void> {
    try {
      await AsyncStorage.removeItem(RECENTLY_PLAYED_KEY);
    } catch (error) {
      console.error('Failed to clear history:', error);
    }
  }

  /**
   * Export history as JSON
   */
  static async exportHistory(): Promise<string> {
    try {
      const history = await this.getRecentlyPlayed();
      return JSON.stringify(history, null, 2);
    } catch (error) {
      console.error('Failed to export history:', error);
      return '[]';
    }
  }
}
