/**
 * EXAMPLE: How to integrate notifications into your app
 * 
 * This file shows example usage patterns for the notification system.
 * You can copy these patterns into your actual code.
 */

import { NotificationService } from './notification-service';

// ============================================
// PLAYBACK NOTIFICATIONS
// ============================================

export const playbackNotifications = {
  /**
   * Show when a track starts playing
   */
  trackStarted: (trackTitle: string, artistName: string) => {
    const service = NotificationService.getInstance();
    service.showPlayback(
      '🎵 Now Playing',
      `${trackTitle} by ${artistName}`
    );
  },

  /**
   * Show when playback is paused
   */
  trackPaused: (trackTitle: string) => {
    const service = NotificationService.getInstance();
    service.showInfo(
      '⏸️ Paused',
      trackTitle
    );
  },

  /**
   * Show when playback resumes
   */
  trackResumed: (trackTitle: string) => {
    const service = NotificationService.getInstance();
    service.showPlayback(
      '▶️ Resumed',
      trackTitle
    );
  },

  /**
   * Show when track ends
   */
  trackEnded: (trackTitle: string) => {
    const service = NotificationService.getInstance();
    service.showInfo(
      '✓ Track Finished',
      trackTitle,
      2000
    );
  },
};

// ============================================
// DOWNLOAD NOTIFICATIONS
// ============================================

export const downloadNotifications = {
  /**
   * Show when download starts
   */
  downloadStarted: (videoTitle: string) => {
    const service = NotificationService.getInstance();
    service.showDownload(
      '⬇️ Downloading',
      `Converting "${videoTitle}" to MP3...`
    );
  },

  /**
   * Show when download completes
   */
  downloadCompleted: (videoTitle: string) => {
    const service = NotificationService.getInstance();
    service.showSuccess(
      '✓ Download Complete',
      `"${videoTitle}" is ready to play`,
      4000
    );
  },

  /**
   * Show when download fails
   */
  downloadFailed: (videoTitle: string, error: string) => {
    const service = NotificationService.getInstance();
    service.showError(
      '✗ Download Failed',
      `Could not download "${videoTitle}": ${error}`,
      5000
    );
  },

  /**
   * Show download progress
   */
  downloadProgress: (videoTitle: string, progress: number) => {
    const service = NotificationService.getInstance();
    const percent = Math.round(progress * 100);
    service.showInfo(
      '⬇️ Downloading',
      `${percent}% - ${videoTitle}`,
      0 // Indefinite
    );
  },
};

// ============================================
// ERROR NOTIFICATIONS
// ============================================

export const errorNotifications = {
  /**
   * Show when audio fails to load
   */
  audioLoadFailed: (trackTitle: string) => {
    const service = NotificationService.getInstance();
    service.showError(
      '✗ Load Failed',
      `Could not load "${trackTitle}"`
    );
  },

  /**
   * Show when network error occurs
   */
  networkError: () => {
    const service = NotificationService.getInstance();
    service.showError(
      '✗ Network Error',
      'Check your internet connection'
    );
  },

  /**
   * Show when YouTube search fails
   */
  searchFailed: (error: string) => {
    const service = NotificationService.getInstance();
    service.showError(
      '✗ Search Failed',
      error || 'Could not search YouTube'
    );
  },

  /**
   * Show when API key is missing
   */
  apiKeyMissing: () => {
    const service = NotificationService.getInstance();
    service.showError(
      '✗ Configuration Error',
      'YouTube API key not configured'
    );
  },
};

// ============================================
// FEATURE NOTIFICATIONS
// ============================================

export const featureNotifications = {
  /**
   * Show when equalizer is applied
   */
  eqApplied: (presetName: string) => {
    const service = NotificationService.getInstance();
    service.showInfo(
      '🎚️ EQ Applied',
      `Preset: ${presetName}`,
      2000
    );
  },

  /**
   * Show when stem silencer is activated
   */
  stemSilencerActivated: (stemName: string) => {
    const service = NotificationService.getInstance();
    service.showInfo(
      '🎸 Stem Silencer',
      `${stemName} silenced`,
      2000
    );
  },

  /**
   * Show when visualizer changes
   */
  visualizerChanged: (vizName: string) => {
    const service = NotificationService.getInstance();
    service.showInfo(
      '✨ Visualizer',
      vizName,
      1500
    );
  },

  /**
   * Show when playlist is created
   */
  playlistCreated: (playlistName: string) => {
    const service = NotificationService.getInstance();
    service.showSuccess(
      '✓ Playlist Created',
      `"${playlistName}" added to library`
    );
  },

  /**
   * Show when track is added to favorites
   */
  addedToFavorites: (trackTitle: string) => {
    const service = NotificationService.getInstance();
    service.showSuccess(
      '❤️ Added to Favorites',
      trackTitle,
      2000
    );
  },

  /**
   * Show when sleep timer is set
   */
  sleepTimerSet: (minutes: number) => {
    const service = NotificationService.getInstance();
    service.showInfo(
      '⏱️ Sleep Timer',
      `Music will stop in ${minutes} minutes`,
      3000
    );
  },
};

// ============================================
// USAGE IN COMPONENTS
// ============================================

/**
 * Example: Using notifications in a component
 * 
 * import { playbackNotifications } from '@/lib/notification-integration-example';
 * 
 * export function MyComponent() {
 *   const handlePlayTrack = (track) => {
 *     // ... play the track ...
 *     playbackNotifications.trackStarted(track.title, track.artist);
 *   };
 * 
 *   return (
 *     <Pressable onPress={() => handlePlayTrack(track)}>
 *       <Text>Play</Text>
 *     </Pressable>
 *   );
 * }
 */

/**
 * Example: Using notifications in a service
 * 
 * import { downloadNotifications } from '@/lib/notification-integration-example';
 * 
 * export async function downloadYouTubeVideo(videoId: string) {
 *   try {
 *     downloadNotifications.downloadStarted(videoTitle);
 *     
 *     const result = await convertYouTubeToMp3(videoId);
 *     
 *     downloadNotifications.downloadCompleted(videoTitle);
 *   } catch (error) {
 *     downloadNotifications.downloadFailed(videoTitle, error.message);
 *   }
 * }
 */
