/**
 * Global Search Service
 * Handles search across YouTube and other sources
 */

import { getYouTubeService, type YouTubeVideo } from './youtube-service';

export interface SearchResult {
  id: string;
  title: string;
  description: string;
  thumbnail: string;
  source: 'youtube' | 'local';
  duration?: string | number;
  durationSeconds?: number;
  channel?: string;
}

export class GlobalSearchService {
  /**
   * Search YouTube for videos
   */
  static async searchYouTube(query: string, maxResults: number = 20): Promise<SearchResult[]> {
    try {
      const youtubeService = getYouTubeService();
      const result = await youtubeService.searchVideos(query, maxResults);

      return result.videos.map((video) => ({
        id: video.id,
        title: video.title,
        description: video.description,
        thumbnail: video.thumbnail,
        source: 'youtube' as const,
        duration: video.duration,
        channel: video.channel,
      }));
    } catch (error) {
      console.error('YouTube search failed:', error);
      return [];
    }
  }

  /**
   * Global search across all sources
   */
  static async globalSearch(query: string, sources: ('youtube' | 'local')[] = ['youtube']): Promise<SearchResult[]> {
    const results: SearchResult[] = [];

    if (sources.includes('youtube')) {
      const youtubeResults = await this.searchYouTube(query, 20);
      results.push(...youtubeResults);
    }

    return results;
  }

  /**
   * Format search query for API
   */
  static formatQuery(query: string): string {
    return query.trim().replace(/\s+/g, ' ');
  }

  /**
   * Validate search query
   */
  static isValidQuery(query: string): boolean {
    const trimmed = query.trim();
    return trimmed.length > 0 && trimmed.length <= 200;
  }
}
