/**
 * Favorites Service
 * Manages user's favorite tracks with persistent storage
 */

import AsyncStorage from '@react-native-async-storage/async-storage';

export interface FavoriteTrack {
  id: string;
  title: string;
  artist: string;
  uri: string;
  addedAt: number;
}

const FAVORITES_KEY = 'music_machine_favorites';
const MAX_FAVORITES = 500;

export class FavoritesService {
  /**
   * Add track to favorites
   */
  static async addFavorite(track: FavoriteTrack): Promise<void> {
    try {
      const favorites = await this.getFavorites();

      // Check if already favorited
      if (favorites.some((fav) => fav.id === track.id)) {
        return;
      }

      // Add new favorite
      favorites.unshift({
        ...track,
        addedAt: Date.now(),
      });

      // Limit to max favorites
      if (favorites.length > MAX_FAVORITES) {
        favorites.pop();
      }

      await AsyncStorage.setItem(FAVORITES_KEY, JSON.stringify(favorites));
    } catch (error) {
      console.error('Failed to add favorite:', error);
    }
  }

  /**
   * Remove track from favorites
   */
  static async removeFavorite(trackId: string): Promise<void> {
    try {
      const favorites = await this.getFavorites();
      const filtered = favorites.filter((fav) => fav.id !== trackId);
      await AsyncStorage.setItem(FAVORITES_KEY, JSON.stringify(filtered));
    } catch (error) {
      console.error('Failed to remove favorite:', error);
    }
  }

  /**
   * Get all favorites
   */
  static async getFavorites(): Promise<FavoriteTrack[]> {
    try {
      const data = await AsyncStorage.getItem(FAVORITES_KEY);
      return data ? JSON.parse(data) : [];
    } catch (error) {
      console.error('Failed to get favorites:', error);
      return [];
    }
  }

  /**
   * Check if track is favorited
   */
  static async isFavorite(trackId: string): Promise<boolean> {
    try {
      const favorites = await this.getFavorites();
      return favorites.some((fav) => fav.id === trackId);
    } catch (error) {
      console.error('Failed to check favorite:', error);
      return false;
    }
  }

  /**
   * Get favorite count
   */
  static async getFavoriteCount(): Promise<number> {
    try {
      const favorites = await this.getFavorites();
      return favorites.length;
    } catch (error) {
      console.error('Failed to get favorite count:', error);
      return 0;
    }
  }

  /**
   * Clear all favorites
   */
  static async clearFavorites(): Promise<void> {
    try {
      await AsyncStorage.removeItem(FAVORITES_KEY);
    } catch (error) {
      console.error('Failed to clear favorites:', error);
    }
  }

  /**
   * Export favorites as JSON
   */
  static async exportFavorites(): Promise<string> {
    try {
      const favorites = await this.getFavorites();
      return JSON.stringify(favorites, null, 2);
    } catch (error) {
      console.error('Failed to export favorites:', error);
      return '[]';
    }
  }
}
