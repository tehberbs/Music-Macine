import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useSharedValue, withTiming } from 'react-native-reanimated';
import { useThemeSwitchOrchestrator } from './theme-switch-orchestrator';

// Theme types
export type ThemeType = 'default' | 'metal' | 'wood' | 'nature' | 'custom';

export interface ThemeColor {
  primary: string;
  secondary: string;
  background: string;
  surface: string;
  text: string;
  accent: string;
  border: string;
}

export interface ThemeSpacing {
  xs: number;
  sm: number;
  md: number;
  lg: number;
  xl: number;
}

export interface ThemeElement {
  id: string;
  name: string;
  imageUrl?: string;
  backgroundColor?: string;
  borderColor?: string;
  borderWidth?: number;
  borderRadius?: number;
  opacity?: number;
  position?: { x: number; y: number };
  size?: { width: number; height: number };
}

export interface NavigationLink {
  id: string;
  label: string;
  icon?: string;
  position: { x: number; y: number };
  visible: boolean;
  order: number;
}

export interface AppFeature {
  id: string;
  name: string;
  position: { x: number; y: number };
  visible: boolean;
  customizable: boolean;
}

export interface CustomTheme {
  id: string;
  name: string;
  type: ThemeType;
  colors: ThemeColor;
  spacing: ThemeSpacing;
  elements: ThemeElement[];
  navigationLinks: NavigationLink[];
  appFeatures: AppFeature[];
  backgroundImage?: string;
  createdAt: number;
  updatedAt: number;
}

// Default themes
const DEFAULT_COLORS: Record<ThemeType, ThemeColor> = {
  default: {
    primary: '#A78BFA',
    secondary: '#06B6D4',
    background: '#0F172A',
    surface: '#1E293B',
    text: '#F1F5F9',
    accent: '#06B6D4',
    border: '#334155',
  },
  metal: {
    primary: '#60A5FA',
    secondary: '#93C5FD',
    background: '#1F2937',
    surface: '#374151',
    text: '#F3F4F6',
    accent: '#60A5FA',
    border: '#4B5563',
  },
  wood: {
    primary: '#D97706',
    secondary: '#F59E0B',
    background: '#78350F',
    surface: '#92400E',
    text: '#FEF3C7',
    accent: '#D97706',
    border: '#B45309',
  },
  nature: {
    primary: '#10B981',
    secondary: '#34D399',
    background: '#064E3B',
    surface: '#047857',
    text: '#D1FAE5',
    accent: '#10B981',
    border: '#059669',
  },
  custom: {
    primary: '#A78BFA',
    secondary: '#06B6D4',
    background: '#0F172A',
    surface: '#1E293B',
    text: '#F1F5F9',
    accent: '#06B6D4',
    border: '#334155',
  },
};

const DEFAULT_SPACING: ThemeSpacing = {
  xs: 4,
  sm: 8,
  md: 16,
  lg: 24,
  xl: 32,
};

// Create context
interface AdvancedThemeContextType {
  currentTheme: CustomTheme;
  availableThemes: CustomTheme[];
  selectTheme: (themeId: string) => Promise<void>;
  updateTheme: (theme: CustomTheme) => Promise<void>;
  createCustomTheme: (name: string) => Promise<CustomTheme>;
  deleteTheme: (themeId: string) => Promise<void>;
  updateThemeColors: (colors: ThemeColor) => Promise<void>;
  updateThemeSpacing: (spacing: ThemeSpacing) => Promise<void>;
  updateThemeElement: (element: ThemeElement) => Promise<void>;
  updateNavigationLink: (link: NavigationLink) => Promise<void>;
  updateAppFeature: (feature: AppFeature) => Promise<void>;
  setBackgroundImage: (imageUrl: string) => Promise<void>;
  resetToDefault: () => Promise<void>;
  exportTheme: () => Promise<string>;
  importTheme: (themeJson: string) => Promise<void>;
  isTransitioning: boolean;
  transitionProgress: number;
}

const AdvancedThemeContext = createContext<AdvancedThemeContextType | undefined>(undefined);

// Provider component
export function AdvancedThemeProvider({ children }: { children: ReactNode }) {
  const [currentTheme, setCurrentTheme] = useState<CustomTheme | null>(null);
  const [availableThemes, setAvailableThemes] = useState<CustomTheme[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Initialize themes on mount
  useEffect(() => {
    initializeThemes();
  }, []);

  const initializeThemes = async () => {
    try {
      const savedThemes = await AsyncStorage.getItem('customThemes');
      const currentThemeId = await AsyncStorage.getItem('currentThemeId');

      let themes: CustomTheme[] = [];

      if (savedThemes) {
        themes = JSON.parse(savedThemes);
      } else {
        // Create default themes
        themes = [
          createDefaultTheme('default', 'Default'),
          createDefaultTheme('metal', 'Metal'),
          createDefaultTheme('wood', 'Wood'),
          createDefaultTheme('nature', 'Nature'),
        ];
        await AsyncStorage.setItem('customThemes', JSON.stringify(themes));
      }

      setAvailableThemes(themes);

      // Load current theme
      let current = themes.find((t) => t.id === currentThemeId) || themes[0];
      setCurrentTheme(current);
      await AsyncStorage.setItem('currentThemeId', current.id);
    } catch (error) {
      console.error('Failed to initialize themes:', error);
      // Fallback to default theme
      const defaultTheme = createDefaultTheme('default', 'Default');
      setCurrentTheme(defaultTheme);
      setAvailableThemes([defaultTheme]);
    } finally {
      setIsLoading(false);
    }
  };

  const createDefaultTheme = (type: ThemeType, name: string): CustomTheme => ({
    id: `${type}-${Date.now()}`,
    name,
    type,
    colors: DEFAULT_COLORS[type],
    spacing: DEFAULT_SPACING,
    elements: [],
    navigationLinks: createDefaultNavigationLinks(),
    appFeatures: createDefaultAppFeatures(),
    backgroundImage: getDefaultBackgroundImage(type),
    createdAt: Date.now(),
    updatedAt: Date.now(),
  });

  const createDefaultNavigationLinks = (): NavigationLink[] => [
    { id: 'home', label: 'Home', icon: 'home', position: { x: 0.1, y: 0.9 }, visible: true, order: 1 },
    { id: 'library', label: 'Library', icon: 'library', position: { x: 0.3, y: 0.9 }, visible: true, order: 2 },
    { id: 'youtube', label: 'YouTube', icon: 'youtube', position: { x: 0.5, y: 0.9 }, visible: true, order: 3 },
    { id: 'search', label: 'Search', icon: 'search', position: { x: 0.7, y: 0.9 }, visible: true, order: 4 },
    { id: 'settings', label: 'Settings', icon: 'settings', position: { x: 0.9, y: 0.9 }, visible: true, order: 5 },
  ];

  const createDefaultAppFeatures = (): AppFeature[] => [
    { id: 'player', name: 'Player', position: { x: 0.5, y: 0.2 }, visible: true, customizable: true },
    { id: 'controls', name: 'Controls', position: { x: 0.5, y: 0.5 }, visible: true, customizable: true },
    { id: 'equalizer', name: 'Equalizer', position: { x: 0.5, y: 0.7 }, visible: true, customizable: true },
    { id: 'visualizer', name: 'Visualizer', position: { x: 0.5, y: 0.3 }, visible: true, customizable: true },
  ];

  const getDefaultBackgroundImage = (type: ThemeType): string => {
    const baseUrl = 'https://d2xsxph8kpxj0f.cloudfront.net/310519663401178821/Z5A7mQeRYv3Hy2mxQTCoJx';
    switch (type) {
      case 'metal':
        return `${baseUrl}/metal-theme-bg-6PawAm4LgguEuKYdft9QS9.webp`;
      case 'wood':
        return `${baseUrl}/wood-theme-bg-PKEKCCTqG5MH8oVD4JWZcE.webp`;
      case 'nature':
        return `${baseUrl}/nature-theme-bg-aaYVAhRw6LHuoSNHNiBRoz.webp`;
      default:
        return '';
    }
  };

  const selectTheme = async (themeId: string) => {
    const theme = availableThemes.find((t) => t.id === themeId);
    if (theme) {
      setCurrentTheme(theme);
      await AsyncStorage.setItem('currentThemeId', themeId);
    }
  };

  const updateTheme = async (theme: CustomTheme) => {
    const updated = { ...theme, updatedAt: Date.now() };
    const newThemes = availableThemes.map((t) => (t.id === theme.id ? updated : t));
    setAvailableThemes(newThemes);
    setCurrentTheme(updated);
    await AsyncStorage.setItem('customThemes', JSON.stringify(newThemes));
  };

  const createCustomTheme = async (name: string): Promise<CustomTheme> => {
    const newTheme = createDefaultTheme('custom', name);
    const newThemes = [...availableThemes, newTheme];
    setAvailableThemes(newThemes);
    await AsyncStorage.setItem('customThemes', JSON.stringify(newThemes));
    return newTheme;
  };

  const deleteTheme = async (themeId: string) => {
    const newThemes = availableThemes.filter((t) => t.id !== themeId);
    setAvailableThemes(newThemes);
    if (currentTheme?.id === themeId && newThemes.length > 0) {
      setCurrentTheme(newThemes[0]);
      await AsyncStorage.setItem('currentThemeId', newThemes[0].id);
    }
    await AsyncStorage.setItem('customThemes', JSON.stringify(newThemes));
  };

  const updateThemeColors = async (colors: ThemeColor) => {
    if (currentTheme) {
      await updateTheme({ ...currentTheme, colors });
    }
  };

  const updateThemeSpacing = async (spacing: ThemeSpacing) => {
    if (currentTheme) {
      await updateTheme({ ...currentTheme, spacing });
    }
  };

  const updateThemeElement = async (element: ThemeElement) => {
    if (currentTheme) {
      const elements = currentTheme.elements.map((e) => (e.id === element.id ? element : e));
      if (!elements.find((e) => e.id === element.id)) {
        elements.push(element);
      }
      await updateTheme({ ...currentTheme, elements });
    }
  };

  const updateNavigationLink = async (link: NavigationLink) => {
    if (currentTheme) {
      const links = currentTheme.navigationLinks.map((l) => (l.id === link.id ? link : l));
      await updateTheme({ ...currentTheme, navigationLinks: links });
    }
  };

  const updateAppFeature = async (feature: AppFeature) => {
    if (currentTheme) {
      const features = currentTheme.appFeatures.map((f) => (f.id === feature.id ? feature : f));
      await updateTheme({ ...currentTheme, appFeatures: features });
    }
  };

  const setBackgroundImage = async (imageUrl: string) => {
    if (currentTheme) {
      await updateTheme({ ...currentTheme, backgroundImage: imageUrl });
    }
  };

  const resetToDefault = async () => {
    const defaultTheme = availableThemes.find((t) => t.type === 'default');
    if (defaultTheme) {
      await selectTheme(defaultTheme.id);
    }
  };

  const exportTheme = async (): Promise<string> => {
    if (currentTheme) {
      return JSON.stringify(currentTheme, null, 2);
    }
    return '';
  };

  const importTheme = async (themeJson: string) => {
    try {
      const theme = JSON.parse(themeJson) as CustomTheme;
      theme.id = `imported-${Date.now()}`;
      theme.createdAt = Date.now();
      theme.updatedAt = Date.now();
      await createCustomTheme(theme.name);
    } catch (error) {
      console.error('Failed to import theme:', error);
    }
  };

  if (isLoading || !currentTheme) {
    return null;
  }

  return (
    <AdvancedThemeContext.Provider
      value={{
        currentTheme,
        availableThemes,
        selectTheme,
        updateTheme,
        createCustomTheme,
        deleteTheme,
        updateThemeColors,
        updateThemeSpacing,
        updateThemeElement,
        updateNavigationLink,
        updateAppFeature,
        setBackgroundImage,
        resetToDefault,
        exportTheme,
        importTheme,
        isTransitioning: false,
        transitionProgress: 0,
      }}
    >
      {children}
    </AdvancedThemeContext.Provider>
  );
}

// Hook to use theme context
export function useAdvancedTheme() {
  const context = useContext(AdvancedThemeContext);
  if (!context) {
    throw new Error('useAdvancedTheme must be used within AdvancedThemeProvider');
  }
  return context;
}
