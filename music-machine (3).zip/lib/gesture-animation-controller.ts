import Animated, {
  Easing,
  withTiming,
  withSequence,
  runOnJS,
} from 'react-native-reanimated';
import type { SharedValue } from 'react-native-reanimated';

export type GestureType = 'swipe-left' | 'swipe-right' | 'swipe-up' | 'swipe-down';

/**
 * Controls gear animations in response to swipe gestures
 * Provides synchronized animation effects for immersive interaction
 */
export class GestureAnimationController {
  private gearRotationMultiplier = new Map<string, number>();
  private lastGestureTime = 0;
  private gestureDebounceMs = 300;

  /**
   * Trigger a gear spin animation in response to a gesture
   * @param intensity - How much to spin (1 = normal, 2 = double, etc)
   * @param direction - 1 for clockwise, -1 for counter-clockwise
   */
  triggerGearSpin(
    rotation: SharedValue<number>,
    intensity: number = 1,
    direction: 1 | -1 = 1
  ) {
    const now = Date.now();
    if (now - this.lastGestureTime < this.gestureDebounceMs) {
      return; // Debounce rapid gestures
    }
    this.lastGestureTime = now;

    // Spin gears based on gesture intensity
    const spinAmount = 45 * intensity * direction; // degrees
    rotation.value = withTiming(rotation.value + spinAmount, {
      duration: 300,
      easing: Easing.out(Easing.cubic),
    });
  }

  /**
   * Create a pulse animation effect for visual feedback
   */
  createPulseAnimation(scale: SharedValue<number>) {
    scale.value = withSequence(
      withTiming(1.1, { duration: 100, easing: Easing.out(Easing.cubic) }),
      withTiming(1, { duration: 100, easing: Easing.in(Easing.cubic) })
    );
  }

  /**
   * Create a directional animation for left/right swipes
   */
  createDirectionalAnimation(
    translateX: SharedValue<number>,
    direction: 'left' | 'right'
  ) {
    const distance = direction === 'left' ? -20 : 20;
    translateX.value = withSequence(
      withTiming(distance, { duration: 150, easing: Easing.out(Easing.cubic) }),
      withTiming(0, { duration: 150, easing: Easing.in(Easing.cubic) })
    );
  }

  /**
   * Create a vertical animation for up/down swipes
   */
  createVerticalAnimation(
    translateY: SharedValue<number>,
    direction: 'up' | 'down'
  ) {
    const distance = direction === 'up' ? -15 : 15;
    translateY.value = withSequence(
      withTiming(distance, { duration: 150, easing: Easing.out(Easing.cubic) }),
      withTiming(0, { duration: 150, easing: Easing.in(Easing.cubic) })
    );
  }

  /**
   * Create a rotation animation for visual feedback
   */
  createRotationAnimation(rotation: SharedValue<number>, direction: 1 | -1 = 1) {
    rotation.value = withSequence(
      withTiming(15 * direction, { duration: 100, easing: Easing.out(Easing.cubic) }),
      withTiming(0, { duration: 100, easing: Easing.in(Easing.cubic) })
    );
  }

  /**
   * Create a combined animation for track skip
   */
  createSkipAnimation(
    scale: SharedValue<number>,
    rotation: SharedValue<number>,
    direction: 'left' | 'right'
  ) {
    const rotationAmount = direction === 'left' ? -45 : 45;

    scale.value = withSequence(
      withTiming(1.15, { duration: 150, easing: Easing.out(Easing.cubic) }),
      withTiming(1, { duration: 150, easing: Easing.in(Easing.cubic) })
    );

    rotation.value = withTiming(rotationAmount, {
      duration: 300,
      easing: Easing.out(Easing.cubic),
    });
  }

  /**
   * Create a combined animation for volume change
   */
  createVolumeAnimation(
    scale: SharedValue<number>,
    translateY: SharedValue<number>,
    direction: 'up' | 'down'
  ) {
    const distance = direction === 'up' ? -25 : 25;

    scale.value = withSequence(
      withTiming(1.12, { duration: 150, easing: Easing.out(Easing.cubic) }),
      withTiming(1, { duration: 150, easing: Easing.in(Easing.cubic) })
    );

    translateY.value = withSequence(
      withTiming(distance, { duration: 200, easing: Easing.out(Easing.cubic) }),
      withTiming(0, { duration: 200, easing: Easing.in(Easing.cubic) })
    );
  }

  /**
   * Reset all animations
   */
  resetAnimations(
    scale: SharedValue<number>,
    rotation: SharedValue<number>,
    translateX: SharedValue<number>,
    translateY: SharedValue<number>
  ) {
    scale.value = 1;
    rotation.value = 0;
    translateX.value = 0;
    translateY.value = 0;
  }
}

// Singleton instance
let instance: GestureAnimationController | null = null;

export function getGestureAnimationController(): GestureAnimationController {
  if (!instance) {
    instance = new GestureAnimationController();
  }
  return instance;
}
