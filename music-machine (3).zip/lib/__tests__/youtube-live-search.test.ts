import { describe, it, expect, beforeAll } from 'vitest';
import { YouTubeService } from '../youtube-service';

describe('YouTube Live Search - Real Results Verification', () => {
  let youtubeService: YouTubeService;
  const apiKey = process.env.YOUTUBE_API_KEY;

  beforeAll(() => {
    youtubeService = new YouTubeService(apiKey);
  });

  it('should return live YouTube search results for "music"', async () => {
    const result = await youtubeService.searchVideos('music', 5);
    
    console.log('\n=== YouTube Search Results for "music" ===');
    console.log(`Total Results: ${result.totalResults}`);
    console.log(`Videos Found: ${result.videos.length}`);
    
    expect(result.videos.length).toBeGreaterThan(0);
    
    result.videos.forEach((video, index) => {
      console.log(`\n[${index + 1}] ${video.title}`);
      console.log(`    Channel: ${video.channel}`);
      console.log(`    Video ID: ${video.id}`);
      console.log(`    Thumbnail: ${video.thumbnail}`);
      console.log(`    Published: ${video.publishedAt}`);
      
      expect(video.id).toBeDefined();
      expect(video.title).toBeDefined();
      expect(video.title.length).toBeGreaterThan(0);
      expect(video.thumbnail).toBeDefined();
      expect(video.channel).toBeDefined();
    });
  });

  it('should return live YouTube search results for "taylor swift"', async () => {
    const result = await youtubeService.searchVideos('taylor swift', 5);
    
    console.log('\n=== YouTube Search Results for "taylor swift" ===');
    console.log(`Total Results: ${result.totalResults}`);
    console.log(`Videos Found: ${result.videos.length}`);
    
    expect(result.videos.length).toBeGreaterThan(0);
    
    result.videos.forEach((video, index) => {
      console.log(`\n[${index + 1}] ${video.title}`);
      console.log(`    Channel: ${video.channel}`);
      console.log(`    Video ID: ${video.id}`);
      
      expect(video.title.toLowerCase()).toContain('taylor');
      expect(video.id).toBeDefined();
    });
  });

  it('should return live YouTube search results for "lo-fi beats"', async () => {
    const result = await youtubeService.searchVideos('lo-fi beats', 5);
    
    console.log('\n=== YouTube Search Results for "lo-fi beats" ===');
    console.log(`Total Results: ${result.totalResults}`);
    console.log(`Videos Found: ${result.videos.length}`);
    
    expect(result.videos.length).toBeGreaterThan(0);
    
    result.videos.forEach((video, index) => {
      console.log(`\n[${index + 1}] ${video.title}`);
      console.log(`    Channel: ${video.channel}`);
      console.log(`    Video ID: ${video.id}`);
      console.log(`    Description: ${video.description.substring(0, 100)}...`);
      
      expect(video.id).toBeDefined();
      expect(video.title).toBeDefined();
    });
  });

  it('should verify video details are complete and accurate', async () => {
    const searchResult = await youtubeService.searchVideos('music', 1);
    
    if (searchResult.videos.length > 0) {
      const videoId = searchResult.videos[0].id;
      const details = await youtubeService.getVideoDetails(videoId);
      
      console.log('\n=== Video Details Verification ===');
      console.log(`Video ID: ${videoId}`);
      
      if (details) {
        console.log(`Title: ${details.title}`);
        console.log(`Channel: ${details.channel}`);
        console.log(`Duration: ${details.duration}`);
        console.log(`Duration (seconds): ${details.durationSeconds}`);
        console.log(`View Count: ${details.viewCount}`);
        console.log(`Published: ${details.publishedAt}`);
        console.log(`Thumbnail: ${details.thumbnail}`);
        
        expect(details.id).toBe(videoId);
        expect(details.title).toBeDefined();
        expect(details.title.length).toBeGreaterThan(0);
        expect(details.channel).toBeDefined();
        expect(details.durationSeconds).toBeGreaterThanOrEqual(0);
        expect(details.thumbnail).toBeDefined();
      }
    }
  });

  it('should handle pagination with nextPageToken', async () => {
    const firstResult = await youtubeService.searchVideos('music', 5);
    
    console.log('\n=== Pagination Test ===');
    console.log(`First page results: ${firstResult.videos.length}`);
    console.log(`Has nextPageToken: ${!!firstResult.nextPageToken}`);
    
    expect(firstResult.videos.length).toBeGreaterThan(0);
    
    if (firstResult.nextPageToken) {
      const secondResult = await youtubeService.searchVideos('music', 5, firstResult.nextPageToken);
      
      console.log(`Second page results: ${secondResult.videos.length}`);
      
      expect(secondResult.videos.length).toBeGreaterThan(0);
      
      // Verify results are different
      const firstIds = firstResult.videos.map(v => v.id);
      const secondIds = secondResult.videos.map(v => v.id);
      const hasDifferentResults = secondIds.some(id => !firstIds.includes(id));
      
      console.log(`Different results between pages: ${hasDifferentResults}`);
      expect(hasDifferentResults).toBe(true);
    }
  });

  it('should verify API key is valid and working', async () => {
    console.log('\n=== API Key Validation ===');
    console.log(`API Key configured: ${!!apiKey}`);
    console.log(`API Key length: ${apiKey?.length || 0}`);
    
    expect(apiKey).toBeDefined();
    expect(apiKey?.length).toBeGreaterThan(0);
    
    // Try a simple search to verify API key works
    const result = await youtubeService.searchVideos('test', 1);
    console.log(`API Key working: ${result.videos.length > 0 || result.totalResults > 0}`);
    
    expect(result.videos.length > 0 || result.totalResults > 0).toBe(true);
  });
});
