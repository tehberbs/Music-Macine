import { describe, it, expect, beforeAll } from 'vitest';
import { YouTubeService } from '../youtube-service';

describe('YouTube API Integration', () => {
  let youtubeService: YouTubeService;
  const apiKey = process.env.YOUTUBE_API_KEY;

  beforeAll(() => {
    youtubeService = new YouTubeService(apiKey);
  });

  it('should have YouTube API key configured', () => {
    expect(apiKey).toBeDefined();
    expect(apiKey).toHaveLength(39); // YouTube API keys are typically 39 characters
  });

  it('should search YouTube videos with real API', async () => {
    if (!apiKey) {
      console.warn('YouTube API key not configured, skipping real API test');
      return;
    }

    const result = await youtubeService.searchVideos('music', 5);
    
    expect(result).toBeDefined();
    expect(result.videos).toBeDefined();
    expect(Array.isArray(result.videos)).toBe(true);
    
    if (result.videos.length > 0) {
      const video = result.videos[0];
      expect(video.id).toBeDefined();
      expect(video.title).toBeDefined();
      expect(video.thumbnail).toBeDefined();
      expect(video.channel).toBeDefined();
    }
  });

  it('should fetch video details with real API', async () => {
    if (!apiKey) {
      console.warn('YouTube API key not configured, skipping real API test');
      return;
    }

    // Search for a video first
    const searchResult = await youtubeService.searchVideos('music', 1);
    
    if (searchResult.videos.length > 0) {
      const videoId = searchResult.videos[0].id;
      const details = await youtubeService.getVideoDetails(videoId);
      
      expect(details).toBeDefined();
      if (details) {
        expect(details.id).toBe(videoId);
        expect(details.title).toBeDefined();
        expect(details.durationSeconds).toBeGreaterThanOrEqual(0);
      }
    }
  });

  it('should handle API errors gracefully', async () => {
    const invalidService = new YouTubeService('invalid-api-key');
    const result = await invalidService.searchVideos('music', 5);
    
    // Should return mock results or empty array on error
    expect(result).toBeDefined();
    expect(Array.isArray(result.videos)).toBe(true);
  });
});
