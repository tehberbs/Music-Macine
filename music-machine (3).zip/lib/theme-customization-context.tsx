import React, { createContext, useContext, useState, useEffect } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

export interface NavigationLink {
  id: string;
  label: string;
  icon: string;
  position: { x: number; y: number };
  size: number;
  color: string;
  action: string;
}

export interface UIElement {
  id: string;
  name: string;
  imageUri?: string;
  opacity: number;
  scale: number;
  position: { x: number; y: number };
  rotation: number;
}

export interface ThemeCustomization {
  // Colors
  primaryColor: string;
  secondaryColor: string;
  accentColor: string;
  backgroundColor: string;
  textColor: string;
  borderColor: string;

  // Layout
  spacing: number;
  borderRadius: number;
  borderWidth: number;

  // Elements
  elements: UIElement[];
  navigationLinks: NavigationLink[];

  // Background
  backgroundImageUri?: string;
  backgroundOpacity: number;

  // Fonts
  fontSize: number;
  fontWeight: 'normal' | 'bold' | '600' | '700';

  // Animations
  enableAnimations: boolean;
  animationSpeed: number;
}

const defaultTheme: ThemeCustomization = {
  primaryColor: '#FFD700',
  secondaryColor: '#D4AF37',
  accentColor: '#8B7355',
  backgroundColor: '#0d0d0d',
  textColor: '#FFD700',
  borderColor: '#D4AF37',
  spacing: 16,
  borderRadius: 8,
  borderWidth: 2,
  elements: [],
  navigationLinks: [],
  backgroundOpacity: 1,
  fontSize: 14,
  fontWeight: '600',
  enableAnimations: true,
  animationSpeed: 1,
};

interface ThemeContextType {
  theme: ThemeCustomization;
  updateTheme: (updates: Partial<ThemeCustomization>) => void;
  resetTheme: () => void;
  saveTheme: () => Promise<void>;
  loadTheme: () => Promise<void>;
  addElement: (element: UIElement) => void;
  updateElement: (id: string, updates: Partial<UIElement>) => void;
  removeElement: (id: string) => void;
  addNavigationLink: (link: NavigationLink) => void;
  updateNavigationLink: (id: string, updates: Partial<NavigationLink>) => void;
  removeNavigationLink: (id: string) => void;
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

export function ThemeProvider({ children }: { children: React.ReactNode }) {
  const [theme, setTheme] = useState<ThemeCustomization>(defaultTheme);
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    loadTheme();
  }, []);

  const updateTheme = (updates: Partial<ThemeCustomization>) => {
    setTheme((prev) => ({ ...prev, ...updates }));
  };

  const resetTheme = () => {
    setTheme(defaultTheme);
  };

  const saveTheme = async () => {
    try {
      await AsyncStorage.setItem('musicMachineTheme', JSON.stringify(theme));
    } catch (error) {
      console.error('[ThemeCustomization] Failed to save theme:', error);
    }
  };

  const loadTheme = async () => {
    try {
      const saved = await AsyncStorage.getItem('musicMachineTheme');
      if (saved) {
        setTheme(JSON.parse(saved));
      }
    } catch (error) {
      console.error('[ThemeCustomization] Failed to load theme:', error);
    } finally {
      setIsLoaded(true);
    }
  };

  const addElement = (element: UIElement) => {
    setTheme((prev) => ({
      ...prev,
      elements: [...prev.elements, element],
    }));
  };

  const updateElement = (id: string, updates: Partial<UIElement>) => {
    setTheme((prev) => ({
      ...prev,
      elements: prev.elements.map((el) =>
        el.id === id ? { ...el, ...updates } : el
      ),
    }));
  };

  const removeElement = (id: string) => {
    setTheme((prev) => ({
      ...prev,
      elements: prev.elements.filter((el) => el.id !== id),
    }));
  };

  const addNavigationLink = (link: NavigationLink) => {
    setTheme((prev) => ({
      ...prev,
      navigationLinks: [...prev.navigationLinks, link],
    }));
  };

  const updateNavigationLink = (id: string, updates: Partial<NavigationLink>) => {
    setTheme((prev) => ({
      ...prev,
      navigationLinks: prev.navigationLinks.map((link) =>
        link.id === id ? { ...link, ...updates } : link
      ),
    }));
  };

  const removeNavigationLink = (id: string) => {
    setTheme((prev) => ({
      ...prev,
      navigationLinks: prev.navigationLinks.filter((link) => link.id !== id),
    }));
  };

  if (!isLoaded) {
    return null;
  }

  return (
    <ThemeContext.Provider
      value={{
        theme,
        updateTheme,
        resetTheme,
        saveTheme,
        loadTheme,
        addElement,
        updateElement,
        removeElement,
        addNavigationLink,
        updateNavigationLink,
        removeNavigationLink,
      }}
    >
      {children}
    </ThemeContext.Provider>
  );
}

export function useThemeCustomization(): ThemeContextType {
  const context = useContext(ThemeContext);
  if (!context) {
    throw new Error('useThemeCustomization must be used within ThemeProvider');
  }
  return context;
}
