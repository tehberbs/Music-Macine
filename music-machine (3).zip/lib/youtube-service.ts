// YouTube Service - Real YouTube API Integration
export interface YouTubeVideo {
  id: string;
  title: string;
  thumbnail: string;
  channel: string;
  channelId: string;
  duration: string;
  durationSeconds: number;
  viewCount: string;
  publishedAt: string;
  description: string;
}

export interface YouTubeSearchResult {
  videos: YouTubeVideo[];
  nextPageToken?: string;
  totalResults: number;
}

export class YouTubeService {
  private apiKey: string = '';
  private baseUrl = 'https://www.googleapis.com/youtube/v3';

  constructor(apiKey?: string) {
    if (apiKey) {
      this.apiKey = apiKey;
    }
  }

  setApiKey(apiKey: string) {
    this.apiKey = apiKey;
  }

  async searchVideos(query: string, maxResults: number = 20, pageToken?: string): Promise<YouTubeSearchResult> {
    if (!this.apiKey) {
      return this.getMockSearchResults(query, maxResults);
    }

    try {
      const params = new URLSearchParams({
        part: 'snippet',
        q: query,
        type: 'video',
        maxResults: maxResults.toString(),
        key: this.apiKey,
        relevanceLanguage: 'en',
        order: 'relevance',
        ...(pageToken && { pageToken }),
      });

      const response = await fetch(`${this.baseUrl}/search?${params}`);
      if (!response.ok) {
        throw new Error(`YouTube API error: ${response.statusText}`);
      }

      const data = await response.json();
      return this.parseSearchResults(data);
    } catch (error) {
      console.error('YouTube search error:', error);
      // Fallback to mock results
      return this.getMockSearchResults(query, maxResults);
    }
  }

  async getVideoDetails(videoId: string): Promise<YouTubeVideo | null> {
    if (!this.apiKey) {
      return this.getMockVideoDetails(videoId);
    }

    try {
      const params = new URLSearchParams({
        part: 'snippet,contentDetails,statistics',
        id: videoId,
        key: this.apiKey,
      });

      const response = await fetch(`${this.baseUrl}/videos?${params}`);
      if (!response.ok) {
        throw new Error(`YouTube API error: ${response.statusText}`);
      }

      const data = await response.json();
      if (data.items && data.items.length > 0) {
        return this.parseVideoDetails(data.items[0]);
      }
      return null;
    } catch (error) {
      console.error('YouTube details error:', error);
      return this.getMockVideoDetails(videoId);
    }
  }

  private parseSearchResults(data: any): YouTubeSearchResult {
    const videos: YouTubeVideo[] = (data.items || []).map((item: any) => ({
      id: item.id.videoId,
      title: item.snippet.title,
      thumbnail: item.snippet.thumbnails.medium?.url || item.snippet.thumbnails.default?.url,
      channel: item.snippet.channelTitle,
      channelId: item.snippet.channelId,
      duration: 'N/A',
      durationSeconds: 0,
      viewCount: 'N/A',
      publishedAt: item.snippet.publishedAt,
      description: item.snippet.description,
    }));

    return {
      videos,
      nextPageToken: data.nextPageToken,
      totalResults: data.pageInfo?.totalResults || 0,
    };
  }

  private parseVideoDetails(item: any): YouTubeVideo {
    const duration = this.parseDuration(item.contentDetails?.duration || 'PT0S');
    const durationSeconds = this.durationToSeconds(item.contentDetails?.duration || 'PT0S');

    return {
      id: item.id,
      title: item.snippet.title,
      thumbnail: item.snippet.thumbnails.medium?.url || item.snippet.thumbnails.default?.url,
      channel: item.snippet.channelTitle,
      channelId: item.snippet.channelId,
      duration,
      durationSeconds,
      viewCount: this.formatNumber(item.statistics?.viewCount || '0'),
      publishedAt: item.snippet.publishedAt,
      description: item.snippet.description,
    };
  }

  private parseDuration(duration: string): string {
    // Parse ISO 8601 duration format (PT1H2M3S)
    const regex = /PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?/;
    const matches = duration.match(regex);

    if (!matches) return '0:00';

    const hours = parseInt(matches[1] || '0', 10);
    const minutes = parseInt(matches[2] || '0', 10);
    const seconds = parseInt(matches[3] || '0', 10);

    if (hours > 0) {
      return `${hours}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
    }
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
  }

  private durationToSeconds(duration: string): number {
    const regex = /PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?/;
    const matches = duration.match(regex);

    if (!matches) return 0;

    const hours = parseInt(matches[1] || '0', 10);
    const minutes = parseInt(matches[2] || '0', 10);
    const seconds = parseInt(matches[3] || '0', 10);

    return hours * 3600 + minutes * 60 + seconds;
  }

  private formatNumber(num: string): string {
    const n = parseInt(num, 10);
    if (n >= 1000000) return `${(n / 1000000).toFixed(1)}M`;
    if (n >= 1000) return `${(n / 1000).toFixed(1)}K`;
    return n.toString();
  }

  private getMockSearchResults(query: string, maxResults: number): YouTubeSearchResult {
    const mockVideos: YouTubeVideo[] = [
      {
        id: 'dQw4w9WgXcQ',
        title: `${query} - Official Music Video`,
        thumbnail: 'https://via.placeholder.com/320x180?text=Music+Video',
        channel: 'Official Channel',
        channelId: 'UCofficial',
        duration: '3:45',
        durationSeconds: 225,
        viewCount: '1.2M',
        publishedAt: new Date().toISOString(),
        description: `Official music video for ${query}`,
      },
      {
        id: 'jNQXAC9IVRw',
        title: `${query} - Live Performance`,
        thumbnail: 'https://via.placeholder.com/320x180?text=Live+Performance',
        channel: 'Music Channel',
        channelId: 'UCmusic',
        duration: '4:12',
        durationSeconds: 252,
        viewCount: '850K',
        publishedAt: new Date().toISOString(),
        description: `Live performance of ${query}`,
      },
      {
        id: 'E4MZZ3MQVd4',
        title: `${query} - Remix`,
        thumbnail: 'https://via.placeholder.com/320x180?text=Remix',
        channel: 'Remix Artist',
        channelId: 'UCremix',
        duration: '3:28',
        durationSeconds: 208,
        viewCount: '450K',
        publishedAt: new Date().toISOString(),
        description: `Remix version of ${query}`,
      },
    ];

    return {
      videos: mockVideos.slice(0, maxResults),
      totalResults: 3,
    };
  }

  private getMockVideoDetails(videoId: string): YouTubeVideo {
    return {
      id: videoId,
      title: 'Sample Music Video',
      thumbnail: 'https://via.placeholder.com/320x180?text=Music+Video',
      channel: 'Music Channel',
      channelId: 'UCmusic',
      duration: '3:45',
      durationSeconds: 225,
      viewCount: '1.2M',
      publishedAt: new Date().toISOString(),
      description: 'This is a sample music video description.',
    };
  }
}

// Singleton instance
let youtubeService: YouTubeService | null = null;

export function getYouTubeService(): YouTubeService {
  if (!youtubeService) {
    // Try to get API key from environment
    let apiKey = '';
    
    // Check for environment variable in Node.js
    if (typeof process !== 'undefined' && process.env?.YOUTUBE_API_KEY) {
      apiKey = process.env.YOUTUBE_API_KEY;
    }
    // Check for global variable (set by app initialization)
    else if (typeof globalThis !== 'undefined' && (globalThis as any).YOUTUBE_API_KEY) {
      apiKey = (globalThis as any).YOUTUBE_API_KEY;
    }
    // Fallback to hardcoded key if available
    else {
      apiKey = 'AIzaSyCM6DzrPxadighRuRCePSAhmKKnC-B_o40';
    }
    
    youtubeService = new YouTubeService(apiKey);
    console.log('[YouTubeService] Initialized with API key:', apiKey ? '✓ Present' : '✗ Missing');
  }
  return youtubeService;
}

export function initializeYouTubeService(apiKey: string) {
  youtubeService = new YouTubeService(apiKey);
  return youtubeService;
}
