/**
 * Stem Presets Service
 * Provides preset configurations for quick stem adjustment
 */

export interface StemPreset {
  id: string;
  name: string;
  description: string;
  drumVolume: number;
  guitarVolume: number;
  synthVolume: number;
  vocalVolume: number;
}

export const STEM_PRESETS: Record<string, StemPreset> = {
  // Vocals Only - Remove all instruments
  vocalsOnly: {
    id: 'vocalsOnly',
    name: 'Vocals Only',
    description: 'Isolate vocals by removing instruments',
    drumVolume: 0,
    guitarVolume: 0,
    synthVolume: 0,
    vocalVolume: 100,
  },

  // Instrumental - Remove vocals
  instrumental: {
    id: 'instrumental',
    name: 'Instrumental',
    description: 'Remove vocals to hear instruments',
    drumVolume: 100,
    guitarVolume: 100,
    synthVolume: 100,
    vocalVolume: 0,
  },

  // Drums Focus - Emphasize drums
  drumsFocus: {
    id: 'drumsFocus',
    name: 'Drums Focus',
    description: 'Emphasize drums and reduce other instruments',
    drumVolume: 100,
    guitarVolume: 50,
    synthVolume: 50,
    vocalVolume: 50,
  },

  // Bass Heavy - Emphasize bass and drums
  bassHeavy: {
    id: 'bassHeavy',
    name: 'Bass Heavy',
    description: 'Emphasize bass and drums',
    drumVolume: 100,
    guitarVolume: 70,
    synthVolume: 100,
    vocalVolume: 60,
  },

  // Vocals Boost - Emphasize vocals
  vocalsBoost: {
    id: 'vocalsBoost',
    name: 'Vocals Boost',
    description: 'Emphasize vocals while keeping instruments',
    drumVolume: 70,
    guitarVolume: 70,
    synthVolume: 70,
    vocalVolume: 100,
  },

  // Balanced - All instruments at normal level
  balanced: {
    id: 'balanced',
    name: 'Balanced',
    description: 'All instruments at normal volume',
    drumVolume: 100,
    guitarVolume: 100,
    synthVolume: 100,
    vocalVolume: 100,
  },

  // Acoustic - Reduce synth and drums
  acoustic: {
    id: 'acoustic',
    name: 'Acoustic',
    description: 'Emphasize acoustic instruments',
    drumVolume: 60,
    guitarVolume: 100,
    synthVolume: 30,
    vocalVolume: 100,
  },

  // Electronic - Emphasize synth and drums
  electronic: {
    id: 'electronic',
    name: 'Electronic',
    description: 'Emphasize electronic and synth sounds',
    drumVolume: 100,
    guitarVolume: 50,
    synthVolume: 100,
    vocalVolume: 70,
  },
};

export class StemPresetsService {
  /**
   * Get all available presets
   */
  static getAllPresets(): StemPreset[] {
    return Object.values(STEM_PRESETS);
  }

  /**
   * Get preset by ID
   */
  static getPreset(presetId: string): StemPreset | undefined {
    return STEM_PRESETS[presetId];
  }

  /**
   * Get preset names for UI display
   */
  static getPresetNames(): { id: string; name: string }[] {
    return Object.values(STEM_PRESETS).map((preset) => ({
      id: preset.id,
      name: preset.name,
    }));
  }

  /**
   * Create custom preset
   */
  static createCustomPreset(
    name: string,
    description: string,
    drumVolume: number,
    guitarVolume: number,
    synthVolume: number,
    vocalVolume: number
  ): StemPreset {
    return {
      id: `custom_${Date.now()}`,
      name,
      description,
      drumVolume: Math.max(0, Math.min(100, drumVolume)),
      guitarVolume: Math.max(0, Math.min(100, guitarVolume)),
      synthVolume: Math.max(0, Math.min(100, synthVolume)),
      vocalVolume: Math.max(0, Math.min(100, vocalVolume)),
    };
  }
}
