/**
 * Offline Cache Service
 * Manages offline storage and caching of downloaded tracks
 */

import AsyncStorage from '@react-native-async-storage/async-storage';
import * as FileSystem from 'expo-file-system/legacy';

export interface CachedTrack {
  id: string;
  title: string;
  artist: string;
  uri: string;
  localPath: string;
  fileSize: number;
  downloadedAt: number;
  isOfflineAvailable: boolean;
}

const CACHE_KEY = 'music_machine_offline_cache';
const CACHE_DIR = `${FileSystem.documentDirectory}music_machine_cache/`;
const MAX_CACHE_SIZE = 500 * 1024 * 1024; // 500 MB

export class OfflineCacheService {
  /**
   * Initialize cache directory
   */
  static async initializeCache(): Promise<void> {
    try {
      const dirInfo = await FileSystem.getInfoAsync(CACHE_DIR);
      if (!dirInfo.exists) {
        await FileSystem.makeDirectoryAsync(CACHE_DIR, { intermediates: true });
      }
    } catch (error) {
      console.error('Failed to initialize cache directory:', error);
    }
  }

  /**
   * Add track to offline cache
   */
  static async addToCache(track: Omit<CachedTrack, 'downloadedAt' | 'localPath'>): Promise<CachedTrack | null> {
    try {
      await this.initializeCache();

      // Generate local path
      const localPath = `${CACHE_DIR}${track.id}.mp3`;

      // Check cache size
      const cacheSize = await this.getCacheSize();
      if (cacheSize + track.fileSize > MAX_CACHE_SIZE) {
        // Remove oldest files to make space
        await this.cleanupOldestFiles(track.fileSize);
      }

      const cachedTrack: CachedTrack = {
        ...track,
        localPath,
        downloadedAt: Date.now(),
        isOfflineAvailable: true,
      };

      // Add to cache list
      const cache = await this.getCache();
      cache.unshift(cachedTrack);

      await AsyncStorage.setItem(CACHE_KEY, JSON.stringify(cache));

      return cachedTrack;
    } catch (error) {
      console.error('Failed to add to cache:', error);
      return null;
    }
  }

  /**
   * Get cached track
   */
  static async getCachedTrack(trackId: string): Promise<CachedTrack | null> {
    try {
      const cache = await this.getCache();
      return cache.find((track) => track.id === trackId) || null;
    } catch (error) {
      console.error('Failed to get cached track:', error);
      return null;
    }
  }

  /**
   * Get all cached tracks
   */
  static async getCache(): Promise<CachedTrack[]> {
    try {
      const data = await AsyncStorage.getItem(CACHE_KEY);
      return data ? JSON.parse(data) : [];
    } catch (error) {
      console.error('Failed to get cache:', error);
      return [];
    }
  }

  /**
   * Remove track from cache
   */
  static async removeFromCache(trackId: string): Promise<void> {
    try {
      const cache = await this.getCache();
      const track = cache.find((t) => t.id === trackId);

      if (track) {
        // Delete file
        try {
          await FileSystem.deleteAsync(track.localPath);
        } catch (error) {
          console.error('Failed to delete cached file:', error);
        }

        // Remove from cache list
        const filtered = cache.filter((t) => t.id !== trackId);
        await AsyncStorage.setItem(CACHE_KEY, JSON.stringify(filtered));
      }
    } catch (error) {
      console.error('Failed to remove from cache:', error);
    }
  }

  /**
   * Get cache size in bytes
   */
  static async getCacheSize(): Promise<number> {
    try {
      const cache = await this.getCache();
      return cache.reduce((sum, track) => sum + track.fileSize, 0);
    } catch (error) {
      console.error('Failed to get cache size:', error);
      return 0;
    }
  }

  /**
   * Get cache size formatted as string
   */
  static async getCacheSizeFormatted(): Promise<string> {
    try {
      const bytes = await this.getCacheSize();
      const mb = (bytes / 1024 / 1024).toFixed(1);
      return `${mb} MB`;
    } catch (error) {
      console.error('Failed to get formatted cache size:', error);
      return '0 MB';
    }
  }

  /**
   * Clear entire cache
   */
  static async clearCache(): Promise<void> {
    try {
      const cache = await this.getCache();

      // Delete all files
      for (const track of cache) {
        try {
          await FileSystem.deleteAsync(track.localPath);
        } catch (error) {
          console.error(`Failed to delete ${track.localPath}:`, error);
        }
      }

      // Clear cache list
      await AsyncStorage.removeItem(CACHE_KEY);
    } catch (error) {
      console.error('Failed to clear cache:', error);
    }
  }

  /**
   * Clean up oldest files to make space
   */
  private static async cleanupOldestFiles(requiredSpace: number): Promise<void> {
    try {
      const cache = await this.getCache();

      // Sort by download date (oldest first)
      cache.sort((a, b) => a.downloadedAt - b.downloadedAt);

      let freedSpace = 0;
      const toDelete: string[] = [];

      for (const track of cache) {
        if (freedSpace >= requiredSpace) break;

        try {
          await FileSystem.deleteAsync(track.localPath);
          freedSpace += track.fileSize;
          toDelete.push(track.id);
        } catch (error) {
          console.error(`Failed to delete ${track.localPath}:`, error);
        }
      }

      // Update cache list
      const filtered = cache.filter((t) => !toDelete.includes(t.id));
      await AsyncStorage.setItem(CACHE_KEY, JSON.stringify(filtered));
    } catch (error) {
      console.error('Failed to cleanup cache:', error);
    }
  }

  /**
   * Check if track is available offline
   */
  static async isOfflineAvailable(trackId: string): Promise<boolean> {
    try {
      const track = await this.getCachedTrack(trackId);
      if (!track) return false;

      // Check if file exists
      const fileInfo = await FileSystem.getInfoAsync(track.localPath);
      return fileInfo.exists;
    } catch (error) {
      console.error('Failed to check offline availability:', error);
      return false;
    }
  }

  /**
   * Get offline available tracks
   */
  static async getOfflineAvailableTracks(): Promise<CachedTrack[]> {
    try {
      const cache = await this.getCache();
      const available: CachedTrack[] = [];

      for (const track of cache) {
        const isAvailable = await this.isOfflineAvailable(track.id);
        if (isAvailable) {
          available.push(track);
        }
      }

      return available;
    } catch (error) {
      console.error('Failed to get offline available tracks:', error);
      return [];
    }
  }
}
