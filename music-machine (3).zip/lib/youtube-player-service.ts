/**
 * YouTube Player Service
 * Handles YouTube video playback using expo-video or WebView
 */

export interface YouTubeVideo {
  id: string;
  title: string;
  channel: string;
  duration: number;
  thumbnail: string;
  url: string;
}

class YouTubePlayerService {
  /**
   * Get YouTube video stream URL
   * Note: Direct streaming requires yt-dlp or similar backend service
   */
  async getVideoStreamUrl(videoId: string): Promise<string | null> {
    try {
      // In production, this would call a backend service that uses yt-dlp
      // to extract the actual video stream URL
      const backendUrl = process.env.YOUTUBE_BACKEND_URL || 'http://localhost:3000';

      const response = await fetch(`${backendUrl}/api/youtube/stream/${videoId}`);

      if (!response.ok) {
        throw new Error(`Failed to get stream URL: ${response.status}`);
      }

      const data = await response.json();
      return data.streamUrl || null;
    } catch (error) {
      console.error('[YouTubePlayer] Error getting stream URL:', error);
      return null;
    }
  }

  /**
   * Get YouTube video info
   */
  async getVideoInfo(videoId: string): Promise<YouTubeVideo | null> {
    try {
      const backendUrl = process.env.YOUTUBE_BACKEND_URL || 'http://localhost:3000';

      const response = await fetch(`${backendUrl}/api/youtube/info/${videoId}`);

      if (!response.ok) {
        throw new Error(`Failed to get video info: ${response.status}`);
      }

      const data = await response.json();
      return data.video || null;
    } catch (error) {
      console.error('[YouTubePlayer] Error getting video info:', error);
      return null;
    }
  }

  /**
   * Generate YouTube embed URL
   */
  getEmbedUrl(videoId: string): string {
    return `https://www.youtube.com/embed/${videoId}?autoplay=1`;
  }

  /**
   * Generate YouTube watch URL
   */
  getWatchUrl(videoId: string): string {
    return `https://www.youtube.com/watch?v=${videoId}`;
  }

  /**
   * Generate YouTube thumbnail URL
   */
  getThumbnailUrl(videoId: string, quality: 'default' | 'medium' | 'high' | 'standard' | 'maxres' = 'high'): string {
    const qualityMap: Record<string, string> = {
      default: `https://img.youtube.com/vi/${videoId}/default.jpg`,
      medium: `https://img.youtube.com/vi/${videoId}/mqdefault.jpg`,
      high: `https://img.youtube.com/vi/${videoId}/hqdefault.jpg`,
      standard: `https://img.youtube.com/vi/${videoId}/sddefault.jpg`,
      maxres: `https://img.youtube.com/vi/${videoId}/maxresdefault.jpg`,
    };

    return qualityMap[quality] || qualityMap.high;
  }

  /**
   * Extract video ID from YouTube URL
   */
  extractVideoId(url: string): string | null {
    const patterns = [
      /(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/)([^&\n?#]+)/,
      /^([a-zA-Z0-9_-]{11})$/,
    ];

    for (const pattern of patterns) {
      const match = url.match(pattern);
      if (match) {
        return match[1];
      }
    }

    return null;
  }

  /**
   * Format video duration (seconds to HH:MM:SS)
   */
  formatDuration(seconds: number): string {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = Math.floor(seconds % 60);

    if (hours > 0) {
      return `${hours}:${String(minutes).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
    }

    return `${minutes}:${String(secs).padStart(2, '0')}`;
  }
}

export const youtubePlayerService = new YouTubePlayerService();
