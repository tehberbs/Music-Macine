import Animated, {
  useSharedValue,
  withTiming,
  interpolateColor,
  interpolate,
  Extrapolate,
} from 'react-native-reanimated';

export interface ThemeTransitionConfig {
  duration?: number;
}

const DEFAULT_CONFIG: ThemeTransitionConfig = {
  duration: 600,
};

/**
 * Hook for using theme transitions in components
 */
export function useThemeTransition(config: ThemeTransitionConfig = DEFAULT_CONFIG) {
  const progress = useSharedValue(0);

  const startTransition = () => {
    const duration = config.duration || DEFAULT_CONFIG.duration!;
    progress.value = withTiming(1, { duration }, () => {
      progress.value = 0;
    });
  };

  const animateColor = (fromColor: string, toColor: string) => {
    return interpolateColor(progress.value, [0, 1], [fromColor, toColor]);
  };

  const animateValue = (fromValue: number, toValue: number) => {
    return interpolate(progress.value, [0, 1], [fromValue, toValue], Extrapolate.CLAMP);
  };

  return {
    progress,
    startTransition,
    animateColor,
    animateValue,
  };
}

/**
 * Utility function to convert hex color to RGB
 */
export function hexToRgb(hex: string): { r: number; g: number; b: number } {
  const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
  return result
    ? {
        r: parseInt(result[1], 16),
        g: parseInt(result[2], 16),
        b: parseInt(result[3], 16),
      }
    : { r: 0, g: 0, b: 0 };
}

/**
 * Utility function to convert RGB to hex color
 */
export function rgbToHex(r: number, g: number, b: number): string {
  return '#' + [r, g, b].map((x) => {
    const hex = x.toString(16);
    return hex.length === 1 ? '0' + hex : hex;
  }).join('');
}

/**
 * Interpolate between two RGB colors
 */
export function interpolateRgbColor(
  progress: number,
  fromColor: string,
  toColor: string
): string {
  const from = hexToRgb(fromColor);
  const to = hexToRgb(toColor);

  const r = Math.round(from.r + (to.r - from.r) * progress);
  const g = Math.round(from.g + (to.g - from.g) * progress);
  const b = Math.round(from.b + (to.b - from.b) * progress);

  return rgbToHex(r, g, b);
}
