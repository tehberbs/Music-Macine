// @ts-ignore - expo-image-picker types
import * as ImagePicker from 'expo-image-picker';
import * as FileSystem from 'expo-file-system/legacy';
import AsyncStorage from '@react-native-async-storage/async-storage';

export interface UploadedImage {
  id: string;
  uri: string;
  name: string;
  size: number;
  uploadedAt: number;
}

const IMAGES_STORAGE_KEY = 'musicMachineUploadedImages';
const IMAGES_DIRECTORY = `${FileSystem.documentDirectory}music-machine-images/`;

export const ImageUploadService = {
  async ensureDirectoryExists() {
    try {
      const dirInfo = await FileSystem.getInfoAsync(IMAGES_DIRECTORY);
      if (!dirInfo.exists) {
        await FileSystem.makeDirectoryAsync(IMAGES_DIRECTORY, {
          intermediates: true,
        });
      }
    } catch (error) {
      console.error('[ImageUploadService] Failed to create directory:', error);
    }
  },

  async pickImage(): Promise<UploadedImage | null> {
    try {
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        aspect: [4, 3],
        quality: 0.8,
      });

      if (result.canceled) {
        return null;
      }

      const asset = result.assets[0];
      return this.uploadImage(asset.uri, asset.fileName || 'image.jpg');
    } catch (error) {
      console.error('[ImageUploadService] Failed to pick image:', error);
      return null;
    }
  },

  async uploadImage(sourceUri: string, fileName: string): Promise<UploadedImage | null> {
    try {
      await this.ensureDirectoryExists();

      const id = `img_${Date.now()}`;
      const fileExtension = fileName.split('.').pop() || 'jpg';
      const destinationUri = `${IMAGES_DIRECTORY}${id}.${fileExtension}`;

      // Copy image to app directory
      await FileSystem.copyAsync({
        from: sourceUri,
        to: destinationUri,
      });

      // Get file info
      const fileInfo = await FileSystem.getInfoAsync(destinationUri);

      const uploadedImage: UploadedImage = {
        id,
        uri: destinationUri,
        name: fileName,
        size: (fileInfo as any).size || 0,
        uploadedAt: Date.now(),
      };

      // Save to storage
      await this.saveImageMetadata(uploadedImage);

      return uploadedImage;
    } catch (error) {
      console.error('[ImageUploadService] Failed to upload image:', error);
      return null;
    }
  },

  async saveImageMetadata(image: UploadedImage) {
    try {
      const existing = await this.getAllImages();
      const updated = [...existing, image];
      await AsyncStorage.setItem(IMAGES_STORAGE_KEY, JSON.stringify(updated));
    } catch (error) {
      console.error('[ImageUploadService] Failed to save image metadata:', error);
    }
  },

  async getAllImages(): Promise<UploadedImage[]> {
    try {
      const stored = await AsyncStorage.getItem(IMAGES_STORAGE_KEY);
      return stored ? JSON.parse(stored) : [];
    } catch (error) {
      console.error('[ImageUploadService] Failed to get images:', error);
      return [];
    }
  },

  async getImage(id: string): Promise<UploadedImage | null> {
    try {
      const images = await this.getAllImages();
      return images.find((img) => img.id === id) || null;
    } catch (error) {
      console.error('[ImageUploadService] Failed to get image:', error);
      return null;
    }
  },

  async deleteImage(id: string): Promise<boolean> {
    try {
      const image = await this.getImage(id);
      if (!image) {
        return false;
      }

      // Delete file
      await FileSystem.deleteAsync(image.uri, { idempotent: true });

      // Remove from storage
      const images = await this.getAllImages();
      const updated = images.filter((img) => img.id !== id);
      await AsyncStorage.setItem(IMAGES_STORAGE_KEY, JSON.stringify(updated));

      return true;
    } catch (error) {
      console.error('[ImageUploadService] Failed to delete image:', error);
      return false;
    }
  },

  async clearAllImages(): Promise<void> {
    try {
      const images = await this.getAllImages();
      for (const image of images) {
        await FileSystem.deleteAsync(image.uri, { idempotent: true });
      }
      await AsyncStorage.removeItem(IMAGES_STORAGE_KEY);
    } catch (error) {
      console.error('[ImageUploadService] Failed to clear images:', error);
    }
  },

  formatFileSize(bytes: number): string {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return Math.round((bytes / Math.pow(k, i)) * 100) / 100 + ' ' + sizes[i];
  },
};
