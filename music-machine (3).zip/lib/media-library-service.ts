// Media Library Service - Load audio files from device storage
import * as MediaLibrary from 'expo-media-library';

export interface AudioFile {
  id: string;
  filename: string;
  uri: string;
  duration: number;
  fileSize: number;
  mediaType: string;
  creationTime: number;
  modificationTime: number;
  title: string;
  artist: string;
  album: string;
}

export class MediaLibraryService {
  private audioFiles: AudioFile[] = [];

  /**
   * Request permission and load all audio files from device.
   * Always re-requests permission so the prompt appears on first use.
   */
  async getAudioFiles(): Promise<AudioFile[]> {
    try {
      // Always request permission (no-op if already granted)
      const { granted } = await MediaLibrary.requestPermissionsAsync();
      if (!granted) {
        console.warn('[MediaLibrary] Permission not granted by user');
        return [];
      }

      // Fetch all audio assets (up to 2000)
      const result = await MediaLibrary.getAssetsAsync({
        mediaType: MediaLibrary.MediaType.audio,
        first: 2000,
        sortBy: [[MediaLibrary.SortBy.modificationTime, false]],
      });

      console.log(`[MediaLibrary] Found ${result.assets.length} audio assets`);

      // Resolve localUri for each asset (needed on Android for file:// URIs)
      const files: AudioFile[] = await Promise.all(
        result.assets.map(async (asset) => {
          let uri = asset.uri;
          try {
            const info = await MediaLibrary.getAssetInfoAsync(asset);
            if (info.localUri) uri = info.localUri;
          } catch (_) {
            // fall back to asset.uri
          }

          const { title, artist } = this.parseName(asset.filename);

          return {
            id: asset.id,
            filename: asset.filename,
            uri,
            duration: asset.duration ?? 0,
            fileSize: 0,
            mediaType: asset.mediaType,
            creationTime: asset.creationTime ?? 0,
            modificationTime: asset.modificationTime ?? 0,
            title,
            artist,
            album: 'Unknown Album',
          };
        })
      );

      this.audioFiles = files;
      return files;
    } catch (error) {
      console.error('[MediaLibrary] Failed to load audio files:', error);
      return [];
    }
  }

  /**
   * Return cached files without re-fetching.
   */
  getCachedAudioFiles(): AudioFile[] {
    return this.audioFiles;
  }

  /**
   * Search cached audio files.
   */
  searchAudioFiles(query: string): AudioFile[] {
    const q = query.toLowerCase();
    return this.audioFiles.filter(
      (f) =>
        f.title.toLowerCase().includes(q) ||
        f.artist.toLowerCase().includes(q) ||
        f.filename.toLowerCase().includes(q)
    );
  }

  /**
   * Parse title/artist from filename.
   * Supports "Artist - Title.mp3" or "Title.mp3"
   */
  private parseName(filename: string): { title: string; artist: string } {
    const name = filename.replace(/\.[^/.]+$/, '').trim();
    const dashIdx = name.indexOf(' - ');
    if (dashIdx > 0) {
      return {
        artist: name.slice(0, dashIdx).trim() || 'Unknown Artist',
        title: name.slice(dashIdx + 3).trim() || name,
      };
    }
    return { title: name || 'Unknown Title', artist: 'Unknown Artist' };
  }
}

// Singleton
let _instance: MediaLibraryService | null = null;
export function getMediaLibraryService(): MediaLibraryService {
  if (!_instance) _instance = new MediaLibraryService();
  return _instance;
}
