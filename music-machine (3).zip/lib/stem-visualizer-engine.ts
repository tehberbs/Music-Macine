// AI Stem Visualizer Engine - 8 stem-reactive visualizations
export type StemVisualizerType =
  | 'drum-reactor'
  | 'bass-wave'
  | 'vocal-spectrum'
  | 'guitar-ripple'
  | 'synth-aurora'
  | 'piano-cascade'
  | 'string-harmony'
  | 'percussion-burst';

export interface StemData {
  drums: number;
  bass: number;
  vocals: number;
  guitar: number;
  synth: number;
  piano: number;
  strings: number;
  percussion: number;
}

export interface StemVisualizerSettings {
  type: StemVisualizerType;
  primaryColor: string;
  secondaryColor?: string;
  intensity: number; // 0-100
  speed: number; // 0-100
  sensitivity: number; // 0-100
  opacity: number; // 0-100
}

export interface StemVisualizerData {
  bars: number[];
  particles?: Array<{ x: number; y: number; size: number; opacity: number; color: string }>;
  rotation?: number;
  scale?: number;
  time?: number;
  stemColors?: Record<string, string>;
}

export class StemVisualizerEngine {
  private stemData: StemData = {
    drums: 0,
    bass: 0,
    vocals: 0,
    guitar: 0,
    synth: 0,
    piano: 0,
    strings: 0,
    percussion: 0,
  };
  private time: number = 0;
  private settings: StemVisualizerSettings;

  constructor(settings: StemVisualizerSettings) {
    this.settings = settings;
  }

  updateSettings(settings: Partial<StemVisualizerSettings>) {
    this.settings = { ...this.settings, ...settings };
  }

  updateStemData(data: Partial<StemData>) {
    this.stemData = { ...this.stemData, ...data };
  }

  generateVisualizerData(): StemVisualizerData {
    this.time += this.settings.speed / 100;

    switch (this.settings.type) {
      case 'drum-reactor':
        return this.generateDrumReactor();
      case 'bass-wave':
        return this.generateBassWave();
      case 'vocal-spectrum':
        return this.generateVocalSpectrum();
      case 'guitar-ripple':
        return this.generateGuitarRipple();
      case 'synth-aurora':
        return this.generateSynthAurora();
      case 'piano-cascade':
        return this.generatePianoCascade();
      case 'string-harmony':
        return this.generateStringHarmony();
      case 'percussion-burst':
        return this.generatePercussionBurst();
      default:
        return this.generateDrumReactor();
    }
  }

  private generateDrumReactor(): StemVisualizerData {
    const bars: number[] = [];
    const drumIntensity = this.stemData.drums * (this.settings.sensitivity / 100);
    const percussionIntensity = this.stemData.percussion * (this.settings.sensitivity / 100);

    for (let i = 0; i < 16; i++) {
      const beat = Math.sin((i / 16) * Math.PI * 2 + this.time) * 0.5 + 0.5;
      const drumPulse = Math.max(0, Math.sin(this.time * 4) * 0.5 + 0.5);
      bars.push((drumIntensity + percussionIntensity) * beat * drumPulse);
    }

    return {
      bars,
      rotation: drumIntensity * 360,
      scale: 0.5 + drumIntensity * 0.5,
      stemColors: {
        drums: '#FF1744',
        percussion: '#FF5722',
      },
    };
  }

  private generateBassWave(): StemVisualizerData {
    const bars: number[] = [];
    const bassIntensity = this.stemData.bass * (this.settings.sensitivity / 100);

    for (let i = 0; i < 32; i++) {
      const wave = Math.sin((i / 32) * Math.PI * 2 + this.time * 0.5) * 0.5 + 0.5;
      const bassModulation = Math.sin(this.time + i * 0.2) * 0.5 + 0.5;
      bars.push(bassIntensity * wave * bassModulation);
    }

    return {
      bars,
      scale: 0.7 + bassIntensity * 0.3,
      stemColors: { bass: '#1976D2' },
    };
  }

  private generateVocalSpectrum(): StemVisualizerData {
    const bars: number[] = [];
    const vocalIntensity = this.stemData.vocals * (this.settings.sensitivity / 100);

    for (let i = 0; i < 24; i++) {
      const midRange = Math.sin((i / 24) * Math.PI * 3 + this.time) * 0.5 + 0.5;
      const vocalPeak = Math.max(0, Math.sin(this.time * 2 - i * 0.1) * 0.5 + 0.5);
      bars.push(vocalIntensity * midRange * vocalPeak);
    }

    return {
      bars,
      rotation: this.time * 0.5,
      stemColors: { vocals: '#E91E63' },
    };
  }

  private generateGuitarRipple(): StemVisualizerData {
    const bars: number[] = [];
    const guitarIntensity = this.stemData.guitar * (this.settings.sensitivity / 100);

    const particles = [];
    for (let i = 0; i < 40; i++) {
      const angle = (i / 40) * Math.PI * 2;
      const ripple = Math.sin(this.time - i * 0.15) * 0.5 + 0.5;
      const radius = guitarIntensity * 100 * ripple + 30;

      particles.push({
        x: Math.cos(angle) * radius,
        y: Math.sin(angle) * radius,
        size: guitarIntensity * 15 + 3,
        opacity: ripple * guitarIntensity,
        color: this.settings.primaryColor,
      });
    }

    return {
      bars: [guitarIntensity],
      particles,
      stemColors: { guitar: '#FF9800' },
    };
  }

  private generateSynthAurora(): StemVisualizerData {
    const bars: number[] = [];
    const synthIntensity = this.stemData.synth * (this.settings.sensitivity / 100);

    for (let i = 0; i < 32; i++) {
      const aurora1 = Math.sin((i / 32) * Math.PI * 2 + this.time * 0.5) * 0.5 + 0.5;
      const aurora2 = Math.cos((i / 32) * Math.PI * 2 + this.time * 0.7) * 0.5 + 0.5;
      bars.push(synthIntensity * (aurora1 + aurora2) * 0.5);
    }

    return {
      bars,
      rotation: this.time * 0.3,
      scale: 0.6 + synthIntensity * 0.4,
      stemColors: { synth: '#9C27B0' },
    };
  }

  private generatePianoCascade(): StemVisualizerData {
    const bars: number[] = [];
    const pianoIntensity = this.stemData.piano * (this.settings.sensitivity / 100);

    const particles = [];
    for (let i = 0; i < 50; i++) {
      const x = (i / 50) * 200 - 100;
      const y = -100 + (this.time * 100) % 200;
      const cascade = Math.sin((i / 50) * Math.PI * 2 + this.time) * 0.5 + 0.5;

      particles.push({
        x,
        y,
        size: pianoIntensity * 12 + 2,
        opacity: Math.max(0, 1 - (this.time % 1)),
        color: this.settings.primaryColor,
      });
    }

    return {
      bars: [pianoIntensity],
      particles,
      stemColors: { piano: '#2196F3' },
    };
  }

  private generateStringHarmony(): StemVisualizerData {
    const bars: number[] = [];
    const stringIntensity = this.stemData.strings * (this.settings.sensitivity / 100);

    for (let i = 0; i < 28; i++) {
      const harmonic = Math.sin((i / 28) * Math.PI * 4 + this.time * 0.3) * 0.5 + 0.5;
      const stringVibration = Math.sin(this.time + i * 0.3) * 0.5 + 0.5;
      bars.push(stringIntensity * harmonic * stringVibration);
    }

    return {
      bars,
      rotation: stringIntensity * 180,
      stemColors: { strings: '#4CAF50' },
    };
  }

  private generatePercussionBurst(): StemVisualizerData {
    const bars: number[] = [];
    const percussionIntensity = this.stemData.percussion * (this.settings.sensitivity / 100);

    const particles = [];
    const burstCount = Math.floor(percussionIntensity * 100);
    for (let i = 0; i < burstCount; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = Math.random() * 200 + 100;
      const distance = (this.time * speed) % 300;

      particles.push({
        x: Math.cos(angle) * distance,
        y: Math.sin(angle) * distance,
        size: Math.random() * 15 + 5,
        opacity: Math.max(0, 1 - distance / 300),
        color: this.settings.primaryColor,
      });
    }

    return {
      bars: [percussionIntensity],
      particles,
      scale: 0.5 + percussionIntensity * 0.5,
      stemColors: { percussion: '#FF5722' },
    };
  }

  static getAllVisualizers(): StemVisualizerType[] {
    return [
      'drum-reactor',
      'bass-wave',
      'vocal-spectrum',
      'guitar-ripple',
      'synth-aurora',
      'piano-cascade',
      'string-harmony',
      'percussion-burst',
    ];
  }

  static getVisualizerLabel(type: StemVisualizerType): string {
    const labels: Record<StemVisualizerType, string> = {
      'drum-reactor': 'Drum Reactor',
      'bass-wave': 'Bass Wave',
      'vocal-spectrum': 'Vocal Spectrum',
      'guitar-ripple': 'Guitar Ripple',
      'synth-aurora': 'Synth Aurora',
      'piano-cascade': 'Piano Cascade',
      'string-harmony': 'String Harmony',
      'percussion-burst': 'Percussion Burst',
    };
    return labels[type] || type;
  }

  static getInstrumentColor(instrument: keyof StemData): string {
    const colors: Record<keyof StemData, string> = {
      drums: '#FF1744',
      bass: '#1976D2',
      vocals: '#E91E63',
      guitar: '#FF9800',
      synth: '#9C27B0',
      piano: '#2196F3',
      strings: '#4CAF50',
      percussion: '#FF5722',
    };
    return colors[instrument];
  }
}
