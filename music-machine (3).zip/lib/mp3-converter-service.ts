// MP3 Converter Service - YouTube to MP3 Conversion
export interface ConversionJob {
  id: string;
  videoId: string;
  title: string;
  status: 'pending' | 'downloading' | 'converting' | 'completed' | 'failed';
  progress: number; // 0-100
  error?: string;
  outputPath?: string;
  startTime: number;
  endTime?: number;
}

export class MP3ConverterService {
  private jobs: Map<string, ConversionJob> = new Map();
  private backendUrl: string = 'http://127.0.0.1:3000';

  constructor(backendUrl?: string) {
    if (backendUrl) {
      this.backendUrl = backendUrl;
    }
  }

  /**
   * Convert YouTube video to MP3
   * In production, this calls the backend API which uses yt-dlp + ffmpeg
   */
  async convertYouTubeToMP3(
    videoId: string,
    title: string,
    onProgress?: (progress: number) => void
  ): Promise<ConversionJob> {
    const jobId = `job_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    const job: ConversionJob = {
      id: jobId,
      videoId,
      title,
      status: 'pending',
      progress: 0,
      startTime: Date.now(),
    };

    this.jobs.set(jobId, job);

    try {
      // Update status to downloading
      job.status = 'downloading';
      job.progress = 10;
      onProgress?.(10);

      // Call backend API to download and convert
      const response = await this.callBackendConversion(videoId, title);

      if (response.success) {
        job.status = 'converting';
        job.progress = 50;
        onProgress?.(50);

        // Simulate conversion progress
        await this.simulateConversionProgress(job, onProgress);

        job.status = 'completed';
        job.progress = 100;
        job.outputPath = response.outputPath;
        job.endTime = Date.now();
        onProgress?.(100);
      } else {
        throw new Error(response.error || 'Conversion failed');
      }
    } catch (error) {
      job.status = 'failed';
      job.error = error instanceof Error ? error.message : 'Unknown error';
      job.endTime = Date.now();
    }

    return job;
  }

  /**
   * Get conversion job status
   */
  getJobStatus(jobId: string): ConversionJob | undefined {
    return this.jobs.get(jobId);
  }

  /**
   * Get all conversion jobs
   */
  getAllJobs(): ConversionJob[] {
    return Array.from(this.jobs.values());
  }

  /**
   * Cancel a conversion job
   */
  cancelJob(jobId: string): boolean {
    const job = this.jobs.get(jobId);
    if (job && (job.status === 'pending' || job.status === 'downloading' || job.status === 'converting')) {
      job.status = 'failed';
      job.error = 'Cancelled by user';
      job.endTime = Date.now();
      return true;
    }
    return false;
  }

  /**
   * Clear completed jobs
   */
  clearCompletedJobs(): void {
    for (const [jobId, job] of this.jobs.entries()) {
      if (job.status === 'completed' || job.status === 'failed') {
        this.jobs.delete(jobId);
      }
    }
  }

  /**
   * Call backend API for conversion
   * In production, backend uses yt-dlp to download and ffmpeg to convert to MP3
   */
  private async callBackendConversion(
    videoId: string,
    title: string
  ): Promise<{ success: boolean; outputPath?: string; error?: string }> {
    try {
      const response = await fetch(`${this.backendUrl}/api/youtube/convert-to-mp3`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          videoId,
          title,
        }),
      });

      if (!response.ok) {
        return {
          success: false,
          error: `Server error: ${response.statusText}`,
        };
      }

      const data = await response.json();
      return {
        success: true,
        outputPath: data.outputPath,
      };
    } catch (error) {
      // Fallback to mock conversion
      return this.mockConversion(videoId, title);
    }
  }

  /**
   * Simulate conversion progress for demo purposes
   */
  private async simulateConversionProgress(
    job: ConversionJob,
    onProgress?: (progress: number) => void
  ): Promise<void> {
    return new Promise((resolve) => {
      let progress = 50;
      const interval = setInterval(() => {
        progress += Math.random() * 15;
        if (progress >= 95) {
          progress = 95;
          clearInterval(interval);
          resolve();
        }
        job.progress = Math.floor(progress);
        onProgress?.(job.progress);
      }, 500);
    });
  }

  /**
   * Mock conversion for demo/fallback
   */
  private mockConversion(
    videoId: string,
    title: string
  ): { success: boolean; outputPath?: string } {
    // In production, this would be replaced with real backend API
    const outputPath = `file:///storage/music/${title.replace(/[^a-z0-9]/gi, '_')}.mp3`;
    return {
      success: true,
      outputPath,
    };
  }
}

// Singleton instance
let converterService: MP3ConverterService | null = null;

export function getMP3ConverterService(): MP3ConverterService {
  if (!converterService) {
    converterService = new MP3ConverterService();
  }
  return converterService;
}

export function initializeMP3ConverterService(backendUrl: string) {
  converterService = new MP3ConverterService(backendUrl);
  return converterService;
}
