/**
 * WaveformVisualizer - SVG-based audio visualizer for React Native
 * Uses react-native-svg only (no Skia dependency)
 */
import React, { useMemo } from 'react';
import { View, StyleSheet, Dimensions } from 'react-native';
import Svg, { Rect, Circle, Line, Path, G, Ellipse } from 'react-native-svg';

export interface WaveformVisualizerProps {
  frequencies: number[];       // normalized 0-1 values
  waveform: number[];          // normalized -1 to 1 values
  visualizationType: number;   // 0-21
  color?: string;
  secondaryColor?: string;
  intensity?: number;          // 0-1
  speed?: number;              // 0-1
  size?: number;               // 0-1
  opacity?: number;            // 0-1
}

const { width: SCREEN_WIDTH } = Dimensions.get('window');

export function WaveformVisualizer({
  frequencies,
  waveform,
  visualizationType,
  color = '#a855f7',
  secondaryColor = '#06b6d4',
  intensity = 1,
  size = 1,
  opacity = 1,
}: WaveformVisualizerProps) {
  const W = SCREEN_WIDTH - 32;
  const H = 180;
  const bars = Math.min(frequencies.length, 48);
  const barW = W / bars - 1;

  const viz = useMemo(() => {
    switch (visualizationType % 22) {
      case 0: // Waveform
        return renderWaveform(waveform, W, H, color, intensity, opacity);
      case 1: // Spectrum Bars
        return renderSpectrumBars(frequencies, bars, barW, W, H, color, secondaryColor, intensity, opacity);
      case 2: // Circular Spectrum
        return renderCircularSpectrum(frequencies, W, H, color, secondaryColor, intensity, size, opacity);
      case 3: // Particles
        return renderParticles(frequencies, W, H, color, intensity, size, opacity);
      case 4: // Geometric
        return renderGeometric(frequencies, W, H, color, intensity, opacity);
      case 5: // Kaleidoscope
        return renderKaleidoscope(frequencies, W, H, color, secondaryColor, intensity, opacity);
      case 6: // Tunnel
        return renderTunnel(frequencies, W, H, color, intensity, opacity);
      case 7: // Liquid Waves
        return renderLiquidWaves(frequencies, W, H, color, secondaryColor, intensity, opacity);
      case 8: // Radial Burst
        return renderRadialBurst(frequencies, W, H, color, intensity, opacity);
      case 9: // Fractal
        return renderFractal(frequencies, W, H, color, intensity, opacity);
      case 10: // Aurora
        return renderAurora(frequencies, W, H, intensity, opacity);
      case 11: // Orb
        return renderOrb(frequencies, W, H, color, secondaryColor, intensity, opacity);
      case 12: // Mesh Grid
        return renderMeshGrid(frequencies, W, H, color, intensity, opacity);
      case 13: // Plasma
        return renderPlasma(frequencies, W, H, color, secondaryColor, intensity, opacity);
      case 14: // Flower Bloom
        return renderFlowerBloom(frequencies, W, H, color, secondaryColor, intensity, size, opacity);
      case 15: // Meteor Shower
        return renderMeteorShower(frequencies, W, H, color, intensity, opacity);
      case 16: // DNA Helix
        return renderDNAHelix(frequencies, W, H, color, secondaryColor, intensity, opacity);
      case 17: // Sound Bars 3D
        return renderSoundBars3D(frequencies, bars, barW, W, H, color, secondaryColor, intensity, opacity);
      case 18: // Equalizer Bars (mirrored)
        return renderEqualizerBars(frequencies, bars, barW, W, H, color, secondaryColor, intensity, opacity);
      case 19: // Pulse Rings
        return renderPulseRings(frequencies, W, H, color, secondaryColor, intensity, opacity);
      case 20: // Butterfly Wings
        return renderButterflyWings(frequencies, W, H, color, secondaryColor, intensity, opacity);
      case 21: // Crystal Lattice
        return renderCrystalLattice(frequencies, W, H, color, secondaryColor, intensity, opacity);
      default:
        return renderSpectrumBars(frequencies, bars, barW, W, H, color, secondaryColor, intensity, opacity);
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [frequencies, waveform, visualizationType, color, secondaryColor, intensity, size, opacity]);

  return (
    <View style={[styles.container, { width: W, height: H }]}>
      <Svg width={W} height={H}>
        {viz}
      </Svg>
    </View>
  );
}

// ─── Visualization Renderers ────────────────────────────────────────────────

function renderWaveform(waveform: number[], W: number, H: number, color: string, intensity: number, opacity: number) {
  if (waveform.length < 2) return null;
  const step = W / (waveform.length - 1);
  const pts = waveform.map((v, i) => {
    const x = (i * step).toFixed(1);
    const y = (H / 2 + v * (H / 2) * intensity).toFixed(1);
    return `${i === 0 ? 'M' : 'L'}${x},${y}`;
  }).join(' ');
  return <Path d={pts} stroke={color} strokeWidth={2} fill="none" opacity={opacity} />;
}

function renderSpectrumBars(freq: number[], bars: number, barW: number, W: number, H: number, c1: string, c2: string, intensity: number, opacity: number) {
  return (
    <G>
      {Array.from({ length: bars }).map((_, i) => {
        const v = (freq[Math.floor((i / bars) * freq.length)] ?? 0) * intensity;
        const bh = Math.max(3, v * H);
        const x = i * (barW + 1);
        return <Rect key={i} x={x} y={H - bh} width={barW} height={bh} rx={2} fill={i % 2 === 0 ? c1 : c2} opacity={opacity} />;
      })}
    </G>
  );
}

function renderCircularSpectrum(freq: number[], W: number, H: number, c1: string, c2: string, intensity: number, size: number, opacity: number) {
  const cx = W / 2, cy = H / 2;
  const baseR = Math.min(cx, cy) * 0.35 * size;
  return (
    <G>
      {freq.map((v, i) => {
        const angle = (i / freq.length) * Math.PI * 2 - Math.PI / 2;
        const len = v * H * 0.4 * intensity;
        const x1 = cx + Math.cos(angle) * baseR;
        const y1 = cy + Math.sin(angle) * baseR;
        const x2 = cx + Math.cos(angle) * (baseR + len);
        const y2 = cy + Math.sin(angle) * (baseR + len);
        return <Line key={i} x1={x1} y1={y1} x2={x2} y2={y2} stroke={i % 2 === 0 ? c1 : c2} strokeWidth={2} opacity={opacity} />;
      })}
      <Circle cx={cx} cy={cy} r={baseR * 0.3} fill={c1} opacity={opacity * 0.6} />
    </G>
  );
}

function renderParticles(freq: number[], W: number, H: number, color: string, intensity: number, size: number, opacity: number) {
  return (
    <G>
      {freq.map((v, i) => {
        const x = (i / freq.length) * W;
        const y = H / 2 - v * H * 0.45 * intensity;
        const r = Math.max(2, v * 8 * size);
        return <Circle key={i} cx={x} cy={y} r={r} fill={color} opacity={opacity * (0.4 + v * 0.6)} />;
      })}
    </G>
  );
}

function renderGeometric(freq: number[], W: number, H: number, color: string, intensity: number, opacity: number) {
  const cx = W / 2, cy = H / 2;
  const avg = freq.reduce((a, b) => a + b, 0) / freq.length;
  const scale = 1 + avg * intensity * 2;
  const sides = 6;
  const pts = Array.from({ length: sides }).map((_, i) => {
    const a = (i / sides) * Math.PI * 2;
    return `${i === 0 ? 'M' : 'L'}${(cx + Math.cos(a) * 60 * scale).toFixed(1)},${(cy + Math.sin(a) * 60 * scale).toFixed(1)}`;
  }).join(' ') + 'Z';
  return <Path d={pts} stroke={color} strokeWidth={2 * intensity} fill="none" opacity={opacity} />;
}

function renderKaleidoscope(freq: number[], W: number, H: number, c1: string, c2: string, intensity: number, opacity: number) {
  const cx = W / 2, cy = H / 2;
  const segs = 6;
  return (
    <G>
      {Array.from({ length: segs }).map((_, seg) => {
        const baseAngle = (seg / segs) * Math.PI * 2;
        const pts = freq.slice(0, 20).map((v, i) => {
          const a = baseAngle + (i / 20) * (Math.PI / segs);
          const r = v * 80 * intensity;
          return `${i === 0 ? 'M' : 'L'}${(cx + Math.cos(a) * r).toFixed(1)},${(cy + Math.sin(a) * r).toFixed(1)}`;
        }).join(' ');
        return <Path key={seg} d={pts} stroke={seg % 2 === 0 ? c1 : c2} strokeWidth={1.5} fill="none" opacity={opacity} />;
      })}
    </G>
  );
}

function renderTunnel(freq: number[], W: number, H: number, color: string, intensity: number, opacity: number) {
  const cx = W / 2, cy = H / 2;
  const layers = 10;
  return (
    <G>
      {Array.from({ length: layers }).map((_, l) => {
        const v = freq[Math.floor((l / layers) * freq.length)] ?? 0;
        const r = (l / layers) * 80 * intensity + v * 30;
        return <Circle key={l} cx={cx} cy={cy} r={r} stroke={color} strokeWidth={1.5 * intensity} fill="none" opacity={opacity * (1 - l / layers * 0.5)} />;
      })}
    </G>
  );
}

function renderLiquidWaves(freq: number[], W: number, H: number, c1: string, c2: string, intensity: number, opacity: number) {
  const waves = 3;
  return (
    <G>
      {Array.from({ length: waves }).map((_, w) => {
        const pts = Array.from({ length: 40 }).map((_, i) => {
          const x = (i / 39) * W;
          const idx = Math.floor((i / 40) * freq.length);
          const v = freq[idx] ?? 0;
          const y = (H / waves) * (w + 0.5) + Math.sin(i * 0.3 + w * 2) * v * 40 * intensity;
          return `${i === 0 ? 'M' : 'L'}${x.toFixed(1)},${y.toFixed(1)}`;
        }).join(' ');
        return <Path key={w} d={pts} stroke={w % 2 === 0 ? c1 : c2} strokeWidth={2} fill="none" opacity={opacity * 0.8} />;
      })}
    </G>
  );
}

function renderRadialBurst(freq: number[], W: number, H: number, color: string, intensity: number, opacity: number) {
  const cx = W / 2, cy = H / 2;
  return (
    <G>
      {freq.map((v, i) => {
        const a = (i / freq.length) * Math.PI * 2;
        const len = v * 80 * intensity;
        return <Line key={i} x1={cx} y1={cy} x2={(cx + Math.cos(a) * len).toFixed(1)} y2={(cy + Math.sin(a) * len).toFixed(1)} stroke={color} strokeWidth={1 + v * 2} opacity={opacity * (0.3 + v * 0.7)} />;
      })}
    </G>
  );
}

function renderFractal(freq: number[], W: number, H: number, color: string, intensity: number, opacity: number) {
  const cx = W / 2, cy = H / 2;
  const avg = freq.reduce((a, b) => a + b, 0) / freq.length;
  return (
    <G>
      {Array.from({ length: 60 }).map((_, i) => {
        const a = (i / 60) * Math.PI * 2;
        const r = avg * 80 * intensity * Math.abs(Math.sin(i * 0.2));
        return <Circle key={i} cx={(cx + Math.cos(a) * r).toFixed(1)} cy={(cy + Math.sin(a) * r).toFixed(1)} r={2} fill={color} opacity={opacity * 0.7} />;
      })}
    </G>
  );
}

function renderAurora(freq: number[], W: number, H: number, intensity: number, opacity: number) {
  const cols = ['#7c3aed', '#2563eb', '#0891b2', '#059669', '#65a30d'];
  return (
    <G>
      {freq.slice(0, 20).map((v, i) => {
        const x = (i / 20) * W;
        const bh = v * H * 0.8 * intensity;
        const col = cols[i % cols.length];
        return <Rect key={i} x={x} y={H / 2 - bh / 2} width={W / 20} height={bh} fill={col} opacity={opacity * (0.3 + v * 0.5)} />;
      })}
    </G>
  );
}

function renderOrb(freq: number[], W: number, H: number, c1: string, c2: string, intensity: number, opacity: number) {
  const cx = W / 2, cy = H / 2;
  const avg = freq.reduce((a, b) => a + b, 0) / freq.length;
  const r = avg * 70 * intensity;
  return (
    <G>
      <Circle cx={cx} cy={cy} r={r * 1.4} fill={c2} opacity={opacity * 0.2} />
      <Circle cx={cx} cy={cy} r={r} fill={c1} opacity={opacity * 0.6} />
      <Circle cx={cx} cy={cy} r={r * 0.4} fill="#fff" opacity={opacity * 0.4} />
    </G>
  );
}

function renderMeshGrid(freq: number[], W: number, H: number, color: string, intensity: number, opacity: number) {
  const cols = 8, rows = 4;
  return (
    <G>
      {Array.from({ length: cols }).map((_, c) =>
        Array.from({ length: rows }).map((_, r) => {
          const idx = Math.floor(((c * rows + r) / (cols * rows)) * freq.length);
          const v = freq[idx] ?? 0;
          const x = (c / cols) * W;
          const y = (r / rows) * H;
          const size = v * 12 * intensity;
          return <Rect key={`${c}-${r}`} x={x - size / 2} y={y - size / 2} width={size} height={size} rx={2} fill={color} opacity={opacity * (0.3 + v * 0.7)} />;
        })
      )}
    </G>
  );
}

function renderPlasma(freq: number[], W: number, H: number, c1: string, c2: string, intensity: number, opacity: number) {
  return (
    <G>
      {freq.slice(0, 16).map((v, i) => {
        const x = (i / 16) * W;
        const r = v * 30 * intensity;
        return <Ellipse key={i} cx={x} cy={H / 2} rx={r} ry={r * 0.6} fill={i % 2 === 0 ? c1 : c2} opacity={opacity * (0.2 + v * 0.5)} />;
      })}
    </G>
  );
}

function renderFlowerBloom(freq: number[], W: number, H: number, c1: string, c2: string, intensity: number, size: number, opacity: number) {
  const cx = W / 2, cy = H / 2;
  const petals = 8;
  return (
    <G>
      {Array.from({ length: petals }).map((_, p) => {
        const a = (p / petals) * Math.PI * 2;
        const v = freq[Math.floor((p / petals) * freq.length)] ?? 0;
        const len = v * 70 * intensity * size;
        const ex = cx + Math.cos(a) * len;
        const ey = cy + Math.sin(a) * len;
        return <Ellipse key={p} cx={(cx + ex) / 2} cy={(cy + ey) / 2} rx={len / 2} ry={len / 5} fill={p % 2 === 0 ? c1 : c2} opacity={opacity * (0.4 + v * 0.5)} />;
      })}
    </G>
  );
}

function renderMeteorShower(freq: number[], W: number, H: number, color: string, intensity: number, opacity: number) {
  return (
    <G>
      {freq.slice(0, 20).map((v, i) => {
        const x = (i / 20) * W;
        const y = v * H * intensity;
        const len = v * 30 * intensity;
        return <Line key={i} x1={x} y1={y} x2={x + len * 0.5} y2={y + len} stroke={color} strokeWidth={2} opacity={opacity * (0.3 + v * 0.7)} />;
      })}
    </G>
  );
}

function renderDNAHelix(freq: number[], W: number, H: number, c1: string, c2: string, intensity: number, opacity: number) {
  const pts1 = freq.slice(0, 24).map((v, i) => {
    const x = (i / 24) * W;
    const y = H / 2 + Math.sin(i * 0.5) * v * H * 0.4 * intensity;
    return `${i === 0 ? 'M' : 'L'}${x.toFixed(1)},${y.toFixed(1)}`;
  }).join(' ');
  const pts2 = freq.slice(0, 24).map((v, i) => {
    const x = (i / 24) * W;
    const y = H / 2 - Math.sin(i * 0.5) * v * H * 0.4 * intensity;
    return `${i === 0 ? 'M' : 'L'}${x.toFixed(1)},${y.toFixed(1)}`;
  }).join(' ');
  return (
    <G>
      <Path d={pts1} stroke={c1} strokeWidth={2} fill="none" opacity={opacity} />
      <Path d={pts2} stroke={c2} strokeWidth={2} fill="none" opacity={opacity} />
    </G>
  );
}

function renderSoundBars3D(freq: number[], bars: number, barW: number, W: number, H: number, c1: string, c2: string, intensity: number, opacity: number) {
  return (
    <G>
      {Array.from({ length: bars }).map((_, i) => {
        const v = (freq[Math.floor((i / bars) * freq.length)] ?? 0) * intensity;
        const bh = Math.max(3, v * H);
        const x = i * (barW + 1);
        const shadow = Math.max(2, bh * 0.15);
        return (
          <G key={i}>
            <Rect x={x + 3} y={H - bh + 3} width={barW} height={bh} rx={2} fill={c2} opacity={opacity * 0.4} />
            <Rect x={x} y={H - bh} width={barW} height={bh} rx={2} fill={c1} opacity={opacity} />
          </G>
        );
      })}
    </G>
  );
}

function renderEqualizerBars(freq: number[], bars: number, barW: number, W: number, H: number, c1: string, c2: string, intensity: number, opacity: number) {
  return (
    <G>
      {Array.from({ length: bars }).map((_, i) => {
        const v = (freq[Math.floor((i / bars) * freq.length)] ?? 0) * intensity;
        const bh = Math.max(3, v * H * 0.5);
        const x = i * (barW + 1);
        return (
          <G key={i}>
            <Rect x={x} y={H / 2 - bh} width={barW} height={bh} rx={2} fill={c1} opacity={opacity} />
            <Rect x={x} y={H / 2} width={barW} height={bh} rx={2} fill={c2} opacity={opacity * 0.6} />
          </G>
        );
      })}
    </G>
  );
}

function renderPulseRings(freq: number[], W: number, H: number, c1: string, c2: string, intensity: number, opacity: number) {
  const cx = W / 2, cy = H / 2;
  const avg = freq.reduce((a, b) => a + b, 0) / freq.length;
  return (
    <G>
      {[0.3, 0.5, 0.7, 1.0].map((scale, i) => {
        const r = avg * 80 * intensity * scale;
        return <Circle key={i} cx={cx} cy={cy} r={r} stroke={i % 2 === 0 ? c1 : c2} strokeWidth={2} fill="none" opacity={opacity * (1 - i * 0.2)} />;
      })}
    </G>
  );
}

function renderButterflyWings(freq: number[], W: number, H: number, c1: string, c2: string, intensity: number, opacity: number) {
  const cx = W / 2, cy = H / 2;
  return (
    <G>
      {freq.slice(0, 16).map((v, i) => {
        const a = (i / 16) * Math.PI;
        const r = v * 70 * intensity;
        const lx = cx - Math.cos(a) * r;
        const ly = cy - Math.sin(a) * r * 0.6;
        const rx2 = cx + Math.cos(a) * r;
        const ry2 = cy - Math.sin(a) * r * 0.6;
        return (
          <G key={i}>
            <Ellipse cx={lx} cy={ly} rx={r * 0.4} ry={r * 0.2} fill={c1} opacity={opacity * (0.3 + v * 0.5)} />
            <Ellipse cx={rx2} cy={ry2} rx={r * 0.4} ry={r * 0.2} fill={c2} opacity={opacity * (0.3 + v * 0.5)} />
          </G>
        );
      })}
    </G>
  );
}

function renderCrystalLattice(freq: number[], W: number, H: number, c1: string, c2: string, intensity: number, opacity: number) {
  const pts: React.JSX.Element[] = [];
  const nodes = freq.slice(0, 12).map((v, i) => ({
    x: (i / 12) * W,
    y: H / 2 + (v - 0.5) * H * intensity,
    v,
  }));
  nodes.forEach((n, i) => {
    if (i < nodes.length - 1) {
      pts.push(<Line key={`l${i}`} x1={n.x} y1={n.y} x2={nodes[i + 1].x} y2={nodes[i + 1].y} stroke={c1} strokeWidth={1.5} opacity={opacity * 0.6} />);
    }
    pts.push(<Circle key={`c${i}`} cx={n.x} cy={n.y} r={4 + n.v * 8 * intensity} fill={i % 2 === 0 ? c1 : c2} opacity={opacity * (0.5 + n.v * 0.5)} />);
  });
  return <G>{pts}</G>;
}

const styles = StyleSheet.create({
  container: { overflow: 'hidden' },
});

export default WaveformVisualizer;
