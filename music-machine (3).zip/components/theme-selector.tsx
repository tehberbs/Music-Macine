import React from 'react';
import { View, Text, TouchableOpacity, ScrollView, ImageBackground, FlatList } from 'react-native';
import { CustomTheme } from '@/lib/advanced-theme-context';

interface ThemeSelectorProps {
  themes: CustomTheme[];
  currentTheme: CustomTheme;
  onSelectTheme: (themeId: string) => void;
}

export function ThemeSelector({
  themes,
  currentTheme,
  onSelectTheme,
}: ThemeSelectorProps) {
  return (
    <ScrollView className="flex-1 bg-background p-4">
      <Text className="text-2xl font-bold text-foreground mb-4">Available Themes</Text>

      <FlatList
        scrollEnabled={false}
        data={themes}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <TouchableOpacity
            onPress={() => onSelectTheme(item.id)}
            className={`mb-4 rounded-lg overflow-hidden border-2 ${
              currentTheme.id === item.id ? 'border-primary' : 'border-border'
            }`}
          >
            {/* Theme preview */}
            {item.backgroundImage ? (
              <ImageBackground
                source={{ uri: item.backgroundImage }}
                className="h-40 justify-end p-4"
              >
                <View className="bg-black/50 p-3 rounded">
                  <Text className="text-lg font-bold text-white">{item.name}</Text>
                  <Text className="text-xs text-gray-200 capitalize mt-1">{item.type}</Text>
                </View>
              </ImageBackground>
            ) : (
              <View
                className="h-40 justify-end p-4"
                style={{ backgroundColor: item.colors.background }}
              >
                <View className="bg-black/50 p-3 rounded">
                  <Text className="text-lg font-bold text-white">{item.name}</Text>
                  <Text className="text-xs text-gray-200 capitalize mt-1">{item.type}</Text>
                </View>
              </View>
            )}

            {/* Color palette preview */}
            <View className="p-4 bg-surface">
              <View className="flex-row gap-2 mb-3">
                {['primary', 'secondary', 'accent'].map((colorKey) => (
                  <View
                    key={colorKey}
                    className="flex-1 h-8 rounded-lg border border-border"
                    style={{
                      backgroundColor: item.colors[colorKey as keyof typeof item.colors],
                    }}
                  />
                ))}
              </View>

              {/* Theme info */}
              <View className="gap-2">
                <View className="flex-row justify-between items-center">
                  <Text className="text-foreground font-semibold">Created</Text>
                  <Text className="text-xs text-muted">
                    {new Date(item.createdAt).toLocaleDateString()}
                  </Text>
                </View>
                <View className="flex-row justify-between items-center">
                  <Text className="text-foreground font-semibold">Elements</Text>
                  <Text className="text-xs text-muted">{item.elements.length}</Text>
                </View>
                <View className="flex-row justify-between items-center">
                  <Text className="text-foreground font-semibold">Status</Text>
                  <Text
                    className={`text-xs font-bold ${
                      currentTheme.id === item.id ? 'text-primary' : 'text-muted'
                    }`}
                  >
                    {currentTheme.id === item.id ? 'Active' : 'Inactive'}
                  </Text>
                </View>
              </View>

              {/* Select button */}
              <TouchableOpacity
                onPress={() => onSelectTheme(item.id)}
                className={`mt-4 p-3 rounded-lg ${
                  currentTheme.id === item.id
                    ? 'bg-primary'
                    : 'bg-border'
                }`}
              >
                <Text
                  className={`text-center font-bold ${
                    currentTheme.id === item.id
                      ? 'text-background'
                      : 'text-foreground'
                  }`}
                >
                  {currentTheme.id === item.id ? 'Active' : 'Select'}
                </Text>
              </TouchableOpacity>
            </View>
          </TouchableOpacity>
        )}
      />
    </ScrollView>
  );
}

// Theme preview card component
export function ThemePreviewCard({ theme }: { theme: CustomTheme }) {
  return (
    <View className="rounded-lg overflow-hidden border border-border">
      {theme.backgroundImage ? (
        <ImageBackground
          source={{ uri: theme.backgroundImage }}
          className="h-32 justify-end p-3"
        >
          <View className="bg-black/60 p-2 rounded">
            <Text className="text-sm font-bold text-white">{theme.name}</Text>
          </View>
        </ImageBackground>
      ) : (
        <View
          className="h-32 justify-end p-3"
          style={{ backgroundColor: theme.colors.background }}
        >
          <View className="bg-black/60 p-2 rounded">
            <Text className="text-sm font-bold text-white">{theme.name}</Text>
          </View>
        </View>
      )}

      {/* Color swatches */}
      <View className="flex-row bg-surface">
        {['primary', 'secondary', 'accent'].map((colorKey) => (
          <View
            key={colorKey}
            className="flex-1 h-6"
            style={{
              backgroundColor: theme.colors[colorKey as keyof typeof theme.colors],
            }}
          />
        ))}
      </View>
    </View>
  );
}
