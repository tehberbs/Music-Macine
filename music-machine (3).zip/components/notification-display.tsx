import React from 'react';
import { View, StyleSheet } from 'react-native';
import { MechanicalNotification } from './mechanical-notification';
import { useNotification } from '@/lib/notification-context';

/**
 * Notification display container that renders all active notifications
 * Place this at the top level of your app (in _layout.tsx)
 */
export const NotificationDisplay: React.FC = () => {
  const { notifications, hide } = useNotification();

  return (
    <View style={styles.container} pointerEvents="box-none">
      {notifications.map((notification) => (
        <MechanicalNotification
          key={notification.id}
          type={notification.type}
          title={notification.title}
          message={notification.message}
          action={notification.action}
          onDismiss={() => hide(notification.id)}
        />
      ))}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    zIndex: 9999,
    paddingTop: 8,
  },
});
