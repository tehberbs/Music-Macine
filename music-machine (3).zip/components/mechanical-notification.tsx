import React, { useEffect } from 'react';
import { View, Text, Pressable, StyleSheet } from 'react-native';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withTiming,
  withSequence,
  Easing,
  FadeInDown,
  FadeOutUp,
} from 'react-native-reanimated';
import MaterialIcons from '@expo/vector-icons/MaterialIcons';
import { SteamPuffSystem } from './steam-puff';
import { NotificationType } from '@/lib/notification-context';

interface MechanicalNotificationProps {
  type: NotificationType;
  title: string;
  message: string;
  onDismiss?: () => void;
  action?: {
    label: string;
    onPress: () => void;
  };
}

const notificationConfig: Record<
  NotificationType,
  {
    icon: string;
    bgColor: string;
    borderColor: string;
    textColor: string;
    iconColor: string;
  }
> = {
  success: {
    icon: 'check-circle',
    bgColor: '#1a1a1a',
    borderColor: '#22C55E',
    textColor: '#22C55E',
    iconColor: '#22C55E',
  },
  error: {
    icon: 'error',
    bgColor: '#1a1a1a',
    borderColor: '#EF4444',
    textColor: '#EF4444',
    iconColor: '#EF4444',
  },
  info: {
    icon: 'info',
    bgColor: '#1a1a1a',
    borderColor: '#3B82F6',
    textColor: '#3B82F6',
    iconColor: '#3B82F6',
  },
  warning: {
    icon: 'warning',
    bgColor: '#1a1a1a',
    borderColor: '#F59E0B',
    textColor: '#F59E0B',
    iconColor: '#F59E0B',
  },
  download: {
    icon: 'download',
    bgColor: '#1a1a1a',
    borderColor: '#D4AF37',
    textColor: '#FFD700',
    iconColor: '#FFD700',
  },
  playback: {
    icon: 'play-circle-filled',
    bgColor: '#1a1a1a',
    borderColor: '#D4AF37',
    textColor: '#FFD700',
    iconColor: '#FFD700',
  },
};

export const MechanicalNotification: React.FC<MechanicalNotificationProps> = ({
  type,
  title,
  message,
  onDismiss,
  action,
}) => {
  const config = notificationConfig[type];
  const scale = useSharedValue(0.95);
  const opacity = useSharedValue(0);
  const showSteam = useSharedValue(type === 'download' || type === 'playback' ? 1 : 0);

  useEffect(() => {
    scale.value = withTiming(1, { duration: 300, easing: Easing.out(Easing.back(1.2)) });
    opacity.value = withTiming(1, { duration: 300 });
  }, []);

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [{ scale: scale.value }],
    opacity: opacity.value,
  }));

  const steamAnimatedStyle = useAnimatedStyle(() => ({
    opacity: showSteam.value,
  }));

  const handleDismiss = () => {
    scale.value = withTiming(0.95, { duration: 200 });
    opacity.value = withTiming(0, { duration: 200 });
    setTimeout(() => onDismiss?.(), 200);
  };

  return (
    <Animated.View
      entering={FadeInDown.springify()}
      exiting={FadeOutUp}
      style={[styles.container, animatedStyle]}
    >
      {/* Steam puff effect for download/playback */}
      {(type === 'download' || type === 'playback') && (
        <Animated.View style={[styles.steamContainer, steamAnimatedStyle]}>
          <SteamPuffSystem count={4} duration={1000} color={config.borderColor} size={30} />
        </Animated.View>
      )}

      {/* Main notification card */}
      <View
        style={[
          styles.card,
          {
            backgroundColor: config.bgColor,
            borderColor: config.borderColor,
          },
        ]}
      >
        {/* Mechanical border accent */}
        <View
          style={[
            styles.borderAccent,
            {
              backgroundColor: config.borderColor,
            },
          ]}
        />

        {/* Content */}
        <View style={styles.content}>
          {/* Icon */}
          <View
            style={[
              styles.iconContainer,
              {
                borderColor: config.borderColor,
              },
            ]}
          >
            <MaterialIcons name={config.icon as any} size={24} color={config.iconColor} />
          </View>

          {/* Text */}
          <View style={styles.textContainer}>
            <Text style={[styles.title, { color: config.textColor }]}>{title}</Text>
            <Text style={[styles.message, { color: config.textColor }]} numberOfLines={2}>
              {message}
            </Text>
          </View>

          {/* Close button */}
          <Pressable onPress={handleDismiss} style={styles.closeBtn}>
            <MaterialIcons name="close" size={20} color={config.textColor} />
          </Pressable>
        </View>

        {/* Action button if provided */}
        {action && (
          <Pressable
            onPress={() => {
              action.onPress();
              handleDismiss();
            }}
            style={[
              styles.actionBtn,
              {
                backgroundColor: config.borderColor,
              },
            ]}
          >
            <Text
              style={[
                styles.actionBtnText,
                {
                  color: type === 'download' || type === 'playback' ? '#000' : '#fff',
                },
              ]}
            >
              {action.label}
            </Text>
          </Pressable>
        )}

        {/* Mechanical rivets */}
        <View
          style={[
            styles.rivet,
            styles.rivetTL,
            {
              backgroundColor: config.borderColor,
            },
          ]}
        />
        <View
          style={[
            styles.rivet,
            styles.rivetTR,
            {
              backgroundColor: config.borderColor,
            },
          ]}
        />
        <View
          style={[
            styles.rivet,
            styles.rivetBL,
            {
              backgroundColor: config.borderColor,
            },
          ]}
        />
        <View
          style={[
            styles.rivet,
            styles.rivetBR,
            {
              backgroundColor: config.borderColor,
            },
          ]}
        />
      </View>
    </Animated.View>
  );
};

const styles = StyleSheet.create({
  container: {
    marginHorizontal: 16,
    marginVertical: 8,
    position: 'relative',
  },
  steamContainer: {
    position: 'absolute',
    top: -40,
    left: 20,
    zIndex: 10,
  },
  card: {
    borderWidth: 2,
    borderRadius: 12,
    padding: 12,
    overflow: 'hidden',
  },
  borderAccent: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: 3,
  },
  content: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  iconContainer: {
    width: 40,
    height: 40,
    borderRadius: 8,
    borderWidth: 2,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.3)',
  },
  textContainer: {
    flex: 1,
  },
  title: {
    fontSize: 14,
    fontWeight: 'bold',
    marginBottom: 2,
  },
  message: {
    fontSize: 12,
    opacity: 0.8,
  },
  closeBtn: {
    padding: 4,
  },
  actionBtn: {
    marginTop: 10,
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderRadius: 6,
    alignItems: 'center',
  },
  actionBtnText: {
    fontSize: 12,
    fontWeight: '600',
  },
  rivet: {
    position: 'absolute',
    width: 6,
    height: 6,
    borderRadius: 3,
  },
  rivetTL: {
    top: 8,
    left: 8,
  },
  rivetTR: {
    top: 8,
    right: 8,
  },
  rivetBL: {
    bottom: 8,
    left: 8,
  },
  rivetBR: {
    bottom: 8,
    right: 8,
  },
});
