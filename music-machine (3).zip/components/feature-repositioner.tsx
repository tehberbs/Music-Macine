import React, { useState } from 'react';
import { View, Text, TouchableOpacity, ScrollView, Switch } from 'react-native';
import { AppFeature } from '@/lib/advanced-theme-context';

interface FeatureRepositionerProps {
  features: AppFeature[];
  onUpdateFeature: (feature: AppFeature) => void;
}

export function FeatureRepositioner({
  features,
  onUpdateFeature,
}: FeatureRepositionerProps) {
  const [expandedFeature, setExpandedFeature] = useState<string | null>(null);

  const handlePositionChange = (featureId: string, direction: 'up' | 'down' | 'left' | 'right') => {
    const feature = features.find((f) => f.id === featureId);
    if (feature) {
      const step = 0.05; // 5% movement
      let newX = feature.position.x;
      let newY = feature.position.y;

      switch (direction) {
        case 'up':
          newY = Math.max(0, newY - step);
          break;
        case 'down':
          newY = Math.min(1, newY + step);
          break;
        case 'left':
          newX = Math.max(0, newX - step);
          break;
        case 'right':
          newX = Math.min(1, newX + step);
          break;
      }

      onUpdateFeature({
        ...feature,
        position: { x: newX, y: newY },
      });
    }
  };

  const handleToggleVisibility = (featureId: string) => {
    const feature = features.find((f) => f.id === featureId);
    if (feature) {
      onUpdateFeature({
        ...feature,
        visible: !feature.visible,
      });
    }
  };

  return (
    <ScrollView className="flex-1 bg-background rounded-lg border-2 border-border p-4">
      <Text className="text-xl font-bold text-foreground mb-4">App Features</Text>

      {features.map((feature) => (
        <View key={feature.id} className="mb-4 bg-surface rounded-lg border border-border overflow-hidden">
          {/* Header */}
          <TouchableOpacity
            onPress={() => setExpandedFeature(expandedFeature === feature.id ? null : feature.id)}
            className="p-4 flex-row items-center justify-between"
          >
            <View className="flex-1">
              <Text className="text-lg font-bold text-foreground">{feature.name}</Text>
              <Text className="text-xs text-muted mt-1">
                Position: {Math.round(feature.position.x * 100)}%, {Math.round(feature.position.y * 100)}%
              </Text>
            </View>
            <Text className="text-primary text-lg">{expandedFeature === feature.id ? '−' : '+'}</Text>
          </TouchableOpacity>

          {/* Expanded content */}
          {expandedFeature === feature.id && (
            <View className="bg-background p-4 border-t border-border gap-4">
              {/* Visibility toggle */}
              <View className="flex-row items-center justify-between">
                <Text className="text-foreground font-semibold">Visible</Text>
                <Switch
                  value={feature.visible}
                  onValueChange={() => handleToggleVisibility(feature.id)}
                  trackColor={{ false: '#4B5563', true: '#A78BFA' }}
                  thumbColor={feature.visible ? '#A78BFA' : '#9CA3AF'}
                />
              </View>

              {/* Position controls */}
              <View>
                <Text className="text-foreground font-semibold mb-2">Position</Text>
                
                {/* Up button */}
                <View className="items-center mb-2">
                  <TouchableOpacity
                    onPress={() => handlePositionChange(feature.id, 'up')}
                    className="bg-primary p-2 rounded-full w-10 h-10 items-center justify-center"
                  >
                    <Text className="text-background text-lg font-bold">↑</Text>
                  </TouchableOpacity>
                </View>

                {/* Left, Center, Right buttons */}
                <View className="flex-row justify-between items-center mb-2">
                  <TouchableOpacity
                    onPress={() => handlePositionChange(feature.id, 'left')}
                    className="bg-primary p-2 rounded-full w-10 h-10 items-center justify-center"
                  >
                    <Text className="text-background text-lg font-bold">←</Text>
                  </TouchableOpacity>

                  <View className="bg-border p-3 rounded flex-1 mx-2">
                    <Text className="text-foreground text-center text-sm font-semibold">
                      {Math.round(feature.position.x * 100)}%, {Math.round(feature.position.y * 100)}%
                    </Text>
                  </View>

                  <TouchableOpacity
                    onPress={() => handlePositionChange(feature.id, 'right')}
                    className="bg-primary p-2 rounded-full w-10 h-10 items-center justify-center"
                  >
                    <Text className="text-background text-lg font-bold">→</Text>
                  </TouchableOpacity>
                </View>

                {/* Down button */}
                <View className="items-center">
                  <TouchableOpacity
                    onPress={() => handlePositionChange(feature.id, 'down')}
                    className="bg-primary p-2 rounded-full w-10 h-10 items-center justify-center"
                  >
                    <Text className="text-background text-lg font-bold">↓</Text>
                  </TouchableOpacity>
                </View>
              </View>

              {/* Customization info */}
              {feature.customizable && (
                <View className="bg-primary/10 border border-primary p-3 rounded">
                  <Text className="text-primary text-xs font-semibold">
                    ✓ This feature can be customized
                  </Text>
                </View>
              )}
            </View>
          )}
        </View>
      ))}
    </ScrollView>
  );
}
