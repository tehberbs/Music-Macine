import React, { useEffect } from 'react';
import { View } from 'react-native';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withTiming,
  Easing,
  withSequence,
  withRepeat,
} from 'react-native-reanimated';

interface AnimatedEqualizerProps {
  isPlaying?: boolean;
  barCount?: number;
  barWidth?: number;
  barSpacing?: number;
  height?: number;
  color?: string;
  animationSpeed?: number;
}

/**
 * Animated equalizer visualization component
 * Displays colorful animated bars that respond to playback state
 * Inspired by the cogwheel animator reference design
 */
export function AnimatedEqualizer({
  isPlaying = false,
  barCount = 32,
  barWidth = 6,
  barSpacing = 2,
  height = 80,
  color = '#FFD700',
  animationSpeed = 300,
}: AnimatedEqualizerProps) {
  const bars = Array.from({ length: barCount }, (_, i) => i);

  return (
    <View
      style={{
        flexDirection: 'row',
        alignItems: 'flex-end',
        justifyContent: 'center',
        gap: barSpacing,
        height: height,
        paddingHorizontal: 8,
      }}
    >
      {bars.map((_, index) => (
        <AnimatedBar
          key={`bar-${index}`}
          isPlaying={isPlaying}
          maxHeight={height}
          index={index}
          totalBars={barCount}
          animationSpeed={animationSpeed}
          color={color}
          width={barWidth}
        />
      ))}
    </View>
  );
}

interface AnimatedBarProps {
  isPlaying: boolean;
  maxHeight: number;
  index: number;
  totalBars: number;
  animationSpeed: number;
  color: string;
  width: number;
}

function AnimatedBar({
  isPlaying,
  maxHeight,
  index,
  totalBars,
  animationSpeed,
  color,
  width,
}: AnimatedBarProps) {
  const heightValue = useSharedValue(10);

  // Create a wave effect across the bars
  const getColorForIndex = (idx: number) => {
    const hue = (idx / totalBars) * 360;
    return `hsl(${hue}, 100%, 50%)`;
  };

  useEffect(() => {
    if (isPlaying) {
      // Random height animation for each bar with staggered timing
      const randomHeight = Math.random() * (maxHeight * 0.8) + maxHeight * 0.2;
      const delay = (index % 4) * 50;

      // Use setTimeout to create staggered animation
      const timer = setTimeout(() => {
        heightValue.value = withRepeat(
          withSequence(
            withTiming(randomHeight, {
              duration: animationSpeed,
              easing: Easing.out(Easing.cubic),
            }),
            withTiming(10, {
              duration: animationSpeed,
              easing: Easing.in(Easing.cubic),
            })
          ),
          -1,
          true
        );
      }, delay);

      return () => clearTimeout(timer);
    } else {
      // Collapse bars when not playing
      heightValue.value = withTiming(10, {
        duration: 200,
        easing: Easing.in(Easing.cubic),
      });
    }
  }, [isPlaying, index, maxHeight, animationSpeed, heightValue]);

  const animatedStyle = useAnimatedStyle(() => ({
    height: heightValue.value,
  }));

  return (
    <Animated.View
      style={[
        {
          width: width,
          backgroundColor: getColorForIndex(index),
          borderRadius: 2,
          shadowColor: getColorForIndex(index),
          shadowOffset: { width: 0, height: 0 },
          shadowOpacity: 0.6,
          shadowRadius: 4,
          elevation: 4,
        },
        animatedStyle,
      ]}
    />
  );
}

/**
 * Vertical equalizer bars component (alternative layout)
 */
interface VerticalEqualizerProps {
  isPlaying?: boolean;
  barCount?: number;
  barHeight?: number;
  barSpacing?: number;
  width?: number;
  animationSpeed?: number;
}

export function VerticalEqualizer({
  isPlaying = false,
  barCount = 16,
  barHeight = 6,
  barSpacing = 2,
  width = 120,
  animationSpeed = 300,
}: VerticalEqualizerProps) {
  const bars = Array.from({ length: barCount }, (_, i) => i);

  return (
    <View
      style={{
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        gap: barSpacing,
        width: width,
        paddingVertical: 8,
      }}
    >
      {bars.map((_, index) => (
        <VerticalBar
          key={`vbar-${index}`}
          isPlaying={isPlaying}
          maxWidth={width}
          index={index}
          totalBars={barCount}
          animationSpeed={animationSpeed}
          height={barHeight}
        />
      ))}
    </View>
  );
}

interface VerticalBarProps {
  isPlaying: boolean;
  maxWidth: number;
  index: number;
  totalBars: number;
  animationSpeed: number;
  height: number;
}

function VerticalBar({
  isPlaying,
  maxWidth,
  index,
  totalBars,
  animationSpeed,
  height,
}: VerticalBarProps) {
  const widthValue = useSharedValue(10);

  const getColorForIndex = (idx: number) => {
    const hue = (idx / totalBars) * 360;
    return `hsl(${hue}, 100%, 50%)`;
  };

  useEffect(() => {
    if (isPlaying) {
      const randomWidth = Math.random() * (maxWidth * 0.7) + maxWidth * 0.3;
      const delay = (index % 3) * 60;

      const timer = setTimeout(() => {
        widthValue.value = withRepeat(
          withSequence(
            withTiming(randomWidth, {
              duration: animationSpeed,
              easing: Easing.out(Easing.cubic),
            }),
            withTiming(10, {
              duration: animationSpeed,
              easing: Easing.in(Easing.cubic),
            })
          ),
          -1,
          true
        );
      }, delay);

      return () => clearTimeout(timer);
    } else {
      widthValue.value = withTiming(10, {
        duration: 200,
        easing: Easing.in(Easing.cubic),
      });
    }
  }, [isPlaying, index, maxWidth, animationSpeed, widthValue]);

  const animatedStyle = useAnimatedStyle(() => ({
    width: widthValue.value,
  }));

  return (
    <Animated.View
      style={[
        {
          height: height,
          backgroundColor: getColorForIndex(index),
          borderRadius: 2,
          shadowColor: getColorForIndex(index),
          shadowOffset: { width: 0, height: 0 },
          shadowOpacity: 0.6,
          shadowRadius: 4,
          elevation: 4,
        },
        animatedStyle,
      ]}
    />
  );
}
