import React, { useEffect } from 'react';
import { View, Pressable, Text } from 'react-native';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withTiming,
  Easing,
  withSequence,
} from 'react-native-reanimated';
import { useMusicPlayer } from '@/lib/music-player-context-v2';
import MaterialIcons from '@expo/vector-icons/MaterialIcons';

interface CentralGearProps {
  isPlaying: boolean;
  onPress?: () => void;
  size?: number;
}

/**
 * Central interactive gear component
 * Displays the main playback control with animated rotation
 * Inspired by the cogwheel animator reference design
 */
export function CentralGear({ isPlaying, onPress, size = 120 }: CentralGearProps) {
  const rotation = useSharedValue(0);
  const scale = useSharedValue(1);

  // Continuous rotation when playing
  useEffect(() => {
    if (isPlaying) {
      rotation.value = withTiming(rotation.value + 360, {
        duration: 4000,
        easing: Easing.linear,
      });
    }
  }, [isPlaying, rotation]);

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [
      { rotate: `${rotation.value}deg` },
      { scale: scale.value },
    ],
  }));

  const handlePress = () => {
    // Pulse animation on press
    scale.value = withSequence(
      withTiming(0.9, { duration: 100, easing: Easing.out(Easing.cubic) }),
      withTiming(1, { duration: 100, easing: Easing.in(Easing.cubic) })
    );
    onPress?.();
  };

  return (
    <View
      style={{
        width: size,
        height: size,
        justifyContent: 'center',
        alignItems: 'center',
      }}
    >
      <Animated.View style={animatedStyle}>
        <Pressable
          onPress={handlePress}
          style={{
            width: size,
            height: size,
            borderRadius: size / 2,
            backgroundColor: '#D4AF37',
            justifyContent: 'center',
            alignItems: 'center',
            borderWidth: 3,
            borderColor: '#FFD700',
            shadowColor: '#FFD700',
            shadowOffset: { width: 0, height: 0 },
            shadowOpacity: 0.6,
            shadowRadius: 12,
            elevation: 12,
          }}
        >
          {/* Gear teeth pattern */}
          <View
            style={{
              position: 'absolute',
              width: '100%',
              height: '100%',
              borderRadius: size / 2,
              borderWidth: 2,
              borderColor: '#8B7355',
              opacity: 0.5,
            }}
          />

          {/* Center circle */}
          <View
            style={{
              width: size * 0.3,
              height: size * 0.3,
              borderRadius: (size * 0.3) / 2,
              backgroundColor: '#1a1a1a',
              borderWidth: 2,
              borderColor: '#FFD700',
              justifyContent: 'center',
              alignItems: 'center',
            }}
          >
            {/* Play/Pause icon */}
            <MaterialIcons
              name={isPlaying ? 'pause' : 'play-arrow'}
              size={size * 0.15}
              color="#FFD700"
            />
          </View>

          {/* Decorative rivets */}
          {[0, 90, 180, 270].map((angle) => {
            const radians = (angle * Math.PI) / 180;
            const x = Math.cos(radians) * (size * 0.35);
            const y = Math.sin(radians) * (size * 0.35);

            return (
              <View
                key={angle}
                style={{
                  position: 'absolute',
                  width: 6,
                  height: 6,
                  borderRadius: 3,
                  backgroundColor: '#8B7355',
                  left: size / 2 + x - 3,
                  top: size / 2 + y - 3,
                }}
              />
            );
          })}
        </Pressable>
      </Animated.View>
    </View>
  );
}

/**
 * Surrounding gear component - smaller gears positioned around central gear
 */
interface SurroundingGearProps {
  angle: number; // degrees from center
  distance: number; // distance from center
  size?: number;
  isPlaying?: boolean;
  rotationSpeed?: number; // ms per full rotation
}

export function SurroundingGear({
  angle,
  distance,
  size = 50,
  isPlaying = false,
  rotationSpeed = 6000,
}: SurroundingGearProps) {
  const rotation = useSharedValue(0);

  // Continuous rotation when playing (opposite direction of central gear)
  useEffect(() => {
    if (isPlaying) {
      rotation.value = withTiming(rotation.value - 360, {
        duration: rotationSpeed,
        easing: Easing.linear,
      });
    }
  }, [isPlaying, rotation, rotationSpeed]);

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [{ rotate: `${rotation.value}deg` }],
  }));

  // Calculate position
  const radians = (angle * Math.PI) / 180;
  const x = Math.cos(radians) * distance;
  const y = Math.sin(radians) * distance;

  return (
    <Animated.View
      style={[
        {
          position: 'absolute',
          width: size,
          height: size,
          left: x - size / 2,
          top: y - size / 2,
        },
        animatedStyle,
      ]}
    >
      <View
        style={{
          width: size,
          height: size,
          borderRadius: size / 2,
          backgroundColor: '#D4AF37',
          borderWidth: 2,
          borderColor: '#FFD700',
          justifyContent: 'center',
          alignItems: 'center',
          shadowColor: '#FFD700',
          shadowOffset: { width: 0, height: 0 },
          shadowOpacity: 0.4,
          shadowRadius: 8,
          elevation: 8,
        }}
      >
        {/* Gear pattern */}
        <View
          style={{
            position: 'absolute',
            width: '100%',
            height: '100%',
            borderRadius: size / 2,
            borderWidth: 1,
            borderColor: '#8B7355',
            opacity: 0.4,
          }}
        />

        {/* Center dot */}
        <View
          style={{
            width: size * 0.25,
            height: size * 0.25,
            borderRadius: (size * 0.25) / 2,
            backgroundColor: '#1a1a1a',
            borderWidth: 1,
            borderColor: '#FFD700',
          }}
        />
      </View>
    </Animated.View>
  );
}
