import React, { useEffect } from 'react';
import { View, Dimensions } from 'react-native';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withRepeat,
  withTiming,
  Easing,
} from 'react-native-reanimated';
import Svg, { G, Circle, Path, Line, Rect, Polygon } from 'react-native-svg';

const { width, height } = Dimensions.get('window');

interface GearConfig {
  id: string;
  x: number;
  y: number;
  radius: number;
  teeth: number;
  speed: number;
  direction: 1 | -1;
  color: string;
  strokeWidth: number;
}

const createGearPath = (
  cx: number,
  cy: number,
  innerRadius: number,
  outerRadius: number,
  teeth: number,
  rotation: number
): string => {
  const points: string[] = [];
  const angleStep = (Math.PI * 2) / (teeth * 2);

  for (let i = 0; i < teeth * 2; i++) {
    const angle = i * angleStep + rotation;
    const radius = i % 2 === 0 ? outerRadius : innerRadius;
    const x = cx + radius * Math.cos(angle);
    const y = cy + radius * Math.sin(angle);
    points.push(`${i === 0 ? 'M' : 'L'} ${x} ${y}`);
  }

  points.push('Z');
  return points.join(' ');
};

const GearComponent: React.FC<{
  config: GearConfig;
  rotation: any;
}> = ({ config, rotation }) => {
  const animatedStyle = useAnimatedStyle(() => {
    return {
      transform: [
        { translateX: config.x },
        { translateY: config.y },
        { rotateZ: rotation.value * config.direction },
      ],
    } as any;
  });

  const innerRadius = config.radius * 0.6;
  const outerRadius = config.radius;
  const toothHeight = config.radius * 0.15;

  return (
    <Animated.View style={[{ position: 'absolute' }, animatedStyle] as any}>
      <Svg width={config.radius * 2.5} height={config.radius * 2.5} viewBox={`${-config.radius * 1.25} ${-config.radius * 1.25} ${config.radius * 2.5} ${config.radius * 2.5}`}>
        {/* Outer gear teeth */}
        <G>
          {Array.from({ length: config.teeth }).map((_, i) => {
            const angle = (i / config.teeth) * Math.PI * 2;
            const nextAngle = ((i + 1) / config.teeth) * Math.PI * 2;

            const x1 = (outerRadius - toothHeight) * Math.cos(angle);
            const y1 = (outerRadius - toothHeight) * Math.sin(angle);
            const x2 = outerRadius * Math.cos(angle + (Math.PI * 2) / (config.teeth * 4));
            const y2 = outerRadius * Math.sin(angle + (Math.PI * 2) / (config.teeth * 4));
            const x3 = outerRadius * Math.cos(nextAngle - (Math.PI * 2) / (config.teeth * 4));
            const y3 = outerRadius * Math.sin(nextAngle - (Math.PI * 2) / (config.teeth * 4));
            const x4 = (outerRadius - toothHeight) * Math.cos(nextAngle);
            const y4 = (outerRadius - toothHeight) * Math.sin(nextAngle);

            return (
              <Polygon
                key={`tooth-${i}`}
                points={`${x1},${y1} ${x2},${y2} ${x3},${y3} ${x4},${y4}`}
                fill={config.color}
                stroke="#333"
                strokeWidth={config.strokeWidth}
              />
            );
          })}
        </G>

        {/* Center hub */}
        <Circle cx={0} cy={0} r={innerRadius * 0.4} fill={config.color} stroke="#333" strokeWidth={config.strokeWidth} />

        {/* Decorative rings */}
        <Circle cx={0} cy={0} r={innerRadius} fill="none" stroke={config.color} strokeWidth={config.strokeWidth * 0.8} />
        <Circle cx={0} cy={0} r={innerRadius * 0.7} fill="none" stroke={config.color} strokeWidth={config.strokeWidth * 0.5} />

        {/* Spokes */}
        {Array.from({ length: 4 }).map((_, i) => {
          const angle = (i / 4) * Math.PI * 2;
          const x = (innerRadius * 0.8) * Math.cos(angle);
          const y = (innerRadius * 0.8) * Math.sin(angle);
          return (
            <Line
              key={`spoke-${i}`}
              x1={0}
              y1={0}
              x2={x}
              y2={y}
              stroke={config.color}
              strokeWidth={config.strokeWidth * 1.5}
            />
          );
        })}
      </Svg>
    </Animated.View>
  );
};

export const SteampunkBackgroundV2: React.FC = () => {
  const rotation = useSharedValue(0);

  useEffect(() => {
    rotation.value = withRepeat(
      withTiming(360, {
        duration: 20000,
        easing: Easing.linear,
      }),
      -1,
      false
    );
  }, []);

  const gears: GearConfig[] = [
    // Large central gears
    { id: 'gear-1', x: width * 0.3, y: height * 0.3, radius: 60, teeth: 12, speed: 1, direction: 1, color: '#C0A080', strokeWidth: 2 },
    { id: 'gear-2', x: width * 0.65, y: height * 0.35, radius: 50, teeth: 10, speed: 1.2, direction: -1, color: '#8B7355', strokeWidth: 2 },
    { id: 'gear-3', x: width * 0.5, y: height * 0.65, radius: 55, teeth: 11, speed: 1.1, direction: 1, color: '#A0826D', strokeWidth: 2 },

    // Medium gears
    { id: 'gear-4', x: width * 0.15, y: height * 0.5, radius: 35, teeth: 8, speed: 1.5, direction: -1, color: '#D4AF37', strokeWidth: 1.5 },
    { id: 'gear-5', x: width * 0.85, y: height * 0.55, radius: 40, teeth: 9, speed: 1.3, direction: 1, color: '#B8860B', strokeWidth: 1.5 },
    { id: 'gear-6', x: width * 0.4, y: height * 0.15, radius: 38, teeth: 9, speed: 1.4, direction: -1, color: '#CD853F', strokeWidth: 1.5 },
    { id: 'gear-7', x: width * 0.7, y: height * 0.75, radius: 42, teeth: 10, speed: 1.2, direction: 1, color: '#DEB887', strokeWidth: 1.5 },

    // Small gears - repositioned to avoid overlaps in top left
    { id: 'gear-8', x: width * 0.12, y: height * 0.25, radius: 20, teeth: 6, speed: 2, direction: 1, color: '#FFD700', strokeWidth: 1 },
    { id: 'gear-9', x: width * 0.9, y: height * 0.2, radius: 22, teeth: 6, speed: 1.9, direction: -1, color: '#FFA500', strokeWidth: 1 },
    { id: 'gear-10', x: width * 0.25, y: height * 0.85, radius: 18, teeth: 5, speed: 2.1, direction: 1, color: '#FF8C00', strokeWidth: 1 },
    { id: 'gear-11', x: width * 0.75, y: height * 0.9, radius: 21, teeth: 6, speed: 1.95, direction: -1, color: '#FFB347', strokeWidth: 1 },

    // Additional decorative gears - repositioned to avoid overlaps
    { id: 'gear-12', x: width * 0.05, y: height * 0.7, radius: 25, teeth: 7, speed: 1.8, direction: -1, color: '#C0A080', strokeWidth: 1.2 },
    { id: 'gear-13', x: width * 0.95, y: height * 0.4, radius: 28, teeth: 8, speed: 1.7, direction: 1, color: '#8B7355', strokeWidth: 1.2 },
    { id: 'gear-14', x: width * 0.5, y: height * 0.04, radius: 30, teeth: 8, speed: 1.6, direction: -1, color: '#A0826D', strokeWidth: 1.2 },
    { id: 'gear-15', x: width * 0.5, y: height * 0.95, radius: 32, teeth: 9, speed: 1.5, direction: 1, color: '#D4AF37', strokeWidth: 1.2 },

    // Corner gears - repositioned to avoid overlaps
    { id: 'gear-16', x: width * 0.06, y: height * 0.06, radius: 24, teeth: 7, speed: 1.85, direction: 1, color: '#B8860B', strokeWidth: 1 },
    { id: 'gear-17', x: width * 0.92, y: height * 0.92, radius: 26, teeth: 7, speed: 1.75, direction: -1, color: '#CD853F', strokeWidth: 1 },
    { id: 'gear-18', x: width * 0.08, y: height * 0.92, radius: 23, teeth: 6, speed: 1.9, direction: -1, color: '#DEB887', strokeWidth: 1 },
    { id: 'gear-19', x: width * 0.92, y: height * 0.08, radius: 25, teeth: 7, speed: 1.8, direction: 1, color: '#FFD700', strokeWidth: 1 },

    // Additional interlocking gears - repositioned to avoid overlaps
    { id: 'gear-20', x: width * 0.35, y: height * 0.45, radius: 28, teeth: 8, speed: 1.6, direction: 1, color: '#FFA500', strokeWidth: 1.2 },
    { id: 'gear-21', x: width * 0.65, y: height * 0.55, radius: 26, teeth: 7, speed: 1.7, direction: -1, color: '#FF8C00', strokeWidth: 1.2 },
    { id: 'gear-22', x: width * 0.22, y: height * 0.38, radius: 22, teeth: 6, speed: 1.95, direction: -1, color: '#FFB347', strokeWidth: 1 },
    { id: 'gear-23', x: width * 0.8, y: height * 0.7, radius: 24, teeth: 7, speed: 1.85, direction: 1, color: '#C0A080', strokeWidth: 1 },

    // More gears for density - repositioned to avoid overlaps
    { id: 'gear-24', x: width * 0.45, y: height * 0.5, radius: 19, teeth: 6, speed: 2.05, direction: 1, color: '#8B7355', strokeWidth: 0.8 },
    { id: 'gear-25', x: width * 0.55, y: height * 0.5, radius: 20, teeth: 6, speed: 2, direction: -1, color: '#A0826D', strokeWidth: 0.8 },
    { id: 'gear-26', x: width * 0.32, y: height * 0.7, radius: 21, teeth: 6, speed: 1.98, direction: 1, color: '#D4AF37', strokeWidth: 0.8 },
    { id: 'gear-27', x: width * 0.68, y: height * 0.32, radius: 23, teeth: 7, speed: 1.92, direction: -1, color: '#B8860B', strokeWidth: 0.8 },

    // Final gears to reach 35+ - repositioned to avoid overlaps
    { id: 'gear-28', x: width * 0.12, y: height * 0.12, radius: 18, teeth: 5, speed: 2.1, direction: -1, color: '#CD853F', strokeWidth: 0.8 },
    { id: 'gear-29', x: width * 0.85, y: height * 0.85, radius: 20, teeth: 6, speed: 2.05, direction: 1, color: '#DEB887', strokeWidth: 0.8 },
    { id: 'gear-30', x: width * 0.25, y: height * 0.6, radius: 17, teeth: 5, speed: 2.15, direction: 1, color: '#FFD700', strokeWidth: 0.8 },
    { id: 'gear-31', x: width * 0.75, y: height * 0.4, radius: 19, teeth: 6, speed: 2.08, direction: -1, color: '#FFA500', strokeWidth: 0.8 },
    { id: 'gear-32', x: width * 0.42, y: height * 0.22, radius: 16, teeth: 5, speed: 2.2, direction: -1, color: '#FF8C00', strokeWidth: 0.8 },
    { id: 'gear-33', x: width * 0.6, y: height * 0.8, radius: 18, teeth: 5, speed: 2.12, direction: 1, color: '#FFB347', strokeWidth: 0.8 },
    { id: 'gear-34', x: width * 0.35, y: height * 0.75, radius: 17, teeth: 5, speed: 2.18, direction: 1, color: '#C0A080', strokeWidth: 0.8 },
    { id: 'gear-35', x: width * 0.62, y: height * 0.18, radius: 19, teeth: 6, speed: 2.1, direction: -1, color: '#8B7355', strokeWidth: 0.8 },
  ];

  return (
    <View style={{ position: 'absolute', width, height, backgroundColor: '#1a1a1a', overflow: 'hidden' }}>
      {/* Metal background texture */}
      <Svg width={width} height={height} style={{ position: 'absolute' }}>
        <Rect width={width} height={height} fill="#0d0d0d" />
        <Rect width={width} height={height} fill="url(#metalGradient)" opacity={0.3} />
      </Svg>

      {/* Render all gears */}
      {gears.map((gear) => (
        <GearComponent key={gear.id} config={gear} rotation={rotation} />
      ))}

      {/* Overlay gradient for depth */}
      <View
        style={{
          position: 'absolute',
          width,
          height,
          backgroundColor: 'rgba(0, 0, 0, 0.2)',
          pointerEvents: 'none',
        }}
      />
    </View>
  );
};
