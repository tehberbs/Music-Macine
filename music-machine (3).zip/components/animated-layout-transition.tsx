import React, { useEffect } from 'react';
import { View, ViewProps } from 'react-native';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withTiming,
  interpolate,
  Extrapolate,
} from 'react-native-reanimated';

interface AnimatedLayoutTransitionProps extends ViewProps {
  fromX?: number;
  toX?: number;
  fromY?: number;
  toY?: number;
  fromScale?: number;
  toScale?: number;
  fromOpacity?: number;
  toOpacity?: number;
  fromRotation?: number;
  toRotation?: number;
  duration?: number;
  animate?: boolean;
  delay?: number;
}

/**
 * Component that animates layout changes (position, scale, opacity, rotation)
 */
export const AnimatedLayoutTransition = React.forwardRef<View, AnimatedLayoutTransitionProps>(
  (
    {
      fromX = 0,
      toX = 0,
      fromY = 0,
      toY = 0,
      fromScale = 1,
      toScale = 1,
      fromOpacity = 1,
      toOpacity = 1,
      fromRotation = 0,
      toRotation = 0,
      duration = 600,
      animate = true,
      delay = 0,
      style,
      children,
      ...props
    },
    ref
  ) => {
    const progress = useSharedValue(0);

    useEffect(() => {
      if (animate) {
        progress.value = withTiming(1, { duration });
      }
    }, [animate, duration, toX, toY, toScale, toOpacity, toRotation]);

    const animatedStyle = useAnimatedStyle(() => {
      const translateX = interpolate(
        progress.value,
        [0, 1],
        [fromX, toX],
        Extrapolate.CLAMP
      );

      const translateY = interpolate(
        progress.value,
        [0, 1],
        [fromY, toY],
        Extrapolate.CLAMP
      );

      const scale = interpolate(
        progress.value,
        [0, 1],
        [fromScale, toScale],
        Extrapolate.CLAMP
      );

      const opacity = interpolate(
        progress.value,
        [0, 1],
        [fromOpacity, toOpacity],
        Extrapolate.CLAMP
      );

      const rotation = interpolate(
        progress.value,
        [0, 1],
        [fromRotation, toRotation],
        Extrapolate.CLAMP
      );

      return {
        transform: [
          { translateX },
          { translateY },
          { scale },
          { rotate: `${rotation}deg` },
        ],
        opacity,
      };
    });

    return (
      <Animated.View
        ref={ref}
        style={[animatedStyle, style as any]}
        {...(props as any)}
      >
        {children}
      </Animated.View>
    );
  }
);

AnimatedLayoutTransition.displayName = 'AnimatedLayoutTransition';

interface AnimatedPaddingTransitionProps extends ViewProps {
  fromPadding?: number;
  toPadding?: number;
  fromPaddingHorizontal?: number;
  toPaddingHorizontal?: number;
  fromPaddingVertical?: number;
  toPaddingVertical?: number;
  duration?: number;
  animate?: boolean;
}

/**
 * Component that animates padding transitions
 */
export const AnimatedPaddingTransition = React.forwardRef<View, AnimatedPaddingTransitionProps>(
  (
    {
      fromPadding = 0,
      toPadding = 0,
      fromPaddingHorizontal = 0,
      toPaddingHorizontal = 0,
      fromPaddingVertical = 0,
      toPaddingVertical = 0,
      duration = 600,
      animate = true,
      style,
      children,
      ...props
    },
    ref
  ) => {
    const progress = useSharedValue(0);

    useEffect(() => {
      if (animate) {
        progress.value = withTiming(1, { duration });
      }
    }, [animate, duration, toPadding, toPaddingHorizontal, toPaddingVertical]);

    const animatedStyle = useAnimatedStyle(() => {
      const padding = interpolate(
        progress.value,
        [0, 1],
        [fromPadding, toPadding],
        Extrapolate.CLAMP
      );

      const paddingHorizontal = interpolate(
        progress.value,
        [0, 1],
        [fromPaddingHorizontal, toPaddingHorizontal],
        Extrapolate.CLAMP
      );

      const paddingVertical = interpolate(
        progress.value,
        [0, 1],
        [fromPaddingVertical, toPaddingVertical],
        Extrapolate.CLAMP
      );

      return {
        padding,
        paddingHorizontal,
        paddingVertical,
      };
    });

    return (
      <Animated.View
        ref={ref}
        style={[animatedStyle, style as any]}
        {...(props as any)}
      >
        {children}
      </Animated.View>
    );
  }
);

AnimatedPaddingTransition.displayName = 'AnimatedPaddingTransition';

interface AnimatedSizeTransitionProps extends ViewProps {
  fromWidth?: number | string;
  toWidth?: number | string;
  fromHeight?: number | string;
  toHeight?: number | string;
  duration?: number;
  animate?: boolean;
}

/**
 * Component that animates size transitions
 */
export const AnimatedSizeTransition = React.forwardRef<View, AnimatedSizeTransitionProps>(
  (
    {
      fromWidth = '100%',
      toWidth = '100%',
      fromHeight = 'auto',
      toHeight = 'auto',
      duration = 600,
      animate = true,
      style,
      children,
      ...props
    },
    ref
  ) => {
    const progress = useSharedValue(0);

    useEffect(() => {
      if (animate) {
        progress.value = withTiming(1, { duration });
      }
    }, [animate, duration, toWidth, toHeight]);

    // For numeric sizes, animate them
    const isFromWidthNumeric = typeof fromWidth === 'number';
    const isToWidthNumeric = typeof toWidth === 'number';
    const isFromHeightNumeric = typeof fromHeight === 'number';
    const isToHeightNumeric = typeof toHeight === 'number';

    const animatedStyle = useAnimatedStyle(() => {
      const width = isFromWidthNumeric && isToWidthNumeric
        ? interpolate(
            progress.value,
            [0, 1],
            [fromWidth as number, toWidth as number],
            Extrapolate.CLAMP
          )
        : fromWidth;

      const height = isFromHeightNumeric && isToHeightNumeric
        ? interpolate(
            progress.value,
            [0, 1],
            [fromHeight as number, toHeight as number],
            Extrapolate.CLAMP
          )
        : fromHeight;

      return {
        width: width as any,
        height: height as any,
      };
    });

    return (
      <Animated.View
        ref={ref}
        style={[animatedStyle, style as any]}
        {...(props as any)}
      >
        {children}
      </Animated.View>
    );
  }
);

AnimatedSizeTransition.displayName = 'AnimatedSizeTransition';
