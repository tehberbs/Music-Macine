import React, { useState } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  TextInput,
  Modal,
  Dimensions,
  Image,
} from 'react-native';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
} from 'react-native-reanimated';
import {
  Gesture,
  GestureDetector,
} from 'react-native-gesture-handler';
import MaterialIcons from '@expo/vector-icons/MaterialIcons';
import { UIElement } from '@/lib/theme-customization-context';
import { ImageUploadService } from '@/lib/image-upload-service';

const { width, height } = Dimensions.get('window');

interface ElementCustomizerProps {
  elements: UIElement[];
  onUpdateElement: (id: string, updates: Partial<UIElement>) => void;
  onRemoveElement: (id: string) => void;
  onAddElement: (element: UIElement) => void;
}

const DraggableElement = ({
  element,
  onUpdate,
  onRemove,
}: {
  element: UIElement;
  onUpdate: (updates: Partial<UIElement>) => void;
  onRemove: () => void;
}) => {
  const translateX = useSharedValue(element.position.x);
  const translateY = useSharedValue(element.position.y);
  const [showEdit, setShowEdit] = useState(false);
  const [newImageUri, setNewImageUri] = useState<string | undefined>(element.imageUri);

  const gesture = Gesture.Pan()
    .onUpdate((e) => {
      translateX.value = Math.max(0, Math.min(width - 80, e.translationX + element.position.x));
      translateY.value = Math.max(0, Math.min(height - 100, e.translationY + element.position.y));
    })
    .onEnd(() => {
      onUpdate({
        position: {
          x: translateX.value,
          y: translateY.value,
        },
      });
    });

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [
      { translateX: translateX.value },
      { translateY: translateY.value },
      { scale: element.scale },
      { rotate: `${element.rotation}deg` },
    ],
  }));

  const handlePickImage = async () => {
    const image = await ImageUploadService.pickImage();
    if (image) {
      setNewImageUri(image.uri);
      onUpdate({ imageUri: image.uri });
    }
  };

  return (
    <>
      <GestureDetector gesture={gesture}>
        <Animated.View
          style={[
            styles.element,
            {
              width: 80 * element.scale,
              height: 80 * element.scale,
              opacity: element.opacity,
            },
            animatedStyle,
          ]}
        >
          <TouchableOpacity
            onPress={() => setShowEdit(true)}
            style={styles.elementContent}
          >
            {element.imageUri ? (
              <Image
                source={{ uri: element.imageUri }}
                style={styles.elementImage}
              />
            ) : (
              <View style={styles.elementPlaceholder}>
                <MaterialIcons name="image" size={32} color="#FFD700" />
              </View>
            )}
          </TouchableOpacity>
        </Animated.View>
      </GestureDetector>

      <Modal visible={showEdit} transparent animationType="slide">
        <View style={styles.editModal}>
          <View style={styles.editHeader}>
            <Text style={styles.editTitle}>Edit Element</Text>
            <TouchableOpacity onPress={() => setShowEdit(false)}>
              <MaterialIcons name="close" size={24} color="#FFD700" />
            </TouchableOpacity>
          </View>

          <ScrollView style={styles.editContent}>
            <View style={styles.editField}>
              <Text style={styles.editLabel}>Name</Text>
              <TextInput
                style={styles.editInput}
                value={element.name}
                onChangeText={(text) => onUpdate({ name: text })}
                placeholderTextColor="#A0826D"
              />
            </View>

            <View style={styles.editField}>
              <Text style={styles.editLabel}>Scale: {element.scale.toFixed(2)}</Text>
              <View style={styles.sliderContainer}>
                <TouchableOpacity onPress={() => onUpdate({ scale: Math.max(0.5, element.scale - 0.1) })}>
                  <MaterialIcons name="remove" size={20} color="#FFD700" />
                </TouchableOpacity>
                <View style={styles.sliderTrack}>
                  <View
                    style={[
                      styles.sliderFill,
                      {
                        width: `${((element.scale - 0.5) / 1.5) * 100}%`,
                      },
                    ]}
                  />
                </View>
                <TouchableOpacity onPress={() => onUpdate({ scale: Math.min(2, element.scale + 0.1) })}>
                  <MaterialIcons name="add" size={20} color="#FFD700" />
                </TouchableOpacity>
              </View>
            </View>

            <View style={styles.editField}>
              <Text style={styles.editLabel}>Opacity: {element.opacity.toFixed(2)}</Text>
              <View style={styles.sliderContainer}>
                <TouchableOpacity onPress={() => onUpdate({ opacity: Math.max(0, element.opacity - 0.1) })}>
                  <MaterialIcons name="remove" size={20} color="#FFD700" />
                </TouchableOpacity>
                <View style={styles.sliderTrack}>
                  <View
                    style={[
                      styles.sliderFill,
                      {
                        width: `${element.opacity * 100}%`,
                      },
                    ]}
                  />
                </View>
                <TouchableOpacity onPress={() => onUpdate({ opacity: Math.min(1, element.opacity + 0.1) })}>
                  <MaterialIcons name="add" size={20} color="#FFD700" />
                </TouchableOpacity>
              </View>
            </View>

            <View style={styles.editField}>
              <Text style={styles.editLabel}>Rotation: {element.rotation}°</Text>
              <View style={styles.sliderContainer}>
                <TouchableOpacity onPress={() => onUpdate({ rotation: (element.rotation - 15) % 360 })}>
                  <MaterialIcons name="remove" size={20} color="#FFD700" />
                </TouchableOpacity>
                <View style={styles.sliderTrack}>
                  <View
                    style={[
                      styles.sliderFill,
                      {
                        width: `${(element.rotation / 360) * 100}%`,
                      },
                    ]}
                  />
                </View>
                <TouchableOpacity onPress={() => onUpdate({ rotation: (element.rotation + 15) % 360 })}>
                  <MaterialIcons name="add" size={20} color="#FFD700" />
                </TouchableOpacity>
              </View>
            </View>

            <TouchableOpacity
              onPress={handlePickImage}
              style={styles.imageButton}
            >
              <MaterialIcons name="image" size={20} color="#0d0d0d" />
              <Text style={styles.imageButtonText}>Upload Image</Text>
            </TouchableOpacity>

            <View style={styles.editActions}>
              <TouchableOpacity
                onPress={() => setShowEdit(false)}
                style={styles.saveButton}
              >
                <Text style={styles.saveButtonText}>Done</Text>
              </TouchableOpacity>

              <TouchableOpacity
                onPress={() => {
                  onRemove();
                  setShowEdit(false);
                }}
                style={styles.deleteButton}
              >
                <MaterialIcons name="delete" size={20} color="#EF4444" />
              </TouchableOpacity>
            </View>
          </ScrollView>
        </View>
      </Modal>
    </>
  );
};

export function ElementCustomizer({
  elements,
  onUpdateElement,
  onRemoveElement,
  onAddElement,
}: ElementCustomizerProps) {
  const [showAddModal, setShowAddModal] = useState(false);
  const [newName, setNewName] = useState('');

  const handleAddElement = () => {
    if (newName.trim()) {
      const newElement: UIElement = {
        id: `elem_${Date.now()}`,
        name: newName,
        opacity: 1,
        scale: 1,
        position: { x: 20, y: 20 + elements.length * 100 },
        rotation: 0,
      };
      onAddElement(newElement);
      setNewName('');
      setShowAddModal(false);
    }
  };

  return (
    <>
      <View style={styles.container}>
        <View style={styles.canvas}>
          {elements.map((element) => (
            <DraggableElement
              key={element.id}
              element={element}
              onUpdate={(updates) => onUpdateElement(element.id, updates)}
              onRemove={() => onRemoveElement(element.id)}
            />
          ))}
        </View>

        <TouchableOpacity
          onPress={() => setShowAddModal(true)}
          style={styles.addButton}
        >
          <MaterialIcons name="add" size={24} color="#0d0d0d" />
          <Text style={styles.addButtonText}>Add Element</Text>
        </TouchableOpacity>
      </View>

      <Modal visible={showAddModal} transparent animationType="slide">
        <View style={styles.addModal}>
          <View style={styles.addModalContent}>
            <Text style={styles.addModalTitle}>Add UI Element</Text>

            <View style={styles.addField}>
              <Text style={styles.addLabel}>Element Name</Text>
              <TextInput
                style={styles.addInput}
                value={newName}
                onChangeText={setNewName}
                placeholder="e.g., Logo, Background, Icon"
                placeholderTextColor="#A0826D"
              />
            </View>

            <View style={styles.addModalButtons}>
              <TouchableOpacity
                onPress={() => setShowAddModal(false)}
                style={styles.cancelButton}
              >
                <Text style={styles.cancelButtonText}>Cancel</Text>
              </TouchableOpacity>

              <TouchableOpacity
                onPress={handleAddElement}
                style={styles.addConfirmButton}
              >
                <Text style={styles.addConfirmButtonText}>Add</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0d0d0d',
  },
  canvas: {
    flex: 1,
    backgroundColor: '#1a1a1a',
    borderWidth: 2,
    borderColor: '#D4AF37',
    borderRadius: 8,
    margin: 16,
    overflow: 'hidden',
    position: 'relative',
  },
  element: {
    position: 'absolute',
    borderRadius: 8,
    borderWidth: 2,
    borderColor: '#D4AF37',
    overflow: 'hidden',
  },
  elementContent: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  elementImage: {
    width: '100%',
    height: '100%',
  },
  elementPlaceholder: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#0d0d0d',
  },
  addButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#FFD700',
    marginHorizontal: 16,
    marginBottom: 16,
    paddingVertical: 12,
    borderRadius: 8,
    gap: 8,
  },
  addButtonText: {
    color: '#0d0d0d',
    fontWeight: 'bold',
    fontSize: 14,
  },
  editModal: {
    flex: 1,
    backgroundColor: '#0d0d0d',
    paddingTop: 40,
  },
  editHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 2,
    borderBottomColor: '#D4AF37',
  },
  editTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#FFD700',
  },
  editContent: {
    flex: 1,
    paddingHorizontal: 16,
    paddingVertical: 16,
  },
  editField: {
    marginBottom: 16,
  },
  editLabel: {
    fontSize: 12,
    color: '#A0826D',
    marginBottom: 8,
    fontWeight: '500',
  },
  editInput: {
    backgroundColor: '#1a1a1a',
    borderWidth: 1,
    borderColor: '#333',
    borderRadius: 6,
    paddingHorizontal: 12,
    paddingVertical: 10,
    color: '#FFD700',
    fontSize: 14,
  },
  sliderContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  sliderTrack: {
    flex: 1,
    height: 4,
    backgroundColor: '#333',
    borderRadius: 2,
    overflow: 'hidden',
  },
  sliderFill: {
    height: '100%',
    backgroundColor: '#FFD700',
  },
  imageButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#FFD700',
    paddingVertical: 12,
    borderRadius: 6,
    marginBottom: 16,
    gap: 8,
  },
  imageButtonText: {
    color: '#0d0d0d',
    fontWeight: 'bold',
    fontSize: 14,
  },
  editActions: {
    flexDirection: 'row',
    gap: 8,
    marginTop: 24,
  },
  saveButton: {
    flex: 1,
    backgroundColor: '#FFD700',
    paddingVertical: 12,
    borderRadius: 6,
    justifyContent: 'center',
    alignItems: 'center',
  },
  saveButtonText: {
    color: '#0d0d0d',
    fontWeight: 'bold',
    fontSize: 14,
  },
  deleteButton: {
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 6,
    backgroundColor: '#1a1a1a',
    borderWidth: 1,
    borderColor: '#EF4444',
    justifyContent: 'center',
    alignItems: 'center',
  },
  addModal: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.9)',
    justifyContent: 'flex-end',
  },
  addModalContent: {
    backgroundColor: '#0d0d0d',
    borderTopLeftRadius: 16,
    borderTopRightRadius: 16,
    paddingHorizontal: 16,
    paddingVertical: 24,
    paddingBottom: 40,
  },
  addModalTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#FFD700',
    marginBottom: 16,
  },
  addField: {
    marginBottom: 16,
  },
  addLabel: {
    fontSize: 12,
    color: '#A0826D',
    marginBottom: 8,
    fontWeight: '500',
  },
  addInput: {
    backgroundColor: '#1a1a1a',
    borderWidth: 1,
    borderColor: '#333',
    borderRadius: 6,
    paddingHorizontal: 12,
    paddingVertical: 10,
    color: '#FFD700',
    fontSize: 14,
  },
  addModalButtons: {
    flexDirection: 'row',
    gap: 8,
    marginTop: 24,
  },
  cancelButton: {
    flex: 1,
    backgroundColor: '#1a1a1a',
    borderWidth: 1,
    borderColor: '#333',
    paddingVertical: 12,
    borderRadius: 6,
    justifyContent: 'center',
    alignItems: 'center',
  },
  cancelButtonText: {
    color: '#FFD700',
    fontWeight: 'bold',
    fontSize: 14,
  },
  addConfirmButton: {
    flex: 1,
    backgroundColor: '#FFD700',
    paddingVertical: 12,
    borderRadius: 6,
    justifyContent: 'center',
    alignItems: 'center',
  },
  addConfirmButtonText: {
    color: '#0d0d0d',
    fontWeight: 'bold',
    fontSize: 14,
  },
});
