import React, { useEffect } from 'react';
import { View } from 'react-native';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withTiming,
  withSequence,
  Easing,
  withDelay,
} from 'react-native-reanimated';

interface SteamPuffProps {
  delay?: number;
  duration?: number;
  size?: number;
  color?: string;
}

/**
 * Single steam puff particle that animates upward with fade-out
 */
export const SteamPuff: React.FC<SteamPuffProps> = ({
  delay = 0,
  duration = 1200,
  size = 40,
  color = 'rgba(212, 175, 55, 0.6)',
}) => {
  const opacity = useSharedValue(0);
  const translateY = useSharedValue(0);
  const scale = useSharedValue(0.3);

  useEffect(() => {
    opacity.value = withDelay(
      delay,
      withSequence(
        withTiming(0.8, { duration: 200, easing: Easing.out(Easing.cubic) }),
        withTiming(0, { duration: duration - 200, easing: Easing.in(Easing.cubic) })
      )
    );

    translateY.value = withDelay(
      delay,
      withTiming(-80, { duration, easing: Easing.out(Easing.quad) })
    );

    scale.value = withDelay(
      delay,
      withTiming(1.2, { duration, easing: Easing.out(Easing.quad) })
    );
  }, []);

  const animatedStyle = useAnimatedStyle(() => ({
    opacity: opacity.value,
    transform: [
      { translateY: translateY.value },
      { scale: scale.value },
    ],
  }));

  return (
    <Animated.View
      style={[
        {
          position: 'absolute',
          width: size,
          height: size,
          borderRadius: size / 2,
          backgroundColor: color,
          filter: 'blur(8px)',
        },
        animatedStyle,
      ]}
    />
  );
};

interface SteamPuffSystemProps {
  count?: number;
  duration?: number;
  color?: string;
  size?: number;
}

/**
 * System of multiple steam puffs for a realistic steam effect
 */
export const SteamPuffSystem: React.FC<SteamPuffSystemProps> = ({
  count = 5,
  duration = 1200,
  color = 'rgba(212, 175, 55, 0.6)',
  size = 40,
}) => {
  return (
    <View style={{ position: 'relative', width: 100, height: 100 }}>
      {Array.from({ length: count }).map((_, i) => (
        <SteamPuff
          key={i}
          delay={i * 100}
          duration={duration}
          color={color}
          size={size}
        />
      ))}
    </View>
  );
};
