import React, { useState } from 'react';
import { View, Text, TouchableOpacity, PanResponder, Animated, Dimensions } from 'react-native';
import { NavigationLink } from '@/lib/advanced-theme-context';

interface DraggableNavEditorProps {
  links: NavigationLink[];
  onUpdateLink: (link: NavigationLink) => void;
  onToggleVisibility: (linkId: string) => void;
}

export function DraggableNavEditor({
  links,
  onUpdateLink,
  onToggleVisibility,
}: DraggableNavEditorProps) {
  const [selectedLink, setSelectedLink] = useState<string | null>(null);
  const screenWidth = Dimensions.get('window').width;
  const screenHeight = Dimensions.get('window').height;

  const handleDragStart = (linkId: string) => {
    setSelectedLink(linkId);
  };

  const handleDragEnd = (linkId: string, x: number, y: number) => {
    const link = links.find((l) => l.id === linkId);
    if (link) {
      const normalizedX = Math.max(0, Math.min(1, x / screenWidth));
      const normalizedY = Math.max(0, Math.min(1, y / screenHeight));
      onUpdateLink({
        ...link,
        position: { x: normalizedX, y: normalizedY },
      });
    }
    setSelectedLink(null);
  };

  return (
    <View className="flex-1 bg-background rounded-lg border-2 border-border p-4 min-h-96">
      {/* Canvas */}
      <View className="flex-1 bg-surface rounded-lg border border-border relative mb-4 overflow-hidden">
        {/* Grid background */}
        <View className="absolute inset-0 opacity-10">
          {Array.from({ length: 10 }).map((_, i) => (
            <View
              key={`h-${i}`}
              className="absolute w-full border-t border-border"
              style={{ top: `${i * 10}%` }}
            />
          ))}
          {Array.from({ length: 10 }).map((_, i) => (
            <View
              key={`v-${i}`}
              className="absolute h-full border-l border-border"
              style={{ left: `${i * 10}%` }}
            />
          ))}
        </View>

        {/* Navigation links */}
        {links.map((link) => (
          <TouchableOpacity
            key={link.id}
            onPress={() => handleDragStart(link.id)}
            onLongPress={() => handleDragStart(link.id)}
            className={`absolute w-16 h-16 rounded-lg flex items-center justify-center transition-all ${
              link.visible ? 'bg-primary' : 'bg-muted opacity-50'
            } ${selectedLink === link.id ? 'border-2 border-accent' : 'border border-border'}`}
            style={{
              left: `${link.position.x * 100}%`,
              top: `${link.position.y * 100}%`,
              transform: [{ translateX: -32 }, { translateY: -32 }],
            }}
          >
            <View className="items-center">
              <Text className="text-xs font-bold text-background text-center">{link.label}</Text>
            </View>
          </TouchableOpacity>
        ))}
      </View>

      {/* Controls */}
      <View className="gap-3">
        <Text className="text-foreground font-semibold">Navigation Links</Text>
        {links.map((link) => (
          <View
            key={link.id}
            className="flex-row items-center justify-between bg-surface p-3 rounded-lg border border-border"
          >
            <View className="flex-1">
              <Text className="text-foreground font-semibold">{link.label}</Text>
              <Text className="text-xs text-muted">
                {Math.round(link.position.x * 100)}%, {Math.round(link.position.y * 100)}%
              </Text>
            </View>
            <TouchableOpacity
              onPress={() => onToggleVisibility(link.id)}
              className={`px-3 py-1 rounded ${link.visible ? 'bg-primary' : 'bg-muted'}`}
            >
              <Text className="text-xs font-bold text-background">
                {link.visible ? 'Visible' : 'Hidden'}
              </Text>
            </TouchableOpacity>
          </View>
        ))}
      </View>
    </View>
  );
}
