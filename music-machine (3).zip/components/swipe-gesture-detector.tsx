import React, { useRef, useCallback, useState } from 'react';
import { View, GestureResponderEvent, StyleSheet } from 'react-native';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withTiming,
  Easing,
} from 'react-native-reanimated';

interface SwipeGestureDetectorProps {
  onSwipeLeft?: () => void;
  onSwipeRight?: () => void;
  onSwipeUp?: () => void;
  onSwipeDown?: () => void;
  children?: React.ReactNode;
  minSwipeDistance?: number;
  maxSwipeTime?: number;
}

interface TouchPoint {
  x: number;
  y: number;
  timestamp: number;
}

/**
 * Detects swipe gestures and triggers callbacks
 * Provides visual feedback during swipe detection
 */
export const SwipeGestureDetector: React.FC<SwipeGestureDetectorProps> = ({
  onSwipeLeft,
  onSwipeRight,
  onSwipeUp,
  onSwipeDown,
  children,
  minSwipeDistance = 50,
  maxSwipeTime = 500,
}) => {
  const startTouchRef = useRef<TouchPoint | null>(null);
  const [isDetectingSwipe, setIsDetectingSwipe] = useState(false);

  // Animation values for visual feedback
  const feedbackOpacity = useSharedValue(0);
  const feedbackScale = useSharedValue(1);

  const animatedFeedbackStyle = useAnimatedStyle(() => ({
    opacity: feedbackOpacity.value,
    transform: [{ scale: feedbackScale.value }],
  }));

  const showFeedback = useCallback(() => {
    feedbackOpacity.value = withTiming(0.6, {
      duration: 100,
      easing: Easing.out(Easing.cubic),
    });
    feedbackScale.value = withTiming(1.05, {
      duration: 100,
      easing: Easing.out(Easing.cubic),
    });

    // Fade out feedback
    setTimeout(() => {
      feedbackOpacity.value = withTiming(0, {
        duration: 200,
        easing: Easing.in(Easing.cubic),
      });
      feedbackScale.value = withTiming(1, {
        duration: 200,
        easing: Easing.in(Easing.cubic),
      });
    }, 300);
  }, []);

  const handleTouchStart = useCallback((e: GestureResponderEvent) => {
    const { locationX, locationY } = e.nativeEvent;
    startTouchRef.current = {
      x: locationX,
      y: locationY,
      timestamp: Date.now(),
    };
    setIsDetectingSwipe(true);
  }, []);

  const handleTouchEnd = useCallback((e: GestureResponderEvent) => {
    if (!startTouchRef.current) {
      setIsDetectingSwipe(false);
      return;
    }

    const { locationX, locationY } = e.nativeEvent;
    const endTime = Date.now();
    const startTouch = startTouchRef.current;

    // Calculate swipe distance and time
    const deltaX = locationX - startTouch.x;
    const deltaY = locationY - startTouch.y;
    const deltaTime = endTime - startTouch.timestamp;

    // Validate swipe
    if (deltaTime > maxSwipeTime) {
      setIsDetectingSwipe(false);
      return;
    }

    const absDeltaX = Math.abs(deltaX);
    const absDeltaY = Math.abs(deltaY);

    // Determine swipe direction (must be more horizontal/vertical than the other)
    if (absDeltaX > absDeltaY && absDeltaX > minSwipeDistance) {
      // Horizontal swipe
      showFeedback();
      if (deltaX > 0) {
        onSwipeRight?.();
      } else {
        onSwipeLeft?.();
      }
    } else if (absDeltaY > absDeltaX && absDeltaY > minSwipeDistance) {
      // Vertical swipe
      showFeedback();
      if (deltaY > 0) {
        onSwipeDown?.();
      } else {
        onSwipeUp?.();
      }
    }

    startTouchRef.current = null;
    setIsDetectingSwipe(false);
  }, [minSwipeDistance, maxSwipeTime, onSwipeLeft, onSwipeRight, onSwipeUp, onSwipeDown, showFeedback]);

  return (
    <View
      style={styles.container}
      onStartShouldSetResponder={() => true}
      onResponderGrant={handleTouchStart}
      onResponderRelease={handleTouchEnd}
      onResponderTerminate={handleTouchEnd}
    >
      {children}

      {/* Visual feedback indicator */}
      <Animated.View
        style={[
          styles.feedbackIndicator,
          animatedFeedbackStyle,
          isDetectingSwipe && styles.feedbackActive,
        ]}
        pointerEvents="none"
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    position: 'relative',
  },
  feedbackIndicator: {
    position: 'absolute',
    top: '50%',
    left: '50%',
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: 'rgba(212, 175, 55, 0.3)',
    borderWidth: 2,
    borderColor: 'rgba(212, 175, 55, 0.6)',
    marginLeft: -30,
    marginTop: -30,
    pointerEvents: 'none',
  },
  feedbackActive: {
    backgroundColor: 'rgba(212, 175, 55, 0.5)',
    borderColor: 'rgba(212, 175, 55, 0.8)',
  },
});
