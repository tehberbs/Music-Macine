import React, { useEffect } from 'react';
import { View } from 'react-native';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withRepeat,
  withTiming,
  Easing,
} from 'react-native-reanimated';
import Svg, { Circle, Path, G } from 'react-native-svg';

interface CogProps {
  size: number;
  teeth: number;
  rotation?: number;
  speed?: number;
  color?: string;
  style?: any;
  clockwise?: boolean;
}

/**
 * Animated Cog Wheel Component
 * Renders a rotating cog wheel with customizable teeth and animation speed
 */
export function AnimatedCog({
  size,
  teeth,
  rotation = 0,
  speed = 1,
  color = '#8B7355',
  style,
  clockwise = true,
}: CogProps) {
  const rotationValue = useSharedValue(0);

  useEffect(() => {
    rotationValue.value = withRepeat(
      withTiming(clockwise ? 360 : -360, {
        duration: 4000 / speed,
        easing: Easing.linear,
      }),
      -1,
      false
    );
  }, [speed, clockwise]);

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [{ rotate: `${rotationValue.value}deg` }],
  }));

  const radius = size / 2;
  const toothDepth = size * 0.15;
  const toothWidth = (Math.PI * 2 * radius) / teeth / 2;

  // Generate tooth path
  const generateToothPath = () => {
    let path = '';
    const innerRadius = radius - toothDepth;
    const outerRadius = radius;

    for (let i = 0; i < teeth; i++) {
      const angle = (i / teeth) * Math.PI * 2;
      const nextAngle = ((i + 1) / teeth) * Math.PI * 2;

      // Outer tooth point
      const x1 = Math.cos(angle) * outerRadius;
      const y1 = Math.sin(angle) * outerRadius;

      // Inner valley
      const x2 = Math.cos(angle + (nextAngle - angle) / 2) * innerRadius;
      const y2 = Math.sin(angle + (nextAngle - angle) / 2) * innerRadius;

      // Next outer tooth point
      const x3 = Math.cos(nextAngle) * outerRadius;
      const y3 = Math.sin(nextAngle) * outerRadius;

      if (i === 0) {
        path += `M ${x1} ${y1}`;
      }

      path += ` L ${x2} ${y2} L ${x3} ${y3}`;
    }

    path += ' Z';
    return path;
  };

  return (
    <Animated.View style={[animatedStyle, style]}>
      <Svg width={size} height={size} viewBox={`${-radius} ${-radius} ${size} ${size}`}>
        <G>
          {/* Outer cog teeth */}
          <Path d={generateToothPath()} fill={color} stroke="#5A4A3A" strokeWidth="0.5" />

          {/* Center hub */}
          <Circle cx="0" cy="0" r={radius * 0.3} fill={color} stroke="#5A4A3A" strokeWidth="0.5" />

          {/* Center hole */}
          <Circle cx="0" cy="0" r={radius * 0.15} fill="#1a1a1a" />

          {/* Metallic shine */}
          <Circle
            cx={-radius * 0.2}
            cy={-radius * 0.2}
            r={radius * 0.4}
            fill="white"
            opacity="0.1"
          />
        </G>
      </Svg>
    </Animated.View>
  );
}

/**
 * Cog Cluster Component
 * Renders multiple interlocking cogs
 */
export function CogCluster({
  cogCount = 5,
  baseSize = 60,
  style,
}: {
  cogCount?: number;
  baseSize?: number;
  style?: any;
}) {
  const cogs = Array.from({ length: cogCount }, (_, i) => {
    const angle = (i / cogCount) * Math.PI * 2;
    const distance = baseSize * 1.5;
    const x = Math.cos(angle) * distance;
    const y = Math.sin(angle) * distance;
    const size = baseSize * (0.7 + Math.random() * 0.6);
    const speed = 1 + Math.random() * 2;
    const clockwise = i % 2 === 0;

    return { x, y, size, speed, clockwise, id: i };
  });

  return (
    <View style={[{ position: 'relative', width: baseSize * 4, height: baseSize * 4 }, style]}>
      {cogs.map((cog) => (
        <View
          key={cog.id}
          style={{
            position: 'absolute',
            left: baseSize * 2 + cog.x - cog.size / 2,
            top: baseSize * 2 + cog.y - cog.size / 2,
          }}
        >
          <AnimatedCog
            size={cog.size}
            teeth={Math.floor(12 + Math.random() * 8)}
            speed={cog.speed}
            clockwise={cog.clockwise}
            color={`hsl(${30 + Math.random() * 20}, 40%, ${50 + Math.random() * 10}%)`}
          />
        </View>
      ))}
    </View>
  );
}

/**
 * Mechanical Gauge Component
 * Displays a value as a rotating needle on a gauge
 */
export function MechanicalGauge({
  value,
  min = 0,
  max = 100,
  size = 120,
  label = 'GAUGE',
  style,
}: {
  value: number;
  min?: number;
  max?: number;
  size?: number;
  label?: string;
  style?: any;
}) {
  const radius = size / 2;
  const needleRotation = ((value - min) / (max - min)) * 270 - 135;

  return (
    <View style={[{ alignItems: 'center' }, style]}>
      <Svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
        {/* Gauge background */}
        <Circle
          cx={radius}
          cy={radius}
          r={radius - 5}
          fill="#2a2a2a"
          stroke="#8B7355"
          strokeWidth="2"
        />

        {/* Gauge markings */}
        {Array.from({ length: 13 }, (_, i) => {
          const angle = (i / 12) * Math.PI * 1.5 - Math.PI * 0.75;
          const x1 = radius + Math.cos(angle) * (radius - 8);
          const y1 = radius + Math.sin(angle) * (radius - 8);
          const x2 = radius + Math.cos(angle) * (radius - 15);
          const y2 = radius + Math.sin(angle) * (radius - 15);

          return (
            <line
              key={i}
              x1={x1}
              y1={y1}
              x2={x2}
              y2={y2}
              stroke="#8B7355"
              strokeWidth="1.5"
            />
          );
        })}

        {/* Needle */}
        <G transform={`translate(${radius}, ${radius}) rotate(${needleRotation})`}>
          <line x1="0" y1="0" x2="0" y2={-radius + 15} stroke="#D4AF37" strokeWidth="2" />
          <circle cx="0" cy="0" r="4" fill="#D4AF37" />
        </G>

        {/* Center cap */}
        <Circle cx={radius} cy={radius} r="6" fill="#5A4A3A" stroke="#8B7355" strokeWidth="1" />
      </Svg>
    </View>
  );
}
