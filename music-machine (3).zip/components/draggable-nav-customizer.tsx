import React, { useState } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  Dimensions,
  TextInput,
  ScrollView,
  Modal,
} from 'react-native';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withSpring,
} from 'react-native-reanimated';
import {
  Gesture,
  GestureDetector,
} from 'react-native-gesture-handler';
import MaterialIcons from '@expo/vector-icons/MaterialIcons';
import { NavigationLink } from '@/lib/theme-customization-context';

const { width, height } = Dimensions.get('window');

interface DraggableNavCustomizerProps {
  links: NavigationLink[];
  onUpdateLink: (id: string, updates: Partial<NavigationLink>) => void;
  onRemoveLink: (id: string) => void;
  onAddLink: (link: NavigationLink) => void;
}

const DraggableNavLink = ({
  link,
  onUpdate,
  onRemove,
}: {
  link: NavigationLink;
  onUpdate: (updates: Partial<NavigationLink>) => void;
  onRemove: () => void;
}) => {
  const translateX = useSharedValue(link.position.x);
  const translateY = useSharedValue(link.position.y);
  const [showEdit, setShowEdit] = useState(false);

  const gesture = Gesture.Pan()
    .onUpdate((e) => {
      translateX.value = Math.max(0, Math.min(width - 60, e.translationX + link.position.x));
      translateY.value = Math.max(0, Math.min(height - 100, e.translationY + link.position.y));
    })
    .onEnd(() => {
      onUpdate({
        position: {
          x: translateX.value,
          y: translateY.value,
        },
      });
    });

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [
      { translateX: translateX.value },
      { translateY: translateY.value },
    ],
  }));

  return (
    <>
      <GestureDetector gesture={gesture}>
        <Animated.View
          style={[
            styles.draggableLink,
            {
              width: link.size,
              height: link.size,
              backgroundColor: link.color,
            },
            animatedStyle,
          ]}
        >
          <TouchableOpacity
            onPress={() => setShowEdit(true)}
            style={styles.linkContent}
          >
            <MaterialIcons name="touch-app" size={20} color="#0d0d0d" />
          </TouchableOpacity>
        </Animated.View>
      </GestureDetector>

      <Modal visible={showEdit} transparent animationType="slide">
        <View style={styles.editModal}>
          <View style={styles.editHeader}>
            <Text style={styles.editTitle}>Edit Navigation Link</Text>
            <TouchableOpacity onPress={() => setShowEdit(false)}>
              <MaterialIcons name="close" size={24} color="#FFD700" />
            </TouchableOpacity>
          </View>

          <ScrollView style={styles.editContent}>
            <View style={styles.editField}>
              <Text style={styles.editLabel}>Label</Text>
              <TextInput
                style={styles.editInput}
                value={link.label}
                onChangeText={(text) => onUpdate({ label: text })}
                placeholderTextColor="#A0826D"
              />
            </View>

            <View style={styles.editField}>
              <Text style={styles.editLabel}>Icon</Text>
              <TextInput
                style={styles.editInput}
                value={link.icon}
                onChangeText={(text) => onUpdate({ icon: text })}
                placeholderTextColor="#A0826D"
              />
            </View>

            <View style={styles.editField}>
              <Text style={styles.editLabel}>Action</Text>
              <TextInput
                style={styles.editInput}
                value={link.action}
                onChangeText={(text) => onUpdate({ action: text })}
                placeholderTextColor="#A0826D"
              />
            </View>

            <View style={styles.editField}>
              <Text style={styles.editLabel}>Size: {link.size}</Text>
              <View style={styles.sizeButtons}>
                {[40, 50, 60, 70].map((size) => (
                  <TouchableOpacity
                    key={size}
                    onPress={() => onUpdate({ size })}
                    style={[
                      styles.sizeButton,
                      link.size === size && styles.sizeButtonActive,
                    ]}
                  >
                    <Text style={styles.sizeButtonText}>{size}</Text>
                  </TouchableOpacity>
                ))}
              </View>
            </View>

            <View style={styles.editActions}>
              <TouchableOpacity
                onPress={() => {
                  setShowEdit(false);
                }}
                style={styles.saveButton}
              >
                <Text style={styles.saveButtonText}>Save</Text>
              </TouchableOpacity>

              <TouchableOpacity
                onPress={() => {
                  onRemove();
                  setShowEdit(false);
                }}
                style={styles.deleteButton}
              >
                <MaterialIcons name="delete" size={20} color="#EF4444" />
              </TouchableOpacity>
            </View>
          </ScrollView>
        </View>
      </Modal>
    </>
  );
};

export function DraggableNavCustomizer({
  links,
  onUpdateLink,
  onRemoveLink,
  onAddLink,
}: DraggableNavCustomizerProps) {
  const [showAddModal, setShowAddModal] = useState(false);
  const [newLabel, setNewLabel] = useState('');
  const [newIcon, setNewIcon] = useState('home');
  const [newAction, setNewAction] = useState('');

  const handleAddLink = () => {
    if (newLabel.trim()) {
      const newLink: NavigationLink = {
        id: `link_${Date.now()}`,
        label: newLabel,
        icon: newIcon,
        position: { x: 20, y: 20 + links.length * 80 },
        size: 60,
        color: '#FFD700',
        action: newAction,
      };
      onAddLink(newLink);
      setNewLabel('');
      setNewIcon('home');
      setNewAction('');
      setShowAddModal(false);
    }
  };

  return (
    <>
      <View style={styles.container}>
        <View style={styles.canvas}>
          {links.map((link) => (
            <DraggableNavLink
              key={link.id}
              link={link}
              onUpdate={(updates) => onUpdateLink(link.id, updates)}
              onRemove={() => onRemoveLink(link.id)}
            />
          ))}
        </View>

        <TouchableOpacity
          onPress={() => setShowAddModal(true)}
          style={styles.addButton}
        >
          <MaterialIcons name="add" size={24} color="#0d0d0d" />
          <Text style={styles.addButtonText}>Add Link</Text>
        </TouchableOpacity>
      </View>

      <Modal visible={showAddModal} transparent animationType="slide">
        <View style={styles.addModal}>
          <View style={styles.addModalContent}>
            <Text style={styles.addModalTitle}>Add Navigation Link</Text>

            <View style={styles.addField}>
              <Text style={styles.addLabel}>Label</Text>
              <TextInput
                style={styles.addInput}
                value={newLabel}
                onChangeText={setNewLabel}
                placeholder="Link name"
                placeholderTextColor="#A0826D"
              />
            </View>

            <View style={styles.addField}>
              <Text style={styles.addLabel}>Icon</Text>
              <TextInput
                style={styles.addInput}
                value={newIcon}
                onChangeText={setNewIcon}
                placeholder="Material icon name"
                placeholderTextColor="#A0826D"
              />
            </View>

            <View style={styles.addField}>
              <Text style={styles.addLabel}>Action</Text>
              <TextInput
                style={styles.addInput}
                value={newAction}
                onChangeText={setNewAction}
                placeholder="Action/route"
                placeholderTextColor="#A0826D"
              />
            </View>

            <View style={styles.addModalButtons}>
              <TouchableOpacity
                onPress={() => setShowAddModal(false)}
                style={styles.cancelButton}
              >
                <Text style={styles.cancelButtonText}>Cancel</Text>
              </TouchableOpacity>

              <TouchableOpacity
                onPress={handleAddLink}
                style={styles.addConfirmButton}
              >
                <Text style={styles.addConfirmButtonText}>Add</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0d0d0d',
  },
  canvas: {
    flex: 1,
    backgroundColor: '#1a1a1a',
    borderWidth: 2,
    borderColor: '#D4AF37',
    borderRadius: 8,
    margin: 16,
    overflow: 'hidden',
    position: 'relative',
  },
  draggableLink: {
    position: 'absolute',
    borderRadius: 30,
    borderWidth: 2,
    borderColor: '#D4AF37',
    justifyContent: 'center',
    alignItems: 'center',
  },
  linkContent: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  addButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#FFD700',
    marginHorizontal: 16,
    marginBottom: 16,
    paddingVertical: 12,
    borderRadius: 8,
    gap: 8,
  },
  addButtonText: {
    color: '#0d0d0d',
    fontWeight: 'bold',
    fontSize: 14,
  },
  editModal: {
    flex: 1,
    backgroundColor: '#0d0d0d',
    paddingTop: 40,
  },
  editHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 2,
    borderBottomColor: '#D4AF37',
  },
  editTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#FFD700',
  },
  editContent: {
    flex: 1,
    paddingHorizontal: 16,
    paddingVertical: 16,
  },
  editField: {
    marginBottom: 16,
  },
  editLabel: {
    fontSize: 12,
    color: '#A0826D',
    marginBottom: 8,
    fontWeight: '500',
  },
  editInput: {
    backgroundColor: '#1a1a1a',
    borderWidth: 1,
    borderColor: '#333',
    borderRadius: 6,
    paddingHorizontal: 12,
    paddingVertical: 10,
    color: '#FFD700',
    fontSize: 14,
  },
  sizeButtons: {
    flexDirection: 'row',
    gap: 8,
  },
  sizeButton: {
    flex: 1,
    paddingVertical: 10,
    borderRadius: 6,
    backgroundColor: '#1a1a1a',
    borderWidth: 1,
    borderColor: '#333',
    justifyContent: 'center',
    alignItems: 'center',
  },
  sizeButtonActive: {
    backgroundColor: '#FFD700',
    borderColor: '#FFD700',
  },
  sizeButtonText: {
    color: '#FFD700',
    fontWeight: 'bold',
    fontSize: 12,
  },
  editActions: {
    flexDirection: 'row',
    gap: 8,
    marginTop: 24,
  },
  saveButton: {
    flex: 1,
    backgroundColor: '#FFD700',
    paddingVertical: 12,
    borderRadius: 6,
    justifyContent: 'center',
    alignItems: 'center',
  },
  saveButtonText: {
    color: '#0d0d0d',
    fontWeight: 'bold',
    fontSize: 14,
  },
  deleteButton: {
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 6,
    backgroundColor: '#1a1a1a',
    borderWidth: 1,
    borderColor: '#EF4444',
    justifyContent: 'center',
    alignItems: 'center',
  },
  addModal: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.9)',
    justifyContent: 'flex-end',
  },
  addModalContent: {
    backgroundColor: '#0d0d0d',
    borderTopLeftRadius: 16,
    borderTopRightRadius: 16,
    paddingHorizontal: 16,
    paddingVertical: 24,
    paddingBottom: 40,
  },
  addModalTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#FFD700',
    marginBottom: 16,
  },
  addField: {
    marginBottom: 16,
  },
  addLabel: {
    fontSize: 12,
    color: '#A0826D',
    marginBottom: 8,
    fontWeight: '500',
  },
  addInput: {
    backgroundColor: '#1a1a1a',
    borderWidth: 1,
    borderColor: '#333',
    borderRadius: 6,
    paddingHorizontal: 12,
    paddingVertical: 10,
    color: '#FFD700',
    fontSize: 14,
  },
  addModalButtons: {
    flexDirection: 'row',
    gap: 8,
    marginTop: 24,
  },
  cancelButton: {
    flex: 1,
    backgroundColor: '#1a1a1a',
    borderWidth: 1,
    borderColor: '#333',
    paddingVertical: 12,
    borderRadius: 6,
    justifyContent: 'center',
    alignItems: 'center',
  },
  cancelButtonText: {
    color: '#FFD700',
    fontWeight: 'bold',
    fontSize: 14,
  },
  addConfirmButton: {
    flex: 1,
    backgroundColor: '#FFD700',
    paddingVertical: 12,
    borderRadius: 6,
    justifyContent: 'center',
    alignItems: 'center',
  },
  addConfirmButtonText: {
    color: '#0d0d0d',
    fontWeight: 'bold',
    fontSize: 14,
  },
});
