import React from 'react';
import { Dimensions } from 'react-native';
import Svg, { Line, Circle, Rect, Path, Polygon } from 'react-native-svg';

const { width, height } = Dimensions.get('window');

export const MechanicalConnectors: React.FC = () => {
  return (
    <Svg width={width} height={height} style={{ position: 'absolute', pointerEvents: 'none' }}>
      {/* Horizontal pipes */}
      <Rect x={width * 0.1} y={height * 0.25} width={width * 0.8} height={8} fill="#8B7355" rx={4} />
      <Rect x={width * 0.1} y={height * 0.25 + 2} width={width * 0.8} height={4} fill="#A0826D" rx={2} />

      <Rect x={width * 0.15} y={height * 0.5} width={width * 0.7} height={6} fill="#8B7355" rx={3} />
      <Rect x={width * 0.15} y={height * 0.5 + 1.5} width={width * 0.7} height={3} fill="#A0826D" rx={1.5} />

      <Rect x={width * 0.1} y={height * 0.75} width={width * 0.8} height={7} fill="#8B7355" rx={3.5} />
      <Rect x={width * 0.1} y={height * 0.75 + 2} width={width * 0.8} height={3} fill="#A0826D" rx={1.5} />

      {/* Vertical pipes */}
      <Rect x={width * 0.2} y={height * 0.1} width={6} height={height * 0.8} fill="#8B7355" rx={3} />
      <Rect x={width * 0.2 + 1.5} y={height * 0.1} width={3} height={height * 0.8} fill="#A0826D" rx={1.5} />

      <Rect x={width * 0.5} y={height * 0.05} width={5} height={height * 0.9} fill="#8B7355" rx={2.5} />
      <Rect x={width * 0.5 + 1.5} y={height * 0.05} width={2} height={height * 0.9} fill="#A0826D" rx={1} />

      <Rect x={width * 0.8} y={height * 0.15} width={6} height={height * 0.7} fill="#8B7355" rx={3} />
      <Rect x={width * 0.8 + 1.5} y={height * 0.15} width={3} height={height * 0.7} fill="#A0826D" rx={1.5} />

      {/* Diagonal connectors */}
      <Line x1={width * 0.3} y1={height * 0.2} x2={width * 0.7} y2={height * 0.6} stroke="#8B7355" strokeWidth={5} strokeLinecap="round" />
      <Line x1={width * 0.3 + 1.5} y1={height * 0.2} x2={width * 0.7 + 1.5} y2={height * 0.6} stroke="#A0826D" strokeWidth={2} strokeLinecap="round" />

      <Line x1={width * 0.7} y1={height * 0.2} x2={width * 0.3} y2={height * 0.6} stroke="#8B7355" strokeWidth={5} strokeLinecap="round" />
      <Line x1={width * 0.7 + 1.5} y1={height * 0.2} x2={width * 0.3 + 1.5} y2={height * 0.6} stroke="#A0826D" strokeWidth={2} strokeLinecap="round" />

      {/* Pipe joints and connectors */}
      {/* Horizontal joints */}
      <Circle cx={width * 0.1} cy={height * 0.25} r={6} fill="#D4AF37" stroke="#8B7355" strokeWidth={1.5} />
      <Circle cx={width * 0.9} cy={height * 0.25} r={6} fill="#D4AF37" stroke="#8B7355" strokeWidth={1.5} />
      <Circle cx={width * 0.15} cy={height * 0.5} r={5} fill="#D4AF37" stroke="#8B7355" strokeWidth={1.5} />
      <Circle cx={width * 0.85} cy={height * 0.5} r={5} fill="#D4AF37" stroke="#8B7355" strokeWidth={1.5} />
      <Circle cx={width * 0.1} cy={height * 0.75} r={6} fill="#D4AF37" stroke="#8B7355" strokeWidth={1.5} />
      <Circle cx={width * 0.9} cy={height * 0.75} r={6} fill="#D4AF37" stroke="#8B7355" strokeWidth={1.5} />

      {/* Vertical joints */}
      <Circle cx={width * 0.2} cy={height * 0.1} r={5} fill="#D4AF37" stroke="#8B7355" strokeWidth={1.5} />
      <Circle cx={width * 0.2} cy={height * 0.9} r={5} fill="#D4AF37" stroke="#8B7355" strokeWidth={1.5} />
      <Circle cx={width * 0.5} cy={height * 0.05} r={4} fill="#D4AF37" stroke="#8B7355" strokeWidth={1.5} />
      <Circle cx={width * 0.5} cy={height * 0.95} r={4} fill="#D4AF37" stroke="#8B7355" strokeWidth={1.5} />
      <Circle cx={width * 0.8} cy={height * 0.15} r={5} fill="#D4AF37" stroke="#8B7355" strokeWidth={1.5} />
      <Circle cx={width * 0.8} cy={height * 0.85} r={5} fill="#D4AF37" stroke="#8B7355" strokeWidth={1.5} />

      {/* Bolts and rivets on pipes */}
      {Array.from({ length: 8 }).map((_, i) => (
        <Circle
          key={`bolt-h1-${i}`}
          cx={width * 0.1 + (width * 0.8 * i) / 8}
          cy={height * 0.25}
          r={2}
          fill="#FFD700"
          stroke="#8B7355"
          strokeWidth={0.5}
        />
      ))}

      {Array.from({ length: 6 }).map((_, i) => (
        <Circle
          key={`bolt-v1-${i}`}
          cx={width * 0.2}
          cy={height * 0.1 + (height * 0.8 * i) / 6}
          r={1.5}
          fill="#FFD700"
          stroke="#8B7355"
          strokeWidth={0.5}
        />
      ))}

      {Array.from({ length: 8 }).map((_, i) => (
        <Circle
          key={`bolt-h2-${i}`}
          cx={width * 0.15 + (width * 0.7 * i) / 8}
          cy={height * 0.5}
          r={1.5}
          fill="#FFD700"
          stroke="#8B7355"
          strokeWidth={0.5}
        />
      ))}

      {/* Pressure gauges */}
      <Circle cx={width * 0.15} cy={height * 0.35} r={12} fill="none" stroke="#D4AF37" strokeWidth={2} />
      <Circle cx={width * 0.15} cy={height * 0.35} r={10} fill="#1a1a1a" stroke="#8B7355" strokeWidth={1} />
      <Line x1={width * 0.15} y1={height * 0.35} x2={width * 0.15 + 7} y2={height * 0.35 - 5} stroke="#FFD700" strokeWidth={1.5} strokeLinecap="round" />

      <Circle cx={width * 0.85} cy={height * 0.65} r={12} fill="none" stroke="#D4AF37" strokeWidth={2} />
      <Circle cx={width * 0.85} cy={height * 0.65} r={10} fill="#1a1a1a" stroke="#8B7355" strokeWidth={1} />
      <Line x1={width * 0.85} y1={height * 0.65} x2={width * 0.85 - 7} y2={height * 0.65 + 5} stroke="#FFD700" strokeWidth={1.5} strokeLinecap="round" />

      {/* Valve wheels */}
      <Circle cx={width * 0.35} cy={height * 0.15} r={8} fill="none" stroke="#D4AF37" strokeWidth={2} />
      <Circle cx={width * 0.35} cy={height * 0.15} r={6} fill="#1a1a1a" stroke="#8B7355" strokeWidth={1} />
      <Line x1={width * 0.35} y1={height * 0.15 - 6} x2={width * 0.35} y2={height * 0.15 + 6} stroke="#FFD700" strokeWidth={1.5} />
      <Line x1={width * 0.35 - 6} y1={height * 0.15} x2={width * 0.35 + 6} y2={height * 0.15} stroke="#FFD700" strokeWidth={1.5} />

      <Circle cx={width * 0.65} cy={height * 0.85} r={8} fill="none" stroke="#D4AF37" strokeWidth={2} />
      <Circle cx={width * 0.65} cy={height * 0.85} r={6} fill="#1a1a1a" stroke="#8B7355" strokeWidth={1} />
      <Line x1={width * 0.65} y1={height * 0.85 - 6} x2={width * 0.65} y2={height * 0.85 + 6} stroke="#FFD700" strokeWidth={1.5} />
      <Line x1={width * 0.65 - 6} y1={height * 0.85} x2={width * 0.65 + 6} y2={height * 0.85} stroke="#FFD700" strokeWidth={1.5} />

      {/* Steam vents */}
      <Rect x={width * 0.45} y={height * 0.4} width={width * 0.1} height={8} fill="#8B7355" rx={4} />
      <Rect x={width * 0.45 + 1} y={height * 0.4 + 1} width={width * 0.1 - 2} height={6} fill="#A0826D" rx={3} />

      {/* Industrial frame corners */}
      <Rect x={width * 0.05} y={height * 0.05} width={12} height={12} fill="none" stroke="#D4AF37" strokeWidth={2} />
      <Rect x={width * 0.95 - 12} y={height * 0.05} width={12} height={12} fill="none" stroke="#D4AF37" strokeWidth={2} />
      <Rect x={width * 0.05} y={height * 0.95 - 12} width={12} height={12} fill="none" stroke="#D4AF37" strokeWidth={2} />
      <Rect x={width * 0.95 - 12} y={height * 0.95 - 12} width={12} height={12} fill="none" stroke="#D4AF37" strokeWidth={2} />
    </Svg>
  );
};
