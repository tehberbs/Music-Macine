import React, { useEffect } from 'react';
import { View, ViewProps } from 'react-native';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withTiming,
  interpolateColor,
} from 'react-native-reanimated';

interface AnimatedThemeViewProps extends ViewProps {
  fromBackgroundColor?: string;
  toBackgroundColor?: string;
  fromBorderColor?: string;
  toBorderColor?: string;
  duration?: number;
  animate?: boolean;
}

/**
 * View component that animates color transitions
 */
export const AnimatedThemeView = React.forwardRef<View, AnimatedThemeViewProps>(
  (
    {
      fromBackgroundColor = '#000000',
      toBackgroundColor = '#111111',
      fromBorderColor = '#333333',
      toBorderColor = '#444444',
      duration = 600,
      animate = true,
      style,
      children,
      ...props
    },
    ref
  ) => {
    const progress = useSharedValue(0);

    useEffect(() => {
      if (animate) {
        progress.value = withTiming(1, { duration });
      }
    }, [animate, duration, toBackgroundColor, toBorderColor]);

    const animatedStyle = useAnimatedStyle(() => {
      const backgroundColor = interpolateColor(
        progress.value,
        [0, 1],
        [fromBackgroundColor, toBackgroundColor]
      );

      const borderColor = interpolateColor(
        progress.value,
        [0, 1],
        [fromBorderColor, toBorderColor]
      );

      return {
        backgroundColor,
        borderColor,
      };
    });

    return (
      <Animated.View
        ref={ref}
        style={[animatedStyle, style]}
        {...props}
      >
        {children}
      </Animated.View>
    );
  }
);

AnimatedThemeView.displayName = 'AnimatedThemeView';

interface AnimatedThemeTextProps {
  fromColor?: string;
  toColor?: string;
  duration?: number;
  animate?: boolean;
  children: React.ReactNode;
  style?: any;
}

/**
 * Text component that animates color transitions
 */
export const AnimatedThemeText = React.forwardRef<any, AnimatedThemeTextProps>(
  (
    {
      fromColor = '#FFFFFF',
      toColor = '#CCCCCC',
      duration = 600,
      animate = true,
      children,
      style,
      ...props
    },
    ref
  ) => {
    const progress = useSharedValue(0);

    useEffect(() => {
      if (animate) {
        progress.value = withTiming(1, { duration });
      }
    }, [animate, duration, toColor]);

    const animatedStyle = useAnimatedStyle(() => {
      const color = interpolateColor(progress.value, [0, 1], [fromColor, toColor]);

      return {
        color,
      };
    });

    return (
      <Animated.Text
        ref={ref}
        style={[animatedStyle, style]}
        {...props}
      >
        {children}
      </Animated.Text>
    );
  }
);

AnimatedThemeText.displayName = 'AnimatedThemeText';

interface AnimatedThemeImageProps {
  fromOpacity?: number;
  toOpacity?: number;
  duration?: number;
  animate?: boolean;
  source: any;
  style?: any;
}

/**
 * Image component that animates opacity transitions
 */
export const AnimatedThemeImage = React.forwardRef<any, AnimatedThemeImageProps>(
  (
    {
      fromOpacity = 1,
      toOpacity = 1,
      duration = 600,
      animate = true,
      source,
      style,
      ...props
    },
    ref
  ) => {
    const progress = useSharedValue(0);

    useEffect(() => {
      if (animate) {
        progress.value = withTiming(1, { duration });
      }
    }, [animate, duration]);

    const animatedStyle = useAnimatedStyle(() => {
      const opacity = fromOpacity + (toOpacity - fromOpacity) * progress.value;

      return {
        opacity,
      };
    });

    return (
      <Animated.Image
        ref={ref}
        source={source}
        style={[animatedStyle, style]}
        {...props}
      />
    );
  }
);

AnimatedThemeImage.displayName = 'AnimatedThemeImage';
