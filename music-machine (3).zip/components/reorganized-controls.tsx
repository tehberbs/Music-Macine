import React from 'react';
import { View, Pressable, Text } from 'react-native';
import MaterialIcons from '@expo/vector-icons/MaterialIcons';

interface ReorganizedControlsProps {
  onPlayPause?: () => void;
  onSkipNext?: () => void;
  onSkipPrev?: () => void;
  onShuffle?: () => void;
  onRepeat?: () => void;
  isPlaying?: boolean;
  isShuffle?: boolean;
  repeatMode?: 'off' | 'all' | 'one';
  currentTrackTitle?: string;
  currentArtist?: string;
}

/**
 * Reorganized playback controls positioned around central gear
 * Inspired by the cogwheel animator reference layout
 */
export function ReorganizedControls({
  onPlayPause,
  onSkipNext,
  onSkipPrev,
  onShuffle,
  onRepeat,
  isPlaying = false,
  isShuffle = false,
  repeatMode = 'off',
  currentTrackTitle = 'No Track Selected',
  currentArtist = 'Unknown Artist',
}: ReorganizedControlsProps) {
  return (
    <View
      style={{
        width: '100%',
        height: '100%',
        justifyContent: 'space-between',
        alignItems: 'center',
        paddingVertical: 40,
      }}
    >
      {/* Track Info - Top */}
      <View
        style={{
          alignItems: 'center',
          gap: 4,
        }}
      >
        <Text
          style={{
            color: '#FFD700',
            fontSize: 16,
            fontWeight: '600',
            textAlign: 'center',
            maxWidth: 200,
          }}
          numberOfLines={1}
        >
          {currentTrackTitle}
        </Text>
        <Text
          style={{
            color: '#A0826D',
            fontSize: 12,
            textAlign: 'center',
            maxWidth: 200,
          }}
          numberOfLines={1}
        >
          {currentArtist}
        </Text>
      </View>

      {/* Central Controls - Middle (Skip Previous, Play/Pause, Skip Next) */}
      <View
        style={{
          flexDirection: 'row',
          alignItems: 'center',
          justifyContent: 'center',
          gap: 30,
        }}
      >
        {/* Skip Previous */}
        <Pressable
          onPress={onSkipPrev}
          style={({ pressed }) => ({
            width: 50,
            height: 50,
            borderRadius: 25,
            backgroundColor: '#2a2a2a',
            borderWidth: 2,
            borderColor: '#D4AF37',
            justifyContent: 'center',
            alignItems: 'center',
            opacity: pressed ? 0.7 : 1,
          })}
        >
          <MaterialIcons name="skip-previous" size={24} color="#FFD700" />
        </Pressable>

        {/* Play/Pause - This will be replaced by CentralGear in parent */}
        <View style={{ width: 40, height: 40 }} />

        {/* Skip Next */}
        <Pressable
          onPress={onSkipNext}
          style={({ pressed }) => ({
            width: 50,
            height: 50,
            borderRadius: 25,
            backgroundColor: '#2a2a2a',
            borderWidth: 2,
            borderColor: '#D4AF37',
            justifyContent: 'center',
            alignItems: 'center',
            opacity: pressed ? 0.7 : 1,
          })}
        >
          <MaterialIcons name="skip-next" size={24} color="#FFD700" />
        </Pressable>
      </View>

      {/* Mode Controls - Bottom (Shuffle and Repeat) */}
      <View
        style={{
          flexDirection: 'row',
          alignItems: 'center',
          justifyContent: 'center',
          gap: 20,
        }}
      >
        {/* Shuffle Button */}
        <Pressable
          onPress={onShuffle}
          style={({ pressed }) => ({
            width: 45,
            height: 45,
            borderRadius: 22.5,
            backgroundColor: isShuffle ? '#D4AF37' : '#2a2a2a',
            borderWidth: 2,
            borderColor: '#D4AF37',
            justifyContent: 'center',
            alignItems: 'center',
            opacity: pressed ? 0.7 : 1,
          })}
        >
          <MaterialIcons
            name="shuffle"
            size={20}
            color={isShuffle ? '#1a1a1a' : '#FFD700'}
          />
        </Pressable>

        {/* Repeat Button */}
        <Pressable
          onPress={onRepeat}
          style={({ pressed }) => ({
            width: 45,
            height: 45,
            borderRadius: 22.5,
            backgroundColor: repeatMode !== 'off' ? '#D4AF37' : '#2a2a2a',
            borderWidth: 2,
            borderColor: '#D4AF37',
            justifyContent: 'center',
            alignItems: 'center',
            opacity: pressed ? 0.7 : 1,
          })}
        >
          <MaterialIcons
            name={repeatMode === 'one' ? 'repeat-one' : 'repeat'}
            size={20}
            color={repeatMode !== 'off' ? '#1a1a1a' : '#FFD700'}
          />
        </Pressable>
      </View>
    </View>
  );
}

/**
 * Compact control buttons for quick access
 * Positioned at bottom of screen
 */
interface CompactControlsProps {
  onEQ?: () => void;
  onSiema?: () => void;
  onViz?: () => void;
  activeTab?: 'eq' | 'siema' | 'viz' | null;
}

export function CompactControls({
  onEQ,
  onSiema,
  onViz,
  activeTab,
}: CompactControlsProps) {
  const ControlButton = ({
    icon,
    label,
    onPress,
    active,
  }: {
    icon: keyof typeof MaterialIcons.glyphMap;
    label: string;
    onPress?: () => void;
    active?: boolean;
  }) => (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => ({
        alignItems: 'center',
        gap: 4,
        opacity: pressed ? 0.7 : 1,
      })}
    >
      <View
        style={{
          width: 50,
          height: 50,
          borderRadius: 25,
          backgroundColor: active ? '#D4AF37' : '#2a2a2a',
          borderWidth: 2,
          borderColor: '#D4AF37',
          justifyContent: 'center',
          alignItems: 'center',
        }}
      >
        <MaterialIcons
          name={icon}
          size={24}
          color={active ? '#1a1a1a' : '#FFD700'}
        />
      </View>
      <Text
        style={{
          color: '#A0826D',
          fontSize: 11,
          fontWeight: '600',
        }}
      >
        {label}
      </Text>
    </Pressable>
  );

  return (
    <View
      style={{
        flexDirection: 'row',
        justifyContent: 'space-around',
        alignItems: 'flex-end',
        paddingHorizontal: 20,
        paddingBottom: 20,
        gap: 15,
      }}
    >
      <ControlButton
        icon="equalizer"
        label="EQ"
        onPress={onEQ}
        active={activeTab === 'eq'}
      />
      <ControlButton
        icon="tune"
        label="Siema"
        onPress={onSiema}
        active={activeTab === 'siema'}
      />
      <ControlButton
        icon="graphic-eq"
        label="Viz"
        onPress={onViz}
        active={activeTab === 'viz'}
      />
    </View>
  );
}
