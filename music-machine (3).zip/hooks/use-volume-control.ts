import { useCallback, useState, useEffect } from 'react';
import { useNotification } from '@/lib/notification-context';

/**
 * Hook for managing audio volume control
 * Handles volume state and provides volume adjustment methods
 */
export function useVolumeControl(initialVolume: number = 0.7) {
  const [volume, setVolume] = useState(initialVolume);
  const { show } = useNotification();

  const MIN_VOLUME = 0;
  const MAX_VOLUME = 1;
  const VOLUME_STEP = 0.1;

  /**
   * Increase volume by one step
   */
  const increaseVolume = useCallback(() => {
    setVolume((prev) => {
      const newVolume = Math.min(prev + VOLUME_STEP, MAX_VOLUME);
      const percentage = Math.round(newVolume * 100);

      show({
        type: 'info',
        title: '🔊 Volume',
        message: `${percentage}%`,
        duration: 1500,
      });

      return newVolume;
    });
  }, [show]);

  /**
   * Decrease volume by one step
   */
  const decreaseVolume = useCallback(() => {
    setVolume((prev) => {
      const newVolume = Math.max(prev - VOLUME_STEP, MIN_VOLUME);
      const percentage = Math.round(newVolume * 100);

      show({
        type: 'info',
        title: '🔉 Volume',
        message: `${percentage}%`,
        duration: 1500,
      });

      return newVolume;
    });
  }, [show]);

  /**
   * Set volume to a specific value
   */
  const setVolumeLevel = useCallback(
    (level: number) => {
      const newVolume = Math.max(MIN_VOLUME, Math.min(level, MAX_VOLUME));
      setVolume(newVolume);

      const percentage = Math.round(newVolume * 100);
      show({
        type: 'info',
        title: '🔊 Volume',
        message: `${percentage}%`,
        duration: 1500,
      });
    },
    [show]
  );

  /**
   * Mute/unmute volume
   */
  const toggleMute = useCallback(() => {
    setVolume((prev) => {
      const newVolume = prev === 0 ? initialVolume : 0;
      const message = newVolume === 0 ? 'Muted' : `${Math.round(newVolume * 100)}%`;

      show({
        type: 'info',
        title: newVolume === 0 ? '🔇 Muted' : '🔊 Unmuted',
        message,
        duration: 1500,
      });

      return newVolume;
    });
  }, [initialVolume, show]);

  return {
    volume,
    increaseVolume,
    decreaseVolume,
    setVolumeLevel,
    toggleMute,
  };
}
