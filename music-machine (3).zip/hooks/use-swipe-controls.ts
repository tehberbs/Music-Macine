import { useCallback, useContext } from 'react';
import { MusicPlayerContext, type MusicPlayerContextType } from '@/lib/music-player-context-v2';
import { useNotification } from '@/lib/notification-context';
import { playbackNotifications } from '@/lib/notification-integration-example';

/**
 * Hook for handling swipe gesture controls
 * Manages track skipping and volume adjustment with notifications
 */
export function useSwipeControls() {
  const musicPlayer = useContext(MusicPlayerContext);
  if (!musicPlayer) {
    throw new Error('useSwipeControls must be used within MusicPlayerProvider');
  }
  const { nextTrack, previousTrack, currentTrack } = musicPlayer;
  const { show } = useNotification();

  /**
   * Handle left swipe - skip to next track
   */
  const handleSwipeLeft = useCallback(async () => {
    if (!currentTrack) {
      show({
        type: 'info',
        title: '⏭️ No Track',
        message: 'Load a track to skip',
        duration: 2000,
      });
      return;
    }

    await nextTrack();
    show({
      type: 'playback',
      title: '⏭️ Skipped',
      message: 'Next track',
      duration: 2000,
    });
  }, [currentTrack, nextTrack, show]);

  /**
   * Handle right swipe - skip to previous track
   */
  const handleSwipeRight = useCallback(async () => {
    if (!currentTrack) {
      show({
        type: 'info',
        title: '⏮️ No Track',
        message: 'Load a track to skip',
        duration: 2000,
      });
      return;
    }

    await previousTrack();
    show({
      type: 'playback',
      title: '⏮️ Previous',
      message: 'Playing previous track',
      duration: 2000,
    });
  }, [currentTrack, previousTrack, show]);

  /**
   * Handle up swipe - increase volume
   */
  const handleSwipeUp = useCallback(() => {
    show({
      type: 'info',
      title: '🔊 Volume Up',
      message: 'Swipe up to increase volume',
      duration: 1500,
    });
  }, [show]);

  /**
   * Handle down swipe - decrease volume
   */
  const handleSwipeDown = useCallback(() => {
    show({
      type: 'info',
      title: '🔉 Volume Down',
      message: 'Swipe down to decrease volume',
      duration: 1500,
    });
  }, [show]);

  return {
    handleSwipeLeft,
    handleSwipeRight,
    handleSwipeUp,
    handleSwipeDown,
  };
}
