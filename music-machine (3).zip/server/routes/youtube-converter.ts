/**
 * YouTube to MP3 Converter Routes
 * Handles video download and MP3 conversion using yt-dlp and ffmpeg
 */

import { Router, Request, Response } from 'express';
import { exec } from 'child_process';
import { promisify } from 'util';
import * as fs from 'fs';
import * as path from 'path';

const execPromise = promisify(exec);
const router = Router();

// Temporary directory for downloads
const TEMP_DIR = path.join(process.cwd(), 'temp_downloads');

// Ensure temp directory exists
if (!fs.existsSync(TEMP_DIR)) {
  fs.mkdirSync(TEMP_DIR, { recursive: true });
}

/**
 * Download YouTube video and convert to MP3
 * POST /api/youtube/convert
 * Body: { videoId: string, title: string }
 */
router.post('/convert', async (req: Request, res: Response) => {
  try {
    const { videoId, title } = req.body;

    if (!videoId) {
      return res.status(400).json({ error: 'videoId is required' });
    }

    const videoUrl = `https://www.youtube.com/watch?v=${videoId}`;
    const outputPath = path.join(TEMP_DIR, `${videoId}.mp3`);

    // Check if already converted
    if (fs.existsSync(outputPath)) {
      return res.json({
        success: true,
        file: outputPath,
        message: 'File already exists',
      });
    }

    // Download and convert using yt-dlp
    const command = `yt-dlp -x --audio-format mp3 --audio-quality 192K -o "${path.join(TEMP_DIR, '%(id)s.%(ext)s')}" "${videoUrl}"`;

    console.log('[YouTube Converter] Starting conversion:', videoId);

    const { stdout, stderr } = await execPromise(command, { timeout: 300000 }); // 5 minute timeout

    if (!fs.existsSync(outputPath)) {
      throw new Error('Conversion failed - output file not created');
    }

    console.log('[YouTube Converter] Conversion complete:', videoId);

    return res.json({
      success: true,
      file: outputPath,
      videoId,
      title,
      message: 'Conversion successful',
    });
  } catch (error) {
    console.error('[YouTube Converter] Error:', error);
    return res.status(500).json({
      error: 'Conversion failed',
      message: error instanceof Error ? error.message : 'Unknown error',
    });
  }
});

/**
 * Get conversion status
 * GET /api/youtube/convert/:videoId
 */
router.get('/convert/:videoId', (req: Request, res: Response) => {
  try {
    const { videoId } = req.params;
    const outputPath = path.join(TEMP_DIR, `${videoId}.mp3`);

    const exists = fs.existsSync(outputPath);
    const stats = exists ? fs.statSync(outputPath) : null;

    return res.json({
      videoId,
      exists,
      size: stats?.size || 0,
      createdAt: stats?.birthtime || null,
    });
  } catch (error) {
    console.error('[YouTube Converter] Error checking status:', error);
    return res.status(500).json({ error: 'Failed to check status' });
  }
});

/**
 * Download converted MP3 file
 * GET /api/youtube/download/:videoId
 */
router.get('/download/:videoId', (req: Request, res: Response) => {
  try {
    const { videoId } = req.params;
    const filePath = path.join(TEMP_DIR, `${videoId}.mp3`);

    if (!fs.existsSync(filePath)) {
      return res.status(404).json({ error: 'File not found' });
    }

    res.download(filePath, `${videoId}.mp3`);
  } catch (error) {
    console.error('[YouTube Converter] Download error:', error);
    return res.status(500).json({ error: 'Download failed' });
  }
});

/**
 * Get file stream for playback
 * GET /api/youtube/stream/:videoId
 */
router.get('/stream/:videoId', (req: Request, res: Response) => {
  try {
    const { videoId } = req.params;
    const filePath = path.join(TEMP_DIR, `${videoId}.mp3`);

    if (!fs.existsSync(filePath)) {
      return res.status(404).json({ error: 'File not found' });
    }

    const stat = fs.statSync(filePath);
    const fileSize = stat.size;
    const range = req.headers.range;

    if (range) {
      const parts = range.replace(/bytes=/, '').split('-');
      const start = parseInt(parts[0], 10);
      const end = parts[1] ? parseInt(parts[1], 10) : fileSize - 1;
      const chunksize = end - start + 1;

      res.writeHead(206, {
        'Content-Range': `bytes ${start}-${end}/${fileSize}`,
        'Accept-Ranges': 'bytes',
        'Content-Length': chunksize,
        'Content-Type': 'audio/mpeg',
      });

      fs.createReadStream(filePath, { start, end }).pipe(res);
    } else {
      res.writeHead(200, {
        'Content-Length': fileSize,
        'Content-Type': 'audio/mpeg',
      });

      fs.createReadStream(filePath).pipe(res);
    }
  } catch (error) {
    console.error('[YouTube Converter] Stream error:', error);
    return res.status(500).json({ error: 'Stream failed' });
  }
});

/**
 * Clean up old files (older than 7 days)
 * DELETE /api/youtube/cleanup
 */
router.delete('/cleanup', (req: Request, res: Response) => {
  try {
    const files = fs.readdirSync(TEMP_DIR);
    const now = Date.now();
    const sevenDaysMs = 7 * 24 * 60 * 60 * 1000;
    let deletedCount = 0;

    for (const file of files) {
      const filePath = path.join(TEMP_DIR, file);
      const stat = fs.statSync(filePath);
      const fileAge = now - stat.mtimeMs;

      if (fileAge > sevenDaysMs) {
        fs.unlinkSync(filePath);
        deletedCount++;
      }
    }

    return res.json({
      success: true,
      deletedCount,
      message: `Deleted ${deletedCount} old files`,
    });
  } catch (error) {
    console.error('[YouTube Converter] Cleanup error:', error);
    return res.status(500).json({ error: 'Cleanup failed' });
  }
});

export default router;
